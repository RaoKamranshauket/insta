<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
?>
<?php include 'config/declare.php'; ?>

<!-- a universal file that has all the classes included -->
<?php include 'config/classesGetter.php'; ?>

<!-- creating objects -->
<?php
  $universal = new universal;
?>

<?php
  if ($universal->isLoggedIn()) {
    header('Location: '.DIR);
  }
?>



<?php  include 'index_include/index_header.php'; ?>

<div class="index_wrapper">

<div class="lg:py-40 pt-24 pb-12 relative -mt-20 bg-white" id="home">
            <div class="banner1">
                <div class="objectWrapper">
                    <img src="assets/images/demos/main landing.png" alt="" >
                   
                </div>
            </div>
            <div class="uk-container mx-auto lg:mt-28">
                <div class="lg:w-5/12 lg:space-y-6 text-center lg:text-left lg:block flex flex-col justify-center items-center">
                   
                   

                    <div class="flex gap-4"> 
                        <a href="login" 
                        class="bg-gradient-to-bl font-semibold from-purple-500 to-blue-600 px-10 py-2 rounded text-sm text-white 
                        hover:shadow-lg hover:text-white">
                            Login </a>

                    </div>
                </div>
            </div>
        </div>

      
       


        


            </div>
        </div>


