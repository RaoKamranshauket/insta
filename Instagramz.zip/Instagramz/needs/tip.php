<div class="help">
  <div class="help_info">
    <?php
      foreach ($help as $value){
        echo "<span style='display:block;'>$value</span>";
      }
    ?>
  </div>
  <div class="help_icon">
    <span><i class="material-icons">help</i></span>
  </div>
</div>
