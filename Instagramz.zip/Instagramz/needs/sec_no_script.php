<link rel="stylesheet" href="./public/css/sec_no_script.css">

<div class="no_script">
  <img src="<?php echo DIR; ?>/images/needs/tumblr_nk2y2oVEjp1rn9vmdo1_500.gif" alt="">
  <div>
    <span>Javascript Required</span>
    <span>Please allow Javascript for GuildUp to work properly and give you a better browsing experience. If you don't know how to do it, there's an option on the address bar.</span>
  </div>
</div>
