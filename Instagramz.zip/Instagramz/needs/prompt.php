<div class="prompt model-shadow">
  <div class="prompt_top">
  <i class="fa fa-exclamation-triangle" style="color:red;" aria-hidden="true"></i> <span class="prompt_title"> Delete post</span>
    <span><i class="material-icons">clear</i></span>
  </div>
  <div class="prompt_middle">
    <span class="prompt_content">This post will be deleted. There's no undo so you won't be able to find it.</span>
  </div>
  <div class="prompt_bottom">
    <a href="#" class="bg-blue-100 flex font-medium h-9 items-center justify-center px-5 rounded-md text-blue-600 text-sm prompt_cancel"><i class="fa fa-times" aria-hidden="true"></i> Cancel</a>
    <a href="#" onclick="location.reload();" class="bg-red-600 flex h-9 items-center justify-center rounded-md text-white px-5 font-medium prompt_done">Delete</a>
  </div>
</div>
