

<div id="create-group-modal" class="create_grouppp create-post is-story" uk-modal>
<div class="uk-modal-dialog uk-modal-body uk-margin-auto-vertical rounded-lg p-0 lg:mt-20 relative shadow-2xl uk-animation-slide-bottom-small">
  
          <div class="text-center py-4 border-b">
                <h3 class="text-lg font-semibold"> Create a Community</h3>
                <button class="uk-modal-close-default bg-gray-100 rounded-full p-2.5 m-1 right-2" type="button" uk-close uk-tooltip="title: Close ; pos: bottom ;offset:7"></button>
            </div>

 
                    <!-- form body -->
                    <div class="p-10 space-y-7">
                       <div class="line c_t_name_div">
                            <input class="cc_name line__input" name="" type="text" onkeyup="this.setAttribute('value', this.value);" value="" autocomplete="off">
                            <span for="username" class="line__placeholder"><i class="fa fa-user" style="color:purple;"></i>  community Name </span>
                        </div>
                        <!--
                        <div class="flex items-center">
                            <div class="-mr-1 bg-gray-100 border px-3 py-3 rounded-l-md">  https://</div>
                            <input type="text" class="with-border" placeholder="">
                        </div>

                        <div>
                            <label for=""> Page Category </label>
                            <select id="" name=""  class="shadow-none selectpicker with-border ">
                                <option value="1">Technology</option>
                                <option value="2">Cars and Vehicles</option>
                                <option value="3">Comedy</option>
                                <option value="4">Economics and Trade</option>
                                <option value="5">Education</option>
                                <option value="6">Entertainment</option>
                                <option value="7">Movies & Animation</option>
                                <option value="8">Gaming</option>
                                <option value="9">History and Facts</option>
                                <option value="10">Live Style</option> 
                                <option value="0">Other</option>
                           </select>
                         </div> -->

                        <div class="line h-32 c_t_name_div"> 
                            <textarea class="line__input h-32 cc_ta" name="name" type="text" onkeyup="this.setAttribute('value', this.value);" value="" autocomplete="off" maxlength="300"></textarea>
                            <span for="username" class="line__placeholder"><i class="fa fa-info-circle" style="color:purple;"></i> About your community (300 words max)</span> 
                        </div>
                        
                    </div>

                     <?php
        if ($universal->GETsDetails($get_id, "firstname") == 'taiwo') {
             echo "
                    <div class='border-t flex justify-between lg:space-x-10 p-7 bg-gray-50 rounded-b-md'>
                        <p class='text-sm leading-6'> You can add profile picture, and other details after you create the community. </p>
                        <button type='button' class='c_t_done button lg:w-1/2'>
                            Create
                        </button>
                    </div>";
                      }else{
                         echo "
                    <div class='border-t flex justify-between lg:space-x-10 p-7 bg-gray-50 rounded-b-md'>
                        <p class='text-sm leading-6'> To create a community is not free on Tagopus. You need to Upgrade.</p>

                        <button  type='button' class='button upgradebtn lg:w-1/2'>
                        <a href='".DIR."/upgradecommunity.php' style='color:white;'>
                            <i class='fa fa-bolt'></i> &nbspUpgrade
                            </a>
                        </button>
                        
                    </div>";
                     }
  
  ?>
                </div>




</div>
</div>
