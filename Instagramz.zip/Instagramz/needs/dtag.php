<div id="offcanvas-tag" uk-offcanvas="flip: true; overlay: true">
<div class="uk-offcanvas-bar bg-white p-0 w-full lg:w-80 shadow-2xl">


<div class="relative pt-5 px-4">

   

    <div class="absolute right-3 top-4 flex items-center">

        <button style="color:red;" class="uk-offcanvas-close  px-2 -mt-1 relative rounded-full inset-0 lg:hidden blcok"
            type="button" uk-close></button>

        <a href="#" uk-toggle="target: #search;animation: uk-animation-slide-top-small">
            <ion-icon name="search" class="text-xl hover:bg-gray-100 p-1 rounded-full"></ion-icon>
        </a>
        
                  

    </div>


</div>

<div class="absolute bg-white z-10 w-full -mt-5 lg:-mt-2 transform translate-y-1.5 py-2 border-b items-center flex"
    id="search" hidden>
</div>

<nav class="responsive-nav border-b extanded mb-2 -mt-2">
    <ul uk-switcher="connect: #chats-tab; animation: uk-animation-fade" style="overflow-y: hidden;">
    <li class="uk-active" ><a class="active" ></a></li>
    </ul>
</nav>

<div class="contact-list px-2 uk-switcher" id="chats-tab">

    <div class="p-3">
    <div class="display_content">

    </div>

    </div>
    

  
  
</div>
</div>
</div>
