<div class="image_show" id="id01">

  <div class="img_s_img" >
  <i class="uil uil-times-circle" style="color:red; font-size:30px;" onclick="document.getElementById('id01').style.display='none'" ></i><br>
    <span onclick="document.getElementById('id01').style.display='none'" >&nbsp tap here to exit</span><br>
    <img src="<?php echo DIR; ?>/images/needs/c4e479a6a6d699749e9f0493e3134d2e.jpg" alt="">
    <div class="img_s_bottom">
      <span class="img_s_by">by Lord Voldemort</span>
      
    </div>
  </div>
<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>
</div>
