<?php
  $count = $noti->unreadCount();
  if($count == 0){
    $return = "";
  } else {
    $return = "<span class='ns_bold'>@{$universal->GETsDetails($session, "username")}</span>, you got {$count} notifications <i class='fa fa-bell' style='color:blue;' aria-hidden='true'></i>";
  }
?>

<div class="noti_speak" style='z-index: 100000;'>
<img src="<?php echo DIR?>/images/bird.gif" style="width:50px; height: 50px;" alt="">
<img src="<?php echo DIR?>/images/leaf.gif" style="width:20px; height: 20px; margin-top:18px;" alt="">
<img src="<?php echo DIR?>/images/bird.gif" style="width:50px; height: 50px;" alt="">
<img src="<?php echo DIR?>/images/leaf.gif" style="width:20px; height: 20px; margin-top:18px;" alt="">


<br>
<br>
</br>
  <input type="hidden" name="" value="<?php echo $return; ?>" class="noti_hidden">
  <img src="<?php echo DIR."/".$avatar->SESSIONsAvatar(); ?>" alt="">
  <div class="n_s_sn_div">
    <span><b>@Modi</b>, you got 12 notifications.</span>
  </div>
</div>
