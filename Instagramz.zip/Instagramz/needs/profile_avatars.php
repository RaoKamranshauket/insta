<div id="change-picture-modal" class="create-post pro_avatars" uk-modal>

<div class="uk-modal-dialog uk-modal-body uk-margin-auto-vertical rounded-lg p-0 lg:w-5/12 relative shadow-2xl uk-animation-slide-bottom-small">
  
          <div class="text-center py-4 border-b">
                <h3 class="text-lg font-semibold"> Change Profile Picture</h3>
                <button class="uk-modal-close-default bg-gray-100 rounded-full p-2.5 m-1 right-2" type="button" uk-close uk-tooltip="title: Close ; pos: bottom ;offset:7"></button>
            </div>
  
  <div class="pro_ava_middle">
    <div class="pro_ava_content">
      <?php
        $images = glob('images/avatars/*');
        foreach ($images as $key => $value) {
          echo "<img src='". DIR ."/$value' class='pro_ava_avts' style='display:inline-flex;'>";
        }
      ?>
    </div>
  </div>

    <div class="flex items-center w-full justify-between p-3 border-t">
  
    <form class="pro_ch_form" action="" method="post" enctype="multipart/form-data">
      <input type="file" name="pro_ch_ava" value="" id="pro_ch_ava" class="">
      <label for="pro_ch_ava" class="bg-purple-100 flex font-medium h-9 items-center justify-center px-5 rounded-md text-purple-600 text-sm"><i class="fa fa-picture-o" aria-hidden="true"></i> &nbsp Upload avatar</label>
      <div class="pro_preview model-shadow">
        <div class="pro_pre_top">
          <div class="pro_pre_info">
            <span>Select this avatar</span>
          </div>
        </div>
        <div class="pro_pre_img">
          <img src="<?php echo DIR; ?>/images/needs/17455538fd839328f5606d284d0c360d.jpg" alt="">
        </div>
        <div class="pro_pre_bottom flex space-x-2">
          <a href="#" class="bg-red-100 flex font-medium h-9 items-center justify-center px-5 rounded-md text-red-600 text-sm pro_pre_cancel">Cancel</a>
          <input type="submit" name="" value="Select" class="bg-blue-600 flex h-9 items-center justify-center rounded-md text-white px-5 font-medium pro_pre_select">
        </div>
      </div>
    </form>
    <div class="pro_ava_bottom_act flex space-x-2">
      <a href="#" onClick="window.location.reload()" class="bg-red-100 flex font-medium h-9 items-center justify-center px-5 rounded-md text-red-600 text-sm">Cancel</a>
      <a href="#" onClick="window.location.reload()" class="bg-blue-600 flex h-9 items-center justify-center rounded-md text-white px-5 font-medium">Apply</a>
    </div>
    
  </div>


</div>
</div>

<div class="pro_crop model-shadow" style="z-index: 100000;">
  <div class="pro_crop_img">
    <img src="<?php echo DIR; ?>/images/needs/17455538fd839328f5606d284d0c360d.jpg" alt="" class="crop_img">
    <div class="pro_crop_tool" style="z-index: 100000;"></div>
  </div>
  <div class="pro_crop_act">
    <a href="#" class="bg-red-100 flex font-medium h-9 items-center justify-center px-5 rounded-md text-red-600 text-sm pro_crop_cancel">Cancel</a>
    <a href="#" onClick="window.location.reload()" class="bg-blue-600 flex h-9 items-center justify-center rounded-md text-white px-5 font-medium pro_crop_done">Apply</a>
  </div>
</div>
