<body>
   

    <div id="wrapper">

        <!-- Header -->
        <header>
            <div class="header_wrap">
                <div class="header_inner mcontainer">
                    <div class="left_side">
                        
                      

                        <div id="logo">
                            <a> 
                                <img src="<?php echo DIR; ?>/assets/images/display logo22.png" alt="">
                                <img src="<?php echo DIR; ?>/assets/images/display logo22.png" class="logo_mobile" alt="Guild Up">
                            </a>
                        </div>
                    </div>
                     
                     
                  
                    
    
                </div>
            </div>
        </header>