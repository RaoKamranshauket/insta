<!-- TEXT POST -->

<div id="create-pozt-modal" class="create-pozt is-story" uk-modal>


</div>


<!-- IMAGE POST -->

<div id="create-post-image-modal" class="create-post-image is-story" uk-modal>

  

</div>

<!-- VIDEO POST -->
<div id="create-post-video-modal" class="create-post-video is-story" uk-modal>

  

</div>

<!-- AUDIO POST -->
<div id="create-post-audio-modal" class="create-post-audio is-story" uk-modal>

  

</div>

<!-- DOCUMENT POST -->
<div class="doc_post post">

  <div class="post_spinner">
    <div class="spinner">
      <span></span><span></span><span></span>
    </div>
  </div>

</div>

<!-- LOCATION POST -->
<div class="loc_post post">

  <div class="post_spinner">
    <div class="spinner">
      <span></span><span></span><span></span>
    </div>
  </div>

</div>

<!-- LINK POST -->
<div id="create-post-link-modal" class="create-post-link is-story" uk-modal>

  

</div>
