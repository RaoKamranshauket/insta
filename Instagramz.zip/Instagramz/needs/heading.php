<body>
   

    <div id="wrapper">

        <!-- Header -->
        <header>
            <div class="header_wrap">
                <div class="header_inner mcontainer">
                    <div class="left_side">
                        
                        <span class="slide_menu" uk-toggle="target: #wrapper ; cls: is-collapse is-active">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path d="M3 4h18v2H3V4zm0 7h12v2H3v-2zm0 7h18v2H3v-2z" fill="currentColor"></path></svg>
                        </span>

                       
                    </div>
                     
                     
                  <!-- search icon for mobile -->
                    <div class="header-search-icon" uk-toggle="target: #wrapper ; cls: show-searchbox"> </div>
                   
                    
    
                    <div class="right_side">
    
                        <div class="header_widgets">
                            

                           
                            <a href="<?php echo DIR; ?>" class="is_icon" uk-tooltip="title: homepage">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="text-blue-600"> 
                                <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z" />
                                </svg>
                            </a>
                           
                            <a class="is_icon notifications" uk-tooltip="title: Notifications" data-link="notifications">
                                <svg fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M10 2a6 6 0 00-6 6v3.586l-.707.707A1 1 0 004 14h12a1 1 0 00.707-1.707L16 11.586V8a6 6 0 00-6-6zM10 18a3 3 0 01-3-3h6a3 3 0 01-3 3z"></path></svg>
                                <span><?php echo $noti->unreadCount(); ?>
                                </span>
                            </a> <?php if($universal->isLoggedIn()){ ?>


                            <!-- notification-->
                            <div uk-drop="mode: click" class="header_dropdown">
                                 <div  class="dropdown_scrollbar" data-simplebar>
                                     <div class="drop_headline">
                                         <h4>Notifications </h4>
                                         <div class="btn_action">
                                            <?php $noti->markRead(); ?>
                                        
                                            <a class="clear_noti" data-description='Clear notifications' data-tippy-placement="left" title="clear all">
                                            <?php if($noti->notiCount() != 0){ ?>
                                                <i class='icon-feather-wind'></i>
                                            <?php } ?>
                                            </a>
                                        </div>
                                     </div>
                                     <ul>
                                        
                                     <?php $noti->getNotifications("direct", "0"); ?>
                            
                                         
                                     </ul> 
                                 </div>
                            </div> 
                            <!-- notification stop-->
                            

                            <!-- Message -->
                            <a href="<?php echo DIR; ?>/messages" class="is_icon messages" uk-tooltip="title: Message" data-link="messages">
                                <svg fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M18 5v8a2 2 0 01-2 2h-5l-5 4v-4H4a2 2 0 01-2-2V5a2 2 0 012-2h12a2 2 0 012 2zM7 8H5v2h2V8zm2 0h2v2H9V8zm6 0h-2v2h2V8z" clip-rule="evenodd"></path></svg>
                                <span class="m_n_new"><?php echo $message->getAllUnreadMssg(); ?></span>
                            </a>
                            
         
        
                            <a>
                                <img src="<?php echo DIR."/".$avatar->SESSIONsAvatar(); ?>" class="is_avatar" alt="<?php echo $universal->getUsernameFromSession(); ?>'s avatar">
                            </a>
                            <div uk-drop="mode: click;offset:5" class="header_dropdown profile_dropdown">

                               
                                
                                <hr>
                              
                                <?php if ($universal->isLoggedIn() == true) { ?>
                                <a href="<?php echo DIR; ?>/logout">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
                                    </svg>
                                    Log Out 
                                </a>
                                <?php } ?>

                                
                            </div>

                        </div>
                        
                    </div>
                </div>
            </div>
            <?php } ?>
        </header>