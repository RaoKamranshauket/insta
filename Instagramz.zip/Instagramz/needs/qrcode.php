<div id="offcanvas-qrcode" uk-offcanvas="flip: true; overlay: true">
<div class="uk-offcanvas-bar bg-white p-0 w-full lg:w-80 shadow-2xl">


<div class="relative pt-5 px-4">

   

    <div class="absolute right-3 top-4 flex items-center">

        <button style="color:red;" class="uk-offcanvas-close  px-2 -mt-1 relative rounded-full inset-0 lg:hidden blcok"
            type="button" uk-close></button>

        <a href="#" uk-toggle="target: #search;animation: uk-animation-slide-top-small">
            <ion-icon name="search" class="text-xl hover:bg-gray-100 p-1 rounded-full"></ion-icon>
        </a>
        
                  

    </div>


</div>

<div class="absolute bg-white z-10 w-full -mt-5 lg:-mt-2 transform translate-y-1.5 py-2 border-b items-center flex"
    id="search" hidden>
</div>

<nav class="responsive-nav border-b extanded mb-2 -mt-2">
    <ul uk-switcher="connect: #chats-tab; animation: uk-animation-fade" style="overflow-y: hidden;">
        
        
    </ul>
</nav>

<div class="contact-list px-2 uk-switcher" id="chats-tab">

    <div class="p-3">
        <img src="<?php echo DIR; ?>/assets/images/display logo22.png" style="width:200px; display: block;
        margin-left: auto;
        margin-right: auto;
        width: 50%;"/>
    <input id="text" type="text" value="<?php echo DIR; ?>/profile/<?php echo $universal->GETsDetails($get_id, 'username'); ?>" style="width:80%" hidden/><br />
<div class="qrcode" id="qrcode" style="width:200px; height:200px; display: block;
        margin-left: auto;
        margin-right: auto;
        margin-top:15px;"></div>
<br>
<h1 class="qrname">@<?php echo $universal->GETsDetails($get_id, 'username'); ?></h1>
<br>
<br>
   <img style='width:50px; height:50px; display: block;
        margin-left: auto;
        margin-right: auto;' src="<?php echo DIR; ?>/images/bird.gif" />     
<p style='text-align:center;'><i class="fa fa-info-circle" style='color:purple;'></i> Scan to follow or take a Screenshot and Share.</p>
<style>
    .qrcode img{
        width:200px;
        height:200px;
    }
    .qrname {
        text-align:center;
  font-size: 20px;
  font-weight:bold;
  background: -webkit-linear-gradient(#0000FF, #800080);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;

    }
</style>
<script type="text/javascript" src="<?php echo DIR; ?>/public/js/qrcode.js"></script>
<script type="text/javascript">
var qrcode = new QRCode(document.getElementById("qrcode"), {
	width : 100,
	height : 100
});

function makeCode () {		
	var elText = document.getElementById("text");
	
	if (!elText.value) {
		alert("Input a text");
		elText.focus();
		return;
	}
	
	qrcode.makeCode(elText.value);
}

makeCode();

$("#text").
	on("blur", function () {
		makeCode();
	}).
	on("keydown", function (e) {
		if (e.keyCode == 13) {
			makeCode();
		}
	});
</script>


    </div>
    

  
  
</div>
</div>
</div>
