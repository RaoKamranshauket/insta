<div class="mssg_to model-shadow">
  
  
      <img src="images/mess.gif" style="width: 150px; height: 150px; margin-left: 30%;">
      <div style="margin-left: 30%;">
      Send a Message <i class="fa fa-envelope" style="color:red;" aria-hidden="true"></i>
      <br>
      <i class="fa fa-user" style="color:blue;" aria-hidden="true"></i><span class="m_t_username">Guildup Admin</span>
      </div>
    

  <div class="m_t_main">
    <input type="hidden" name="" value="" class="to_holder">
    <input type="text" name="" value="" placeholder="Name.." class="con_name" spellcheck="false" hidden>
    <textarea name="name" class="m_t_ta input100" spellcheck="false" placeholder="Write a message.." required></textarea>
  </div>

  <div class="m_t_bottom">
    <!-- <span class="m_t_emoji"><i class="material-icons">sentiment_very_satisfied</i></span> -->
    <a href="#" class="bg-red-100 flex font-medium h-9 items-center justify-center px-5 rounded-md text-red-600 text-sm m_t_cancel"><i class="fa fa-times" aria-hidden="true"></i> Cancel</a>
    <a href="#" class="bg-blue-600 flex h-9 items-center justify-center rounded-md text-white px-5 font-medium m_t_done"><i class="fa fa-paper-plane" aria-hidden="true"></i> Send</a>
  </div>

</div>
