<?php include 'config/declare.php'; ?>

<!-- a universal file that has all the classes included -->
<?php include 'config/classesGetter.php'; ?>

<!-- creating objects -->
<?php
  $universal = new universal;
  $avatar = new Avatar;
  $post = new post;
  $noti = new notifications;
  $message = new message;
?>

<?php
  if ($universal->isLoggedIn() == false) {
    header('Location:'. DIR .'/welcome');
  }
  $session = $_SESSION['id'];
?>

<?php
  $title = "{$noti->titleNoti()} Messages • GuildUp";
  $keywords = "GuildUp, Share and capture world's moments, share, capture, messages";
  $desc = "GuildUp lets you capture, follow, like and share world's moments in a better way and tell your story with photos, messages, posts and everything in between";
?>

<!-- including files for header of document -->
<?php include_once 'includes/headerchat.php'; ?>
<?php include_once 'needs/headingchat.php'; ?>

<div class="user_info" data-userid="<?php echo $session; ?>" data-sessionid="<?php echo $session; ?>" data-username="<?php echo $universal->getUsernameFromSession(); ?>"></div>
<div class="overlay"></div>
<div class="overlay-2"></div>
<div class="notify" style="z-index: 100000;"><span></span></div>

     <!-- Main Contents -->
<div class="layout-wrapper d-lg-flex">


            <div class="chat-leftsidebar me-lg-1 ms-lg-0">

                <div class="tab-content">

         
          <div class="mssg_left messages-inbox">
              <div class="messages-headline">
                  <div class="input-with-icon" hidden>
                          <input id="autocomplete-input" type="text" placeholder="Search">
                      <i class="icon-material-outline-search"></i>
                  </div>
                  <h2 class="text-2xl font-semibold"><a href="<?php echo DIR; ?>"><i class="uil uil-angle-left"></i></a>Chats</h2>
                  <span class="absolute uil uil-envelope-edit mr-4 text-xl uk-position-center-right cursor-pointer new_con"></span>
              </div>


              <div class="mssg_add_persons search-box chat-search-box">
                <div class="input-group mb-3 rounded-3">
                <input type="text" name="" value="" class="form-control bg-light" placeholder="Search to message" spellcheck="false">
              </div>
              </div>

              <div class="mssg_persons">
                <div class="mssg_persons_inner">
                  <ul></ul>
                </div>
              </div>
             
              <div id="titleMain" class="messages-inbox-inner search-box chat-search-box">
              <form id="search-chats">
                <div class="input-group mb-3 rounded-3">
                                        <span class="input-group-text text-muted bg-light pe-1 ps-3">
                                            <i class="uil uil-search"></i>
                                        </span>
                                        <input type="text" class="form-control bg-light" placeholder="Search chat history ..." >
                                    </div> 
              </form>

               <!-- Start user status -->
                            <div class="px-4 pb-4" dir="ltr">
                              
                                <div class="owl-carousel owl-theme" id="user-status-carousel">

                                     <?php $message->convomain(); ?>

                                    
            
                                </div>
                                <!-- end user status carousel -->
                            </div>


                            <div>
                                <h5 class="mb-3 px-3 font-size-16">Recent</h5>

                                <div class="chat-message-list px-2" data-simplebar>
                  <ul uk-toggle="target: .message-content;" class="list-unstyled chat-list chat-user-list">
                      
                    <?php $message->conversations(); ?>
                  </ul>
              </div></div></div>
<script>const searchBar = document.forms['search-chats'].querySelector('input');
searchBar.addEventListener('keyup', function(e) {
  const term = e.target.value.toLocaleLowerCase();
  const searchchats = document.getElementsByClassName('message-nani');
  var notAvailable = document.getElementById('notAvailable');
  $("#titleMain").toggle($('input').val().length == 0);
  var hasResults = false;
  Array.from(searchchats).forEach(function(book) {
    const title = book.textContent;
    if (title.toLowerCase().indexOf(term) != -1) {
      book.parentElement.parentElement.style.display = 'flex';
      hasResults = true;
    } else {
      book.parentElement.parentElement.style.display = 'none';
    }
  });
  notAvailable.style.display = hasResults ? 'none' : 'block';
});</script>
          </div>
  
</div>
</div>



           <div class="w-100 overflow-hidden"s>
                <div class="d-lg-flex">

                  
          
          <div id="getback" class="mssg_right message-content"  hidden>


          <img src='<?php echo DIR; ?>/images/img-01.png'>
          <span>Please select a conversation</span>


          </div>
        </div>
      </div>

            <script>
function myFunction() {
  var x = document.getElementById("getback");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
</script>
           

     

 

</div>







<?php include 'needs/message_div.php'; ?>
<?php include 'needs/emojis.php'; ?>
<?php include_once 'needs/display.php'; ?>
<?php include_once 'needs/prompt.php'; ?>
<?php include 'needs/image_show.php'; ?>
<?php include 'needs/stickers.php'; ?>
<?php include 'needs/.php'; ?>
<?php include_once 'needs/search.php'; ?>

<!-- including the footer of the document -->
<?php include_once 'includes/footerchat.php'; ?>

<script type="text/javascript">
  $(function(e){
    LinkIndicator("messages");
    // $('.messages').find('.m_n_new').text('');
    // $('.mssg_last_mssg').on('click', function(e){
    //   if (window.Notification) {
    //     Notification.requestPermission(function(status){
    //       console.log('status: '+status);
    //       var n = new Notification('Instagram', {
    //         body: "Wlecome to Instagram!",
    //         icon: DIR+"/images/avatars/voldemort.jpg"
    //       });
    //     });
    //   }
    // });
  });
</script>
