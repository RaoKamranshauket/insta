<script type="text/javascript" src="<?php echo DIR; ?>/public/js/autosize.js"></script>
<!-- <script src="//twemoji.maxcdn.com/twemoji.min.js"></script> -->
<script type='text/javascript' src="<?php echo DIR; ?>/public/js/emoji.js"></script>
<script type="text/javascript" src="<?php echo DIR; ?>/public/js/perfectScrollbar.js"></script>
<script type="text/javascript" src="<?php echo DIR; ?>/public/js/wookmark.js"></script>
<script type="text/javascript" src="<?php echo DIR; ?>/public/js/text_figures.js"></script>
<script type="text/javascript" src="<?php echo DIR; ?>/public/js/modules.js"></script>
<script type="text/javascript" src="<?php echo DIR; ?>/public/js/prompt_fn.js"></script>
<script type="text/javascript" src="<?php echo DIR; ?>/public/js/login_fn.js"></script>
<script type="text/javascript" src='<?php echo DIR; ?>/public/js/post_partial.js'></script>
<script type="text/javascript" src='<?php echo DIR; ?>/public/js/comment_partial.js'></script>
<script type="text/javascript" src='<?php echo DIR; ?>/public/js/settings_partial.js'></script>
<script type="text/javascript" src='<?php echo DIR; ?>/public/js/mssg_partial.js'></script>
<script type="text/javascript" src='<?php echo DIR; ?>/public/js/group_partial.js'></script>
<script type="text/javascript" src="<?php echo DIR; ?>/public/js/master.js"></script>

<script src="ca/assets/js/jquery.min.js"></script>
    <script src="ca/assets/js/bootstrap.min.js"></script>
    <script src="ca/assets/js/jquery-ui.js"></script>
    <script src="ca/assets/js/plugin/slick.js"></script>
    <script src="ca/assets/js/plugin/apexcharts.js"></script>
    <script src="ca/assets/js/plugin/jquery.countdown.js"></script>
    <script src="ca/assets/js/plugin/jquery.nice-select.min.js"></script>
    <script src="ca/assets/js/plugin/waypoint.min.js"></script>
    <script src="ca/assets/js/plugin/wow.min.js"></script>
    <script src="ca/assets/js/plugin/plugin.js"></script>
    <script src="ca/assets/js/main.js"></script>
  
    <!-- Javascript
    ================================================== -->
    <script src="assets/js/tippy.all.min.js"></script>
    <script src="assets/js/uikit.js"></script>
    <script src="assets/js/simplebar.js"></script>
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/bootstrap-select.min.js"></script>
    <script src="../../unpkg.com/ionicons%405.2.3/dist/ionicons.js"></script>
<noscript>
  <?php include 'needs/sec_no_script.php'; ?>
</noscript>
</body>
</html>
