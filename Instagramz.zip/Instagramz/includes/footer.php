<script type="text/javascript" src="<?php echo DIR; ?>/public/js/autosize.js"></script>
<!-- <script src="//twemoji.maxcdn.com/twemoji.min.js"></script> -->
<script type='text/javascript' src="<?php echo DIR; ?>/public/js/emoji.js"></script>
<script type="text/javascript" src="<?php echo DIR; ?>/public/js/perfectScrollbar.js"></script>
<script type="text/javascript" src="<?php echo DIR; ?>/public/js/wookmark.js"></script>
<script type="text/javascript" src="<?php echo DIR; ?>/public/js/text_figures.js"></script>
<script type="text/javascript" src="<?php echo DIR; ?>/public/js/modules.js"></script>
<script type="text/javascript" src="<?php echo DIR; ?>/public/js/prompt_fn.js"></script>
<script type="text/javascript" src="<?php echo DIR; ?>/public/js/login_fn.js"></script>
<script type="text/javascript" src='<?php echo DIR; ?>/public/js/post_partial.js'></script>
<script type="text/javascript" src='<?php echo DIR; ?>/public/js/comment_partial.js'></script>
<script type="text/javascript" src='<?php echo DIR; ?>/public/js/settings_partial.js'></script>
<script type="text/javascript" src='<?php echo DIR; ?>/public/js/mssg_partial.js'></script>
<script type="text/javascript" src='<?php echo DIR; ?>/public/js/group_partial.js'></script>
<script type="text/javascript" src="<?php echo DIR; ?>/public/js/master.js"></script>
<!-- For Night mode -->
<script>
        (function (window, document, undefined) {
            'use strict';
            if (!('localStorage' in window)) return;
            var nightMode = localStorage.getItem('gmtNightMode');
            if (nightMode) {
                document.documentElement.className += ' night-mode';
            }
        })(window, document);
    
        (function (window, document, undefined) {
    
            'use strict';
    
            // Feature test
            if (!('localStorage' in window)) return;
    
            // Get our newly insert toggle
            var nightMode = document.querySelector('#night-mode');
            if (!nightMode) return;
    
            // When clicked, toggle night mode on or off
            nightMode.addEventListener('click', function (event) {
                event.preventDefault();
                document.documentElement.classList.toggle('dark');
                if (document.documentElement.classList.contains('dark')) {
                    localStorage.setItem('gmtNightMode', true);
                    return;
                }
                localStorage.removeItem('gmtNightMode');
            }, false);
    
        })(window, document);
    </script>
  
    <!-- Javascript
    ================================================== -->
    <script src="assets/js/tippy.all.min.js"></script>
    <script src="assets/js/uikit.js"></script>
    <script src="assets/js/simplebar.js"></script>
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/bootstrap-select.min.js"></script>
    <script src="../../unpkg.com/ionicons%405.2.3/dist/ionicons.js"></script>
<noscript>
  <?php include 'needs/sec_no_script.php'; ?>
</noscript>
</body>
</html>
