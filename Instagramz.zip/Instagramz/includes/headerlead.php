

  <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Favicon -->
    <link href="assets/images/favicon.png" rel="icon" type="image/png">

    <!-- Basic Page Needs
        ================================================== -->
    <title>Tagopus</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    

    <!-- icons
    ================================================== -->
    <link rel="stylesheet" href="assets/css/icons.css">

    <!-- CSS 
    ================================================== --> 
    <link rel="icon" href="<?php echo DIR; ?>/images/favicon/favicon.png" type="image/png">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <!-- <link href="https://fonts.googleapis.com/css?family=Arima+Madurai" rel="stylesheet"> -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo DIR; ?>/public/css/perfectScrollbar.css">
    <link rel="stylesheet" href="<?php echo DIR; ?>/public/css/animate.css">
    <link rel="stylesheet" href="<?php echo DIR; ?>/public/css/master.css">
    <script type="text/javascript" src="<?php echo DIR; ?>/public/js/jquery-3.1.1.min.js"></script>
    <link rel="stylesheet" href="assets/css/uikit.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/tailwind.css">  
    <link rel="stylesheet" href="<?php echo DIR; ?>/public/css/reactlike.css"> 


     <link rel="stylesheet" href="ca/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="ca/assets/css/fontawesome.min.css">
    <link rel="stylesheet" href="ca/assets/css/jquery-ui.css">
    <link rel="stylesheet" href="ca/assets/css/plugin/slick.css">
    <link rel="stylesheet" href="ca/assets/css/plugin/apexcharts.css">
    <link rel="stylesheet" href="ca/assets/css/plugin/nice-select.css">
    <link rel="stylesheet" href="ca/assets/css/arafat-font.css">
    <link rel="stylesheet" href="ca/assets/css/plugin/animate.css">
    <link rel="stylesheet" href="ca/assets/css/style.css">


</head>
