<?php include 'config/declare.php'; ?>

<!-- a universal file that has all the classes included -->
<?php include 'config/classesGetter.php'; ?>

<!-- creating objects -->
<?php
  $universal = new universal;
?>

<?php
  if ($universal->isLoggedIn()) {
    header('Location: '.DIR);
  }
?>

<?php
  $title = "Tagopus";
  $keywords = "Create your own future. Build amazing professional communities.";
  $desc = "Tagopus is a platform purpose-built for professional groups, networks and people to connect and share what's new and life moments with friends, communicate and collaborate.";
?>

<?php  include 'index_include/index_header.php'; ?>

<div class="index_wrapper">


        <div class="bg-white"  id="features"> 

            <svg width="100%" height="100px" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" preserveAspectRatio="none" x="0px" y="0px" viewBox="0 0 2560 100" style="enable-background:new 0 0 2560 100" xml:space="preserve" class="-mt-24 absolute fill-current text-white invisible lg:visible">
                <polygon points="2560 0 2560 100 0 100"></polygon>
            </svg>
            
            <div class="container m-auto  py-20">

                <div class=" mb-3">
                    <h1 class="text-3xl font-semibold"> COOKIE POLICY</h1>
                    <div data-custom-class="body">
	<div>
		<br>
	</div>
	<div>
		<span style="color: rgb(127, 127, 127);"><strong><span style="font-size: 15px;"><span data-custom-class="subtitle">Last updated <bdt class="question">May 08, 2023</bdt></span></span></strong></span>
	</div>
	<div>
		<br>
	</div>
	<div>
		<br>
	</div>
	<div>
		<br>
	</div>
	<div style="line-height: 1.5;">
		<span style="color: rgb(127, 127, 127);"><span style="color: rgb(89, 89, 89); font-size: 15px;"><span data-custom-class="body_text">This Cookie Policy explains how <bdt class="question">__________</bdt> ("<strong>Company</strong>," "<strong>we</strong>," "<strong>us</strong>," and "<strong>our</strong>") uses cookies and similar technologies to recognize you when you visit our website at <bdt class="question"><a href="https://tagopus.com" target="_blank" data-custom-class="link">https://tagopus.com</a></bdt> ("<strong>Website</strong>"). It explains what these technologies are and why we use them, as well as your rights to control our use of them.</span></span></span>
	</div>
	<div style="line-height: 1.5;">
		<br>
	</div>
	<div style="line-height: 1.5;">
		<span style="color: rgb(127, 127, 127);"><span style="color: rgb(89, 89, 89); font-size: 15px;"><span data-custom-class="body_text">In some cases we may use cookies to collect personal information, or that becomes personal information if we combine it with other information.</span></span></span>
	</div>
	<div style="line-height: 1.5;">
		<br>
	</div>
	<div style="line-height: 1.5;">
		<span style="color: rgb(127, 127, 127);"><span style="color: rgb(0, 0, 0); font-size: 15px;"><strong><span data-custom-class="heading_1">What are cookies?</span></strong></span></span>
	</div>
	<div style="line-height: 1.5;">
		<br>
	</div>
	<div style="line-height: 1.5;">
		<span style="color: rgb(127, 127, 127);"><span style="color: rgb(89, 89, 89); font-size: 15px;"><span data-custom-class="body_text">Cookies are small data files that are placed on your computer or mobile device when you visit a website. Cookies are widely used by website owners in order to make their websites work, or to work more efficiently, as well as to provide reporting information.</span></span></span>
	</div>
	<div style="line-height: 1.5;">
		<br>
	</div>
	<div style="line-height: 1.5;">
		<span style="color: rgb(127, 127, 127);"><span style="color: rgb(89, 89, 89); font-size: 15px;"><span data-custom-class="body_text">Cookies set by the website owner (in this case, <bdt class="question">__________</bdt>) are called "first-party cookies." Cookies set by parties other than the website owner are called "third-party cookies." Third-party cookies enable third-party features or functionality to be provided on or through the website (e.g., advertising, interactive content, and analytics). The parties that set these third-party cookies can recognize your computer both when it visits the website in question and also when it visits certain other websites.</span></span></span>
	</div>
	<div style="line-height: 1.5;">
		<br>
	</div>
	<div style="line-height: 1.5;">
		<span style="color: rgb(127, 127, 127);"><span style="color: rgb(0, 0, 0); font-size: 15px;"><strong><span data-custom-class="heading_1">Why do we use cookies?</span></strong></span></span>
	</div>
	<div style="line-height: 1.5;">
		<br>
	</div>
	<div style="line-height: 1.5;">
		<span style="color: rgb(127, 127, 127);"><span style="color: rgb(89, 89, 89); font-size: 15px;"><span data-custom-class="body_text">We use first-<bdt class="block-component"></bdt> and third-<bdt class="statement-end-if-in-editor"></bdt>party cookies for several reasons. Some cookies are required for technical reasons in order for our Website to operate, and we refer to these as "essential" or "strictly necessary" cookies. Other cookies also enable us to track and target the interests of our users to enhance the experience on our Online Properties. <bdt class="block-component"></bdt>Third parties serve cookies through our Website for advertising, analytics, and other purposes. <bdt class="statement-end-if-in-editor"></bdt>This is described in more detail below.</span></span></span>
	</div>
	<div style="line-height: 1.5;">
		<br>
	</div>
	
	<div style="line-height: 1.5;">
		<span data-custom-class="heading_2" style="color: rgb(0, 0, 0);"><span style="font-size: 15px;"><strong><u><br>
		Performance and functionality cookies:</u></strong></span></span>
	</div>
	<div>
		<p style="font-size: 15px; line-height: 1.5;">
			<span style="font-size: 15px; color: rgb(89, 89, 89);"><span data-custom-class="body_text">These cookies are used to enhance the performance and functionality of our Website but are non-essential to their use. However, without these cookies, certain functionality (like videos) may become unavailable.</span></span>
		</p>
		<div>
			<span style="font-size: 15px; color: rgb(89, 89, 89);"><span data-custom-class="body_text"><section data-custom-class="body_text" style="width: 100%; border: 1px solid #e6e6e6; margin: 0 0 10px; border-radius: 3px;">
			<div style="padding: 8px 13px; border-bottom: 1px solid #e6e6e6;">
				<table>
					<tbody>
						<tr style="font-family: Roboto, Arial; font-size: 12px; line-height: 1.67; margin: 0 0 8px; vertical-align: top;">
							<td style="text-align: right; color: #19243c; min-width: 80px;">
								Name:
							</td>
							<td style="display: inline-block; margin-left: 5px;">
								<span style="color: #8b93a7; word-break: break-all;">PHPSESSID</span>
							</td>
						</tr>
						<tr style="font-family: Roboto, Arial; font-size: 12px; line-height: 1.67; margin: 0; vertical-align: top;">
							<td style="text-align: right; color: #19243c; min-width: 80px;">
								Purpose:
							</td>
							<td style="display: inline-block; margin-left: 5px;">
								<span style="color: #8b93a7; word-break: break-all;">Cookie generated by applications based on the PHP language. This is a general purpose identifier used to maintain user session variables. It is normally a random generated number, how it is used can be specific to the site, but a good example is maintaining a logged-in status for a user between pages.</span>
							</td>
						</tr>
						<tr style="font-family: Roboto, Arial; font-size: 12px; line-height: 1.67; margin: 0 0 8px; vertical-align: top;">
							<td style="text-align: right; color: #19243c; min-width: 80px;">
								Provider:
							</td>
							<td style="display: inline-block; margin-left: 5px;">
								<span style="color: #8b93a7; word-break: break-all;">tagopus.com</span>
							</td>
						</tr>
						<tr style="font-family: Roboto, Arial; font-size: 12px; line-height: 1.67; margin: 0 0 8px; vertical-align: top;">
							<td style="text-align: right; color: #19243c; min-width: 80px;">
								Service:
							</td>
							<td style="display: inline-block; margin-left: 5px;">
								<span style="color: #8b93a7; word-break: break-all;">PHP.net <a href="https://www.php.net/privacy.php" style="color: #1a98eb !important;" target="_blank">View Service Privacy Policy</a> &nbsp;</span>
							</td>
						</tr>
						<tr style="font-family: Roboto, Arial; font-size: 12px; line-height: 1.67; margin: 0 0 8px; vertical-align: top;">
							<td style="text-align: right; color: #19243c; min-width: 80px;">
								Country:
							</td>
							<td style="display: inline-block; margin-left: 5px;">
								<span style="color: #8b93a7; word-break: break-all;">Finland</span>
							</td>
						</tr>
						<tr style="font-family: Roboto, Arial; font-size: 12px; line-height: 1.67; margin: 0 0 8px; vertical-align: top;">
							<td style="text-align: right; color: #19243c; min-width: 80px;">
								Type:
							</td>
							<td style="display: inline-block; margin-left: 5px;">
								<span style="color: #8b93a7; word-break: break-all;">server_cookie</span>
							</td>
						</tr>
						<tr style="font-family: Roboto, Arial; font-size: 12px; line-height: 1.67; margin: 0 0 8px; vertical-align: top;">
							<td style="text-align: right; color: #19243c; min-width: 80px;">
								Expires in:
							</td>
							<td style="display: inline-block; margin-left: 5px;">
								<span style="color: #8b93a7; word-break: break-all;">session</span>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			</section></span></span>
		</div>
	</div>
	<div style="line-height: 1.5;">
		<br>
	</div>
	<div style="line-height: 1.5;">
		<span style="color: rgb(127, 127, 127);"><span style="color: rgb(0, 0, 0); font-size: 15px;"><strong><span data-custom-class="heading_1">How can I control cookies on my browser?</span></strong></span></span>
	</div>
	<div style="line-height: 1.5;">
		<br>
	</div>
	<div style="line-height: 1.5;">
		<span data-custom-class="body_text">As the means by which you can refuse cookies through your web browser controls vary from browser to browser, you should visit your browser's help menu for more information. The following is information about how to manage cookies on the most popular browsers:</span>
	</div>
	<ul style="color:blue">
		<li style="line-height: 1.5;"><a href="https://support.google.com/chrome/answer/95647#zippy=%2Callow-or-block-cookies" rel="noopener noreferrer" target="_blank"><span data-custom-class="link">Chrome</span></a></li>
		<li style="line-height: 1.5;"><a href="https://support.microsoft.com/en-us/windows/delete-and-manage-cookies-168dab11-0753-043d-7c16-ede5947fc64d" rel="noopener noreferrer" target="_blank"><span data-custom-class="link">Internet Explorer</span></a></li>
		<li style="line-height: 1.5;"><a href="https://support.mozilla.org/en-US/kb/enhanced-tracking-protection-firefox-desktop?redirectslug=enable-and-disable-cookies-website-preferences&amp;redirectlocale=en-US" rel="noopener noreferrer" target="_blank"><span data-custom-class="link">Firefox</span></a></li>
		<li style="line-height: 1.5;"><a href="https://support.apple.com/en-ie/guide/safari/sfri11471/mac" rel="noopener noreferrer" target="_blank"><span data-custom-class="link">Safari</span></a></li>
		<li style="line-height: 1.5;"><a href="https://support.microsoft.com/en-us/windows/microsoft-edge-browsing-data-and-privacy-bb8174ba-9d73-dcf2-9b4a-c582b4e640dd" rel="noopener noreferrer" target="_blank"><span data-custom-class="link">Edge</span></a></li>
		<li style="line-height: 1.5;"><a href="https://help.opera.com/en/latest/web-preferences/" rel="noopener noreferrer" target="_blank"><span data-custom-class="link">Opera</span></a></li>
	</ul>
	<div style="line-height: 1.5;">
		<span data-custom-class="body_text">In addition, most advertising networks offer you a way to opt out of targeted advertising. If you would like to find out more information, please visit:</span>
	</div>
	<ul style="color:blue">
		<li style="line-height: 1.5;"><a href="http://www.aboutads.info/choices/" rel="noopener noreferrer" target="_blank"><span data-custom-class="link">Digital Advertising Alliance</span></a></li>
		<li style="line-height: 1.5;"><a href="https://youradchoices.ca/" rel="noopener noreferrer" target="_blank"><span data-custom-class="link">Digital Advertising Alliance of Canada</span></a></li>
		<li style="line-height: 1.5;"><a href="http://www.youronlinechoices.com/" rel="noopener noreferrer" target="_blank"><span data-custom-class="body_text"><span data-custom-class="link">European Interactive Digital Advertising Alliance</span></span></a></li>
	</ul>
	<div style="line-height: 1.5;">
		<br>
	</div>
	<div style="line-height: 1.5;">
		<span style="color: rgb(127, 127, 127);"><span style="color: rgb(0, 0, 0); font-size: 15px;"><strong><span data-custom-class="heading_1">What about other tracking technologies, like web beacons?</span></strong></span></span>
	</div>
	<div style="line-height: 1.5;">
		<br>
	</div>
	<div style="line-height: 1.5;">
		<span style="color: rgb(127, 127, 127);"><span style="color: rgb(89, 89, 89); font-size: 15px;"><span data-custom-class="body_text">Cookies are not the only way&nbsp;</span><span style="font-size: 15px; color: rgb(89, 89, 89);"><span data-custom-class="body_text">to recognize or track visitors to a website. We may use other, similar technologies from time to time, like web beacons (sometimes called "tracking pixels" or "clear gifs"). These are tiny graphics files that contain a unique identifier that enables us to recognize when someone has visited our Website<bdt class="block-component"></bdt> or opened an email including them<bdt class="statement-end-if-in-editor"></bdt>. This allows us, for example, to monitor&nbsp;</span><span style="font-size: 15px; color: rgb(89, 89, 89);"><span style="color: rgb(89, 89, 89);"><span data-custom-class="body_text">the traffic patterns of users from one page within a website to another, to deliver or communicate with cookies, to understand whether you have come to the website from an online advertisement displayed on a third-party website, to improve site performance, and to measure the success of email marketing campaigns. In many instances, these technologies are reliant on cookies to function properly, and so declining cookies will impair their functioning.</span><bdt class="block-component"></bdt></span></span></span></span></span>
	</div>
	<div style="line-height: 1.5;">
		<br>
	</div>
	<div style="line-height: 1.5;">
		<span style="color: rgb(127, 127, 127);"><span style="color: rgb(89, 89, 89); font-size: 15px;"><span style="font-size: 15px; color: rgb(89, 89, 89);"><span style="font-size: 15px; color: rgb(89, 89, 89);"><span style="color: rgb(0, 0, 0);"><strong><span data-custom-class="heading_1">Do you use Flash cookies or Local Shared Objects?</span></strong></span></span></span></span></span>
	</div>
	<div style="line-height: 1.5;">
		<br>
	</div>
	<div style="line-height: 1.5;">
		<span style="font-size: 15px; color: rgb(89, 89, 89);"><span data-custom-class="body_text">Websites may also use so-called "Flash Cookies" (also known as Local Shared Objects or "LSOs") to, among other things, collect and store information about your use of our services, fraud prevention, and for other site operations.</span></span>
	</div>
	<div style="line-height: 1.5;">
		<br>
	</div>
	<div style="line-height: 1.5;">
		<span style="font-size: 15px; color: rgb(89, 89, 89);"><span data-custom-class="body_text">If you do not want Flash Cookies stored on your computer, you can adjust the settings of your Flash player to block Flash Cookies storage using the tools contained in the&nbsp;</span></span><span data-custom-class="body_text"><span style="color: rgb(48, 48, 241);"><a data-custom-class="link" href="http://www.macromedia.com/support/documentation/en/flashplayer/help/settings_manager07.html" target="_BLANK"><span style="font-size: 15px;">Website Storage Settings Panel</span></a></span><span style="font-size: 15px; color: rgb(89, 89, 89);">. You can also control Flash Cookies by going to the&nbsp;</span><span style="color: rgb(48, 48, 241);"><a data-custom-class="link" href="http://www.macromedia.com/support/documentation/en/flashplayer/help/settings_manager03.html" target="_BLANK"><span style="font-size: 15px;">Global Storage Settings Panel</span></a></span></span><span style="font-size: 15px; color: rgb(89, 89, 89);"><span data-custom-class="body_text">&nbsp;and&nbsp;</span><span style="font-size:15px; color: rgb(89, 89, 89);"><span data-custom-class="body_text">following the instructions (which may include instructions that explain, for example, how to delete existing Flash Cookies (referred to "information" on the Macromedia site), how to prevent Flash LSOs from being placed on your computer without your being asked, and (for Flash Player 8 and later) how to block Flash Cookies that are not being delivered by the operator of the page you are on at the time).</span></span></span>
	</div>
	<div style="line-height: 1.5;">
		<br>
	</div>
	<div style="line-height: 1.5;">
		<span style="font-size: 15px; color: rgb(89, 89, 89);"><span style="font-size: 15px; color: rgb(89, 89, 89);"><span data-custom-class="body_text">Please note that setting the Flash Player to restrict or limit acceptance of Flash Cookies may reduce or impede the functionality of some Flash applications, including, potentially, Flash applications used in connection with our services or online content.</span></span></span><span style="color: rgb(127, 127, 127);"><span style="color: rgb(89, 89, 89); font-size: 15px;"><span style="font-size: 15px; color: rgb(89, 89, 89);"><span style="font-size: 15px; color: rgb(89, 89, 89);"><span style="color: rgb(89, 89, 89);"><bdt class="statement-end-if-in-editor"></bdt><bdt class="block-component"></bdt></span></span></span></span></span>
	</div>
	<div style="line-height: 1.5;">
		<br>
	</div>
	<div style="line-height: 1.5;">
		<span style="color: rgb(127, 127, 127);"><span style="color: rgb(89, 89, 89); font-size: 15px;"><span style="font-size: 15px; color: rgb(89, 89, 89);"><span style="font-size: 15px; color: rgb(89, 89, 89);"><span style="color: rgb(89, 89, 89);"><span style="font-size: 15px; color: rgb(89, 89, 89);"><span style="font-size: 15px; color: rgb(0, 0, 0);"><strong><span data-custom-class="heading_1">Do you serve targeted advertising?</span></strong></span></span></span></span></span></span></span>
	</div>
	<div style="line-height: 1.5;">
		<br>
	</div>
	<div style="line-height: 1.5;">
		<span style="font-size: 15px; color: rgb(89, 89, 89);"><span data-custom-class="body_text">Third parties may serve cookies on your computer or mobile device to serve advertising through our Website. These companies may use information about your visits to this and other websites in order to provide relevant advertisements about goods and services that you may be interested in. They may also employ technology that is used to measure the effectiveness of advertisements. They can accomplish this by using cookies or web beacons to collect information about your visits to this and other sites in order to provide relevant advertisements about goods and services of potential interest to you. The information collected through this process does not enable us or them to identify your name, contact details, or other details that directly identify you unless you choose to provide these.</span></span><span style="color: rgb(127, 127, 127);"><span style="color: rgb(89, 89, 89); font-size: 15px;"><span style="font-size: 15px; color: rgb(89, 89, 89);"><span style="font-size: 15px; color: rgb(89, 89, 89);"><span style="color: rgb(89, 89, 89);"><bdt class="statement-end-if-in-editor"></bdt></span></span></span></span></span>
	</div>
	<div style="line-height: 1.5;">
		<br>
	</div>
	<div style="line-height: 1.5;">
		<span style="font-size: 15px; color: rgb(89, 89, 89);"><span style="font-size: 15px; color: rgb(0, 0, 0);"><strong><span data-custom-class="heading_1">How often will you update this Cookie Policy?</span></strong></span></span>
	</div>
	<div style="line-height: 1.5;">
		<br>
	</div>
	<div style="line-height: 1.5;">
		<span style="font-size: 15px; color: rgb(89, 89, 89);"><span style="font-size: 15px; color: rgb(89, 89, 89);"><span data-custom-class="body_text">We may update&nbsp;</span><span style="font-size: 15px; color: rgb(89, 89, 89);"><span data-custom-class="body_text">this Cookie Policy from time to time in order to reflect, for example, changes to the cookies we use or for other operational, legal, or regulatory reasons. Please therefore revisit this Cookie Policy regularly to stay informed about our use of cookies and related technologies.</span></span></span></span>
	</div>
	<div style="line-height: 1.5;">
		<br>
	</div>
	<div style="line-height: 1.5;">
		<span style="font-size: 15px; color: rgb(89, 89, 89);"><span style="font-size: 15px; color: rgb(89, 89, 89);"><span style="font-size: 15px; color: rgb(89, 89, 89);"><span data-custom-class="body_text">The date at the top of this Cookie Policy indicates when it was last updated.</span></span></span></span>
	</div>
	<div style="line-height: 1.5;">
		<br>
	</div>
	<div style="line-height: 1.5;">
		<span style="font-size: 15px; color: rgb(89, 89, 89);"><span style="font-size: 15px; color: rgb(89, 89, 89);"><span style="font-size: 15px; color: rgb(0, 0, 0);"><strong><span data-custom-class="heading_1">Where can I get further information?</span></strong></span></span></span>
	</div>
	<div style="line-height: 1.5;">
		<br>
	</div>
	<div style="line-height: 1.5;">
		<span style="font-size: 15px; color: rgb(89, 89, 89);"><span style="font-size: 15px; color: rgb(89, 89, 89);"><span style="font-size: 15px; color: rgb(89, 89, 89);"><span data-custom-class="body_text">If you have any questions about our use of cookies or other technologies, please email us at <a href="mailto:info@tagopus.com" style="color:blue">info@tagopus.com</a></span></span></span></span>
	</div>
	<div style="line-height: 1.5;">
		<span data-custom-class="body_text"><br>
		</span>
	</div>
	<style>
      ul {
        list-style-type: square;
      }
      ul > li > ul {
        list-style-type: circle;
      }
      ul > li > ul > li > ul {
        list-style-type: square;
      }
      ol li {
        font-family: Arial ;
      }
	</style>
</div>    
                </div>


                


            </div>
        </div>
<?php include 'index_include/index_footer.php'; ?>

<script type="text/javascript">
  $(function(e){
    // $('.s_username').username_checker({
    //   url: "reg_process/@username_checker.php"
    // });

    $('#show_psswrd').togglePassword({
      input: document.getElementById('password')
    });

    $('form').on('submit', (function(e){
      e.preventDefault();
      $('.s_submit').prop('disabled', true);
      $('.overlay-2').show();
      login($('.s_username').val(), $('.s_password').val(), $('.s_submit'));
    }))

  });
</script>
