<?php include 'config/declare.php'; ?>

<!-- a universal file that has all the classes included -->
<?php include 'config/classesGetter.php'; ?>

<!-- creating objects -->
<?php
  $universal = new universal;
  $avatar = new Avatar;
  $noti = new notifications;
  $message = new message;
?>

<?php
  $title = "{$noti->titleNoti()} Member not found • Instagram";
  $keywords = "eror, 404, document not found, webpage not found, Instagram, Share and capture world's moments";
  $desc = "There's been an error • Instagram";
?>

<?php
  if ($universal->isLoggedIn()) {
    include 'includes/header.php';
    include 'needs/heading.php';
    include 'needs/nav.php';
    include_once 'needs/search.php';
  } else if ($universal->isLoggedIn() == false) {
    include 'index_include/index_header.php';
  }
?>

<div class="mcontainer">
  <div style="text-align: center; margin-top: 70px;">
    <h1 style="font-weight:bold; font-size: 40px;">Oops!</h1>
    <p style="font-weight:bold;">no such member found</p>
    <img src="<?php echo DIR; ?>/images/needs/bud3.svg" style="height: 300px; width:300px; display: block; margin: auto;" alt="404">
    <?php
      if ($universal->isLoggedIn()) {
    ?>
    <a href="<?php echo DIR; ?>/profile/<?php echo $universal->getUsernameFromSession(); ?>" class="prii_btn">View profile</a>
    <a href="<?php echo DIR; ?>" class="prii_btn bg-purple-500" style="color: white;">Try going to homepage</a>
    <?php } else { ?>
      <a href="<?php echo DIR; ?>/login" class="prii_btn bg-purple-500" style="color: white;">Login</a>
      <a href="<?php echo DIR; ?>" class="pri_btn bg-purple-500" style="color: white;">Try going to homepage</a>
    <?php } ?>
  </div>
</div>

<?php
if ($universal->isLoggedIn()) {
  include 'includes/footer.php';
} else if ($universal->isLoggedIn() == false) {
  include 'index_include/index_footer.php';
}
?>
