 <!-- footer-->
 <div class="lg:mb-5 py-3 uk-link-reset">
                <div class="flex flex-col items-center justify-between lg:flex-row max-w-6xl mx-auto lg:space-y-0 space-y-3">
                    <div class="flex space-x-2 text-gray-700 uppercase">
                        <a href="#"> About</a>
                        <a href="#"> Help</a>
                        <a href="#"> Terms</a>
                        <a href="#"> Privacy</a>
                    </div>
                    <p class="capitalize"> © 2021 Tagopus</p>
                </div>
            </div>
    
        </div>


    </div>

    <!-- Scripts
    ================================================== -->
    <script src="assets/js/tippy.all.min.js"></script>
    <script src="assets/js/jquery-3.3.1.min.js"></script> 
    <script src="assets/js/tippy.all.min.js"></script>
    <script src="assets/js/uikit.js"></script>
    <script src="assets/js/simplebar.min.html"></script>
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/bootstrap-select.min.js"></script>

<script type="text/javascript">
  $(function(){
    $('.index_header > .logo').on('click', function(e){
      window.location.href = "welcome";
    });
    //for replacing illegal characters
    $('.s_username, .s_password, .s_email, .s_firstname, .s_surname').on('keyup', function(e){
      replacer($(this));
    });
  });
</script>
<noscript>
  <?php include 'needs/sec_no_script.php'; ?>
</noscript>


</body>
</html>
