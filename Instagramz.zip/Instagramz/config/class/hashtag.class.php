<?php
  class hashtag{

    protected $db;
    protected $DIR;

    public function __construct(){
      $db = N::_DB();
      $DIR = N::$DIR;

      $this->db = $db;
      $this->DIR = $DIR;
    }

    public function toHashtag($str, $of){
      $regex = "/#+([^ <>]+)/";
      $two = substr($str, 1);
      $t = preg_replace("#[\#]#", "", $two);

      if ($t != "") {
        if ($of == "post") {
          $str = preg_replace($regex, '<a class="hashtag" href="'. $this->DIR .'/hashtag?tag=$1">$0</a>', $str);
        } else if ($of == "comment") {
          $str = preg_replace($regex, "<span class='hashtag'>$0</span>", $str);
        }
      }

      return $str;
    }

    public function lineBreakHashtag($str, $of){
      $newString = '';
      $array = preg_split('/(\r\n|\r|\n)/', $str);

      foreach ($array as $line) {
        $word = explode(' ', $line);
        foreach ($word as $each) {
          $each = trim($each);
          if($each[0] == "#"){

            $two = substr($each, 1);
            $t = preg_replace("#[\#]#", "", $two);

            if($t != ""){
              if($of == "post"){
                $newString .= "<a class='hashtag' href='{$this->DIR}/hashtag?tag={$t}'>{$each}</a> ";
              } else if($of == "comment") {
                $newString .= "<span class='hashtag'>{$each}</span>";
              }
            }

          } else {
            $newString .= "$each ";
          }

        }
      }

      return $newString;

    }

    public function getHashtags($text, $post){
      $session = $_SESSION['id'];

      // $array = explode(" ", $text);
      $array = preg_split('/(\r\n|\r|\n| )/', $text);

      foreach ($array as $value) {
        if ($value[0] == "#") {
          $sec = substr($value, 1);
          $t = trim(preg_replace("#[\#]#", "", $sec));
          if ($t != "") {
            // $mquery = $this->db->prepare("SELECT hashtag_id FROM hashtag WHERE post_id = :post AND hashtag = :hashtag AND user_id = :user AND src = :src");
            // $mquery->execute(array(":post" => $post, ":hashtag" => $value, ":user" => $session, ":src" => "post"));
            // if ($mquery->rowCount() == 0) {
            $query = $this->db->prepare("INSERT INTO hashtag(hashtag, src, post_id, user_id, time) VALUES (:hashtag, :src, :post, :user, now())");
            $query->execute(array(":hashtag" => "#$t", ":src" => "post", ":post" => $post, ":user" => $session));
            // }
          }
        }
      }
    }

    public function noOfHashTags($hash){
      $query = $this->db->prepare("SELECT hashtag_id FROM hashtag WHERE hashtag LIKE :hash");
      $query->execute(array(":hash" => "%#$hash%"));
      $count = $query->rowCount();
      if ($count == 0) {
        return "No";
      } else {
        return $count;
      }
    }

    public function usersHashtags($user){
      $universal = new universal;

      if (isset($_SESSION['id'])) {
        $session = $_SESSION['id'];
      }

      $query = $this->db->prepare("SELECT DISTINCT hashtag FROM hashtag WHERE user_id = :user ORDER BY hashtag_id DESC LIMIT 20");
      $query->execute(array(":user" => $user));
      if ($query->rowCount() > 0) {
        echo "<div class='my_hashtags inst'><div class='header_of_divs '><h4 class='text-lg font-semibold'>";
        if($user == @$session){ echo "<i style='color:green; font-size: 40px;'>#</i> Your"; } else { echo $universal->GETsDetails($user, "username")."'s"; }
        echo " recent hashtags</h4></div><div class='my_h_main'>";
        while ($row = $query->fetch(PDO::FETCH_OBJ)) {
          $hashtag = $row->hashtag;
          echo "<a href='{$this->DIR}/hashtag?tag=". substr($hashtag, 1) ."'>{$hashtag}</a>";
        }
        echo "</div></div>";
      }
    }

    public function popularHashtags(){
      $session = $_SESSION['id'];
      $universal = new universal;

      $query = $this->db->query("SELECT hashtag, COUNT(hashtag) as c FROM hashtag GROUP BY hashtag ORDER BY c DESC LIMIT 10");
      if ($query->rowCount() > 0) {
        echo "<h3 class='text-xl font-semibold mb-2'><i style='color:green; font-size: 40px;'>#</i> Popular Trends  </h3>
        <div class='py-2 pl-2 mb-2 rounded-md hover:bg-gray-200'>";
        while ($row = $query->fetch(PDO::FETCH_OBJ)) {
          $hashtag = $row->hashtag;
          echo "<a href='{$this->DIR}/hashtag?tag=". substr($hashtag, 1) ."'><p class='line-clamp-2'> <strong>{$hashtag}</strong> 
          </p></a>";
        }
        echo "</div>";
      }
    }

    //hashtag for Explore page
    public function popularHashtagsex(){
      $session = $_SESSION['id'];
      $universal = new universal;

      $query = $this->db->query("SELECT hashtag, catex, rateex, locationex, COUNT(hashtag) as c FROM hashtag GROUP BY hashtag ORDER BY c DESC LIMIT 10");
      if ($query->rowCount() > 0) {
        echo "<div class='flex-1 space-y-2'> ";
        while ($row = $query->fetch(PDO::FETCH_OBJ)) {
          $hashtag = $row->hashtag;
          $catex = $row->catex;
          $rateex = $row->rateex;
          $locationex = $row->locationex;
          echo "<p class='leading-6 pr-4 line-clamp-2 md:block'> {$catex}</p>
          <a href='{$this->DIR}/hashtag?tag=". substr($hashtag, 1) ."' class='md:text-xl font-semibold line-clamp-2'> <strong>{$hashtag}</strong> </a>
          <div class='flex items-center justify-between'>
                                <div class='flex space-x-3 items-center text-sm md:pt-3'>
                                    <div>{$rateex} </div>
                                    <div class='md:block hidden'>·</div>
                                    <div><i class='uil uil-globe'></i>{$locationex}</div>
                                </div>
                            </div><hr></hr>";
        }
        echo "</div>";
      }
    }

    public function noOfHashTagPosts($tag){
      $query = $this->db->prepare("SELECT post.post_id, post.user_id, post.type, post.post_of, post.grp_id, post.time, post.font_size, post.address FROM post, hashtag WHERE hashtag.hashtag = :hashtag AND hashtag.post_id = post.post_id ORDER BY post.time DESC");
      $query->execute(array(":hashtag" => "#$tag"));
      $count = $query->rowCount();
      if ($count == 0) {
        return "No";
      } else {
        return $count;
      }
    }

    public function hashtaggedPost($tag, $way, $limit){
      $session = $_SESSION['id'];

      $avatar = new Avatar;
      $universal = new universal;
      $Time = new time;
      $post_like = new postLike;
      $bookmark = new bookmark;
      $taggings = new taggings;
      $share = new share;
      $comment = new postComment;
      $follow = new follow_system;
      $comment = new postComment;
      $settings = new settings;
      $groups = new group;
      $Post = new post;

      if ($way == "direct") {
        $query = $this->db->prepare("SELECT post.post_id, post.user_id, post.type, post.post_of, post.grp_id, post.time, post.font_size, post.address, hashtag.hashtag_id FROM post, hashtag WHERE hashtag.hashtag = :hashtag AND hashtag.post_id = post.post_id ORDER BY hashtag.hashtag_id DESC LIMIT 10");
        $query->execute(array(":hashtag" => "#$tag"));

      } else if ($way == "ajax") {
        $start = intval($limit);
        $query = $this->db->prepare("SELECT post.post_id, post.user_id, post.type, post.post_of, post.grp_id, post.time, post.font_size, post.address, hashtag.hashtag_id FROM post, hashtag WHERE hashtag.hashtag = :hashtag AND hashtag.post_id = post.post_id AND hashtag.hashtag_id < :start ORDER BY hashtag.hashtag_id DESC LIMIT 5");
        $query->execute(array(":hashtag" => "#$tag", ":start" => $start));
      }

      $count = $query->rowCount();
      if ($count == 0) {
        if ($way == "direct") {
          echo "<div class='home_last_mssg hashtag_last_mssg'><img src='{$this->DIR}/images/no post.gif'><span>No tagged posts found</span></div>";
        }
      } else if ($count > 0) {
        while ($row = $query->fetch(PDO::FETCH_OBJ)) {
          $hashid = $row->hashtag_id;
          $post_id = $row->post_id;
          $user_id = $row->user_id;
          $type = $row->type;
          $time = $row->time;
          $size = $row->font_size;
          $address = $row->address;
          $of = $row->post_of;
          $grp = $row->grp_id;

          echo "<div class='card lg:mx-0 uk-animation-slide-bottom-small posts inst' data-postid='{$post_id}' data-type='{$type}' data-hashid='{$hashid}'>";
          if ($way == "direct") {
            echo "<div class='flex justify-between items-center lg:p-4 p-2.5'>
            <div class='flex flex-1 items-center space-x-4'>
            <img class='bg-gray-200 border border-white rounded-full w-10 h-10' src='{$this->DIR}/". $avatar->GETsAvatar($user_id) ."' alt=''>";
          } else if ($way == "ajax") {
            echo "<div class='flex justify-between items-center lg:p-4 p-2.5'>
            <div class='flex flex-1 items-center space-x-4'>
            <img class='bg-gray-200 border border-white rounded-full w-10 h-10' src='{$this->DIR}/". $avatar->DisplayAvatar($user_id) ."' alt=''>";
          }

          echo "<div class='flex-1 capitalize'>
          <div class='font-semibold'>
          <a href='". DIR ."/profile/{$universal->GETsDetails($user_id, "username")}' data-getid='{$user_id}' class='text-black dark:text-gray-100'> ".$universal->GETsDetails($user_id, "firstname")." ".$universal->GETsDetails($user_id, "surname")."</a>
          </div>
          <div class='text-gray-700 flex items-center space-x-2'>
          <span><a href='". DIR ."/profile/{$universal->GETsDetails($user_id, "username")}' data-getid='{$user_id}' class='text-black dark:text-gray-100' title='{$universal->GETsDetails($user_id, "username")}'> @{$universal->nameShortener($universal->GETsDetails($user_id, "username"), 25)}</a>
           ";
          echo "</span>";
          echo "<p>. ". $Time->timeAgo($time) ."</p> <ion-icon name='people'></ion-icon></div>";
          echo $Post->addressN($address, $user_id);
          echo " </div></div><div>"; 
          echo "<span class='exp_p_menu'><i class='icon-feather-more-horizontal text-2xl hover:bg-gray-200 rounded-full p-2 transition -mr-1 dark:hover:bg-gray-700'></i></span>
          <div class='p_options bg-white w-56 shadow-md mx-auto p-2 mt-12 rounded-md text-gray-500 hidden text-base border border-gray-100 dark:bg-gray-900 dark:text-gray-100 dark:border-gray-700' 
          uk-drop='mode: click;pos: bottom-right;animation: uk-animation-slide-bottom-small'>
        
              <ul class='space-y-1'>";
              
              
          echo "<li> 
          <a href='{$this->DIR}/view_post/{$post_id}' class='flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
           <i class='uil-bullseye mr-1'></i> Open
          </a> 
      </li>";
          if ($follow->isFollowing($user_id)) {
            echo "<li> 
            <a href='#' class='flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
             <i class='uil-user-times mr-1'></i>  Unfollow
            </a> 
        </li>";
          }
          if ($settings->isBlocked($user_id) == false) {
            echo "<li> 
            <a href='#' data-getid='{$user_id}' data-username='{$universal->nameShortener($universal->GETsDetails($user_id, "username"), 20)}' class='flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
             <i class='uil-ban mr-1'></i> Block @{$universal->nameShortener($universal->GETsDetails($user_id, "username"), 12)}
            </a> 
        </li> ";
       }
          if ($taggings->AmITagged($post_id)) {
            echo "<li> 
            <a href='#' class='flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
             <i class='uil-tag-alt mr-1'></i> Untag
            </a> 
        </li>";
          }
          if ($share->AmIsharedTo($post_id)) {
            echo "<li> 
            <a href='#' class='flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
             <i class='uil-backspace mr-1'></i> Remove Share
            </a> 
        </li> ";
          }
          if ($share->AmIsharedBy($post_id)) {
            echo "<li> 
            <a href='#' class='flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
             <i class='uil-backspace mr-1'></i> Unshare
            </a> 
        </li> ";
          }
          echo "<li> 
          <a href='#'' data-link='{$universal->urlChecker($this->DIR)}/view_post/{$post_id}' class='flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
           <i class='uil-copy mr-1'></i>  Copy Link
          </a> 
      </li>";
      echo "</ul></div></div></div>";
          
          echo "<div uk-lightbox>"; 
          echo $Post->getDifferentPost($type, $post_id, $size);
          echo "</div><hr><div class='p_a p-4 space-y-3'><div class='p_do'>";
          echo "<div class='flex space-x-4 lg:font-bold'>";
          if($post_like->likedOrNot($post_id)){
            echo "<span class='p_unlike flex items-center space-x-2' data-description='Unlike'><i class='material-icons' style='color:red;'>favorite</i></span>";
          } else if ($post_like->likedOrNot($post_id) == false) {
            echo "<span class='p_like flex items-center space-x-2' data-description='Like'><i class='material-icons' style='color:red;'>favorite_border</i></span>";
          }
          echo "</div>";
          echo "<div class='p_bmrk_wra'>";
          if ($bookmark->bookmarkedOrNot($post_id)) {
            echo "<span class='p_unbookmark' data-description='Unbookmark'><i class='material-icons' style='color:blue;'>bookmark</i></span>";
          } else if ($bookmark->bookmarkedOrNot($post_id) == false) {
            echo "<span class='p_bookmark' data-description='Bookmark'><i class='material-icons' style='color:blue;'>bookmark_border</i></span>";
          }
          echo "</div>";
          echo "<div uk-toggle='target: #offcanvas-chat' class='p_send_wra'><span class='p_send' data-description='Share'><i class='fa fa-leaf' style='font-size: 24px; color:purple; top:-4px; position:relative;'></i></span></div>";
          echo "</div><div uk-toggle='target: #offcanvas-chat' class='p_did dark:text-gray-100'><span class='p_likes likes'><strong><i class='uil uil-comment-alt-heart' style='color:red;'></i> &nbsp". $post_like->getPostLikes($post_id) ." </strong>
          </strong></span>
          </div></div><hr>";
          
          echo "<div class='p_comments'><strong><i class='uil uil-comment-dots' style='color:blue;'></i> &nbsp&nbsp". $comment->getComments($post_id) ."</strong></div>";
          
          
          echo "</div>";

        }
        echo "<div class='post_end feed_inserted flex justify-center mt-6'>
        <a class='bg-white dark:bg-gray-900 font-semibold my-3 px-6 py-2 rounded-full shadow-md dark:bg-gray-800 dark:text-white'>
        Looks like you've reached the end</a></div>";
      }

    }

  }
?>
