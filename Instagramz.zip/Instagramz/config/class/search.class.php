<?php
  class search{

    protected $db;
    protected $DIR;

    public function __construct(){
      $db = N::_DB();
      $DIR = N::$DIR;

      $this->db = $db;
      $this->DIR = $DIR;
    }

    public function searchInstagram($value){
      $session = $_SESSION['id'];

      $universal = new universal;
      $avatar = new Avatar;
      $groups = new group;
      $Post = new post;
      $hashtag = new hashtag;

      echo "<h4 class='search_title'> Search Result </h4><ul>";

      $q1 = $this->db->prepare("SELECT id, username FROM users WHERE username LIKE :username ORDER BY id LIMIT 8");
      $q1->execute(array(":username" => "%$value%"));
      if ($q1->rowCount() > 0) {
        while ($r1 = $q1->fetch(PDO::FETCH_OBJ)) {
          $userid = $r1->id;
          $user = $r1->username;
          $none = '"none"';

          echo
            "<li><a href='{$this->DIR}/profile/{$user}'>
            <img src='{$this->DIR}/{$avatar->DisplayAvatar($userid)}' alt='' class='list-avatar'>
            <div class='list-name'>@". $universal->nameShortener($user, 30). " <img src='{$this->DIR}/images/".$universal->GETsDetails($userid, "bluetick").".png' style='width:15px; height:15px; display:inline-block;' onerror='this.style.display = ".$none."'/></div></a></li>";

        }
      }

      echo "</ul>";
      
      echo "<ul>";

      $tag = preg_replace("#[\#]#", "", $value);
      $q3 = $this->db->prepare("SELECT DISTINCT hashtag FROM hashtag WHERE hashtag LIKE :hashtag ORDER BY hashtag_id LIMIT 12");
      $q3->execute(array(":hashtag" => "%#$tag%"));
      if ($q3->rowCount() > 0) {
        while ($r3 = $q3->fetch(PDO::FETCH_OBJ)) {
          $hashname = $r3->hashtag;

          echo
            "<li><a href='{$this->DIR}/hashtag?tag=". substr($hashname, 1) ."'><div class='list-name'>". $universal->nameShortener($hashname, 30) ."</div>";
            // echo "<span class='s_d_light'>";
            // if ("#".$tag == $hashname) {
            //   echo $hashtag->noOfHashTags("$tag")." posts";
            // } else {
            //   echo "Working..";
            // }
            // echo "</span>
            echo "</a></li>";

        }
      }

      echo "</ul>";


    }

  }
?>
