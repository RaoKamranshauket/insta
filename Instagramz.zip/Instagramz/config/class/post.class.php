<?php
  class post{

     protected $db;
    protected $DIR;
    protected $gmail;
    protected $gmail_password;

    public function __construct(){
      $db = N::_DB();
      $DIR = N::$DIR;
      $GMAIL = N::$GMAIL;
      $GMAIL_PASS = N::$GMAIL_PASSWORD;

      $this->db = $db;
      $this->DIR = $DIR;
      $this->gmail = $GMAIL;
      $this->gmail_password = $GMAIL_PASS;
    }

    public function postCount($id){
      $query = $this->db->prepare("SELECT post_id FROM post WHERE user_id =:id AND post_of <> :grp");
      $query->execute(array(":id" => $id, ":grp" => "group"));
      $count = $query->rowCount();
      return $count;
    }

    public function getPost($post, $what){
      $query = $this->db->prepare("SELECT $what FROM post WHERE post_id = :post");
      $query->execute(array(":post" => $post));
      if ($query->rowCount() > 0) {
        $row = $query->fetch(PDO::FETCH_OBJ);
        return $row->$what;
      }
    }

    public function reportaccountnow($post){
      if(isset($_POST['submit'])){
 require 'phpmailer/PHPMailerAutoload.php';

 $mail = new PHPMailer;

 $mail->IsSMTP();
    $mail->Host='smtp.gmail.com';
    $mail->Port=587;
    $mail->SMTPAuth=true;
    $mail->SMTPSecure='tls';
    $mail->Username = $this->gmail;                 // SMTP username
        $mail->Password = $this->gmail_password; 

 $mail->setFrom = $this->gmail;
 $mail->addAddress('feyinani@gmail.com');

 $mail->isHTML(true);
 $mail->Subject='Tagopus Report';
 $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
        $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
        $mail->addEmbeddedImage('../../images/display logo22.png', 'te');
        $mail->addEmbeddedImage('../../images/email.png', 'logo');
        $mail->isHTML(true);  
 $mail->Body='<!DOCTYPE html>
 <html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
 <head>
     <meta charset="utf-8"> <!-- utf-8 works for most cases -->
     <meta name="viewport" content="width=device-width">
     <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Use the latest (edge) version of IE rendering engine -->
     <meta name="x-apple-disable-message-reformatting">  <!-- Disable auto-scale in iOS 10 Mail entirely -->
     <title></title> <!-- The title tag shows in email notifications, like Android 4.4. -->
 
     <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700" rel="stylesheet">
 
     <!-- CSS Reset : BEGIN -->
     <style>
 
         /* What it does: Remove spaces around the email design added by some email clients. */
         /* Beware: It can remove the padding / margin and add a background color to the compose a reply window. */
         html,
 body {
     margin: 0 auto !important;
     padding: 0 !important;
     height: 100% !important;
     width: 100% !important;
     background: #f1f1f1;
 }
 
 /* What it does: Stops email clients resizing small text. */
 * {
     -ms-text-size-adjust: 100%;
     -webkit-text-size-adjust: 100%;
 }
 
 /* What it does: Centers email on Android 4.4 */
 div[style*="margin: 16px 0"] {
     margin: 0 !important;
 }
 
 /* What it does: Stops Outlook from adding extra spacing to tables. */
 table,
 td {
     mso-table-lspace: 0pt !important;
     mso-table-rspace: 0pt !important;
 }
 
 /* What it does: Fixes webkit padding issue. */
 table {
     border-spacing: 0 !important;
     border-collapse: collapse !important;
     table-layout: fixed !important;
     margin: 0 auto !important;
 }
 
 /* What it does: Uses a better rendering method when resizing images in IE. */
 img {
     -ms-interpolation-mode:bicubic;
 }
 
 /* What it does: Prevents Windows 10 Mail from underlining links despite inline CSS. Styles for underlined links should be inline. */
 a {
     text-decoration: none;
 }
 
 /* What it does: A work-around for email clients meddling in triggered links. */
 *[x-apple-data-detectors],  /* iOS */
 .unstyle-auto-detected-links *,
 .aBn {
     border-bottom: 0 !important;
     cursor: default !important;
     color: inherit !important;
     text-decoration: none !important;
     font-size: inherit !important;
     font-family: inherit !important;
     font-weight: inherit !important;
     line-height: inherit !important;
 }
 
 /* What it does: Prevents Gmail from displaying a download button on large, non-linked images. */
 .a6S {
     display: none !important;
     opacity: 0.01 !important;
 }
 
 /* What it does: Prevents Gmail from changing the text color in conversation threads. */
 .im {
     color: inherit !important;
 }
 
 img.g-img + div {
     display: none !important;
 }
 
 /* What it does: Removes right gutter in Gmail iOS app: https://github.com/TedGoas/Cerberus/issues/89  */
 
 @media only screen and (min-device-width: 320px) and (max-device-width: 374px) {
     u ~ div .email-container {
         min-width: 320px !important;
     }
 }
 /* iPhone 6, 6S, 7, 8, and X */
 @media only screen and (min-device-width: 375px) and (max-device-width: 413px) {
     u ~ div .email-container {
         min-width: 375px !important;
     }
 }
 /* iPhone 6+, 7+, and 8+ */
 @media only screen and (min-device-width: 414px) {
     u ~ div .email-container {
         min-width: 414px !important;
     }
 }
 
 
     </style>
 
     <!-- CSS Reset : END -->
 
     <!-- Progressive Enhancements : BEGIN -->
     <style>
 
         .primary{
     background: #17bebb;
 }
 .bg_white{
     background: #ffffff;
 }
 .bg_light{
     background: #f7fafa;
 }
 .bg_black{
     background: #000000;
 }
 .bg_dark{
     background: rgba(0,0,0,.8);
 }
 .email-section{
     padding:2.5em;
 }
 
 /*BUTTON*/
 .btn{
     padding: 10px 15px;
     display: inline-block;
 }
 .btn.btn-primary{
     border-radius: 5px;
     background: #17bebb;
     color: #ffffff;
 }
 .btn.btn-white{
     border-radius: 5px;
     background: #ffffff;
     color: #000000;
 }
 .btn.btn-white-outline{
     border-radius: 5px;
     background: transparent;
     border: 1px solid #fff;
     color: #fff;
 }
 .btn.btn-black-outline{
     border-radius: 0px;
     background: transparent;
     border: 2px solid #000;
     color: #000;
     font-weight: 700;
 }
 .btn-custom{
     color: rgba(0,0,0,.3);
     text-decoration: underline;
 }
 
 h1,h2,h3,h4,h5,h6{
     font-family: "Poppins", sans-serif;
     color: #000000;
     margin-top: 0;
     font-weight: 400;
 }
 
 body{
     font-family: "Poppins", sans-serif;
     font-weight: 400;
     font-size: 15px;
     line-height: 1.8;
     color: rgba(0,0,0,.4);
 }
 
 a{
     color: #17bebb;
 }
 
 table{
 }
 /*LOGO*/
 
 .logo h1{
     margin: 0;
 }
 .logo h1 a{
     color: #17bebb;
     font-size: 24px;
     font-weight: 700;
     font-family: "Poppins", sans-serif;
 }
 
 /*HERO*/
 .hero{
     position: relative;
     z-index: 0;
 }
 
 .hero .text{
     color: rgba(0,0,0,.3);
 }
 .hero .text h2{
     color: #000;
     font-size: 34px;
     margin-bottom: 0;
     font-weight: 200;
     line-height: 1.4;
 }
 .hero .text h3{
     font-size: 24px;
     font-weight: 300;
 }
 .hero .text h2 span{
     font-weight: 600;
     color: #000;
 }
 
 .text-author{
     bordeR: 1px solid rgba(0,0,0,.05);
     max-width: 50%;
     margin: 0 auto;
     padding: 2em;
 }
 .text-author img{
     border-radius: 50%;
     padding-bottom: 20px;
 }
 .text-author h3{
     margin-bottom: 0;
 }
 ul.social{
     padding: 0;
 }
 ul.social li{
     display: inline-block;
     margin-right: 10px;
 }
 
 /*FOOTER*/
 
 .footer{
     border-top: 1px solid rgba(0,0,0,.05);
     color: rgba(0,0,0,.5);
 }
 .footer .heading{
     color: #000;
     font-size: 20px;
 }
 .footer ul{
     margin: 0;
     padding: 0;
 }
 .footer ul li{
     list-style: none;
     margin-bottom: 10px;
 }
 .footer ul li a{
     color: rgba(0,0,0,1);
 }
 
 
 @media screen and (max-width: 500px) {
 
 
 }
 
 
     </style>
 
 
 </head>
 
 <body width="100%" style="margin: 0; padding: 0 !important; mso-line-height-rule: exactly; background-color: #f1f1f1;">
     <center style="width: 100%; background-color: #f1f1f1;">
     <div style="display: none; font-size: 1px;max-height: 0px; max-width: 0px; opacity: 0; overflow: hidden; mso-hide: all; font-family: sans-serif;">
       &zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;
     </div>
     <div style="max-width: 600px; margin: 0 auto;" class="email-container">
         <!-- BEGIN BODY -->
       <table align="center" role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: auto;">
         <tr>
           <td valign="top" class="bg_white" style="padding: 1em 2.5em 0 2.5em;">
             <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
                 <tr>
                     <td class="logo" style="text-align: center;">
                     <img src="cid:logo" style="width: 150px; height: 60px;"/>
                       </td>
                       </tr>
                       </table>
                     </td>
                   </tr><!-- end tr -->
                   <tr>
                     <td valign="middle" class="hero bg_white" style="padding: 3em 0 2em 0;">
                       <img src="cid:mail" alt="" style="width: 100px; max-width: 200px; height: auto; margin: auto; display: block;">
                     </td>
                   </tr><!-- end tr -->
                   <tr>
                     <td valign="middle" class="hero bg_white" style="padding: 2em 0 4em 0;">
                       <table>
                         <tr>
                           <td>
                             <div class="text" style="padding: 0 2.5em; text-align: center;">
                               <h4>Hello Tagopus Admin,</h4>
                               <p>A Report has been made about an account, post or community. Please have a look and do the right thing.</p>
                               <h4 style="font-weight: bold;">'.$_POST['reportuser'].' <br>
                                '.$_POST['reportlink'].'<br>
                               '.$_POST['reportabout'].'</h4>

                             </div>
                           </td>
                         </tr>
                       </table>
                     </td>
                   </tr><!-- end tr -->
                 <!-- 1 Column Text + Button : END -->
                 </table>
                 
      
 
     </div>
   </center>
 </body>
 </html>';
 
 if(!$mail->send()){
  header('Location:'. DIR .'/welcome');
 }else{
 header('Location:'. DIR .'/welcome');

 }

}
    }



    public function getLink($link){
      if ($link != "") {
        include 'simple_html_dom.php';

        $content = file_get_html($link);

        foreach ($content->find('title') as $element) {
          $title = $element->plaintext;
        }

        $image = array();
        array_slice($content->find('img'), 0, 15);

        foreach($content->find('img') as $element){
      		if(filter_var($element->src, FILTER_VALIDATE_URL)){
      			list($width,$height) = getimagesize($element->src);
      			if($width>75 && $height>75){
      				$image[] =  $element->src;
      			}
      		}
      	}

        if (sizeof($image) == 0) {
          $image[0] = "{$this->DIR}/images/Default_Link_Cover/world.jpg";
        }

        $array = array(
          "title" => $title,
          "url"   => $link,
          "src"   => $image[0]
        );

        echo json_encode($array);
      }
    }

    public function addressN($add, $id){
      $universal = new universal;
      if ($add == '') {
        return  $add;
      } else {
        return "\u{1F4CD} $add";
      }
    }

    public function addressTitle($add, $id){
      $universal = new universal;
      if ($add == '') {
        return $universal->GETsDetails($id, "firstname")." ".$universal->GETsDetails($id, "surname");
      } else {
        return $add;
      }
    }

    public function postDetails($post, $what){
      $query = $this->db->prepare("SELECT $what FROM post WHERE post_id = :post LIMIT 1");
      $query->execute(array(":post" => $post));
      $row = $query->fetch(PDO::FETCH_OBJ);
      return $row->$what;
    }

    public function textPost($value, $tags, $font, $loc, $when, $grp){

      $universal = new universal;
      $noti = new notifications;
      $hashtag = new hashtag;
      $mention = new mention_class;

      $session = $_SESSION['id'];

      if ($when == "user") {
        $pquery = $this->db->prepare("INSERT INTO post (user_id, type, time, font_size, address) VALUES (:id, :type, now(), :size, :loc)");
        $pquery->execute(array(":id" => $session, ":type" => "text", ":size" => $font, ":loc" => $loc));
      } else if ($when == "group") {
        $pquery = $this->db->prepare("INSERT INTO post (user_id, type, post_of, grp_id, time, font_size, address) VALUES (:id, :type, :of, :grp, now(), :size, :loc)");
        $pquery->execute(array(":id" => $session, ":type" => "text", ":of" => "group", ":grp" => $grp, ":size" => $font, ":loc" => $loc));
      }

      $last_id = $this->db->lastInsertId();

      $tquery = $this->db->prepare("INSERT INTO text_post (post_id, text) VALUES (:post_id, :post)");
      $tquery->execute(array(":post_id" => $last_id, ":post" => $value));

      $mention->getMentions($value, $last_id);
      $hashtag->getHashtags($value, $last_id);

      if ($when == "user") {
        $array = explode(",", $tags);
        foreach ($array as $value) {
          if ($value != "") {
            $my = $universal->getIdFromGet($value);
            $fquery = $this->db->prepare("INSERT INTO taggings (post_id, taggings, taggings_id, taggings_time) VALUES (:post_id, :tags, :taggs_id, now())");
            $fquery->execute(array(":post_id" => $last_id, ":tags" => $value, ":taggs_id" => $my));
            $noti->actionNotify($my, $last_id, "tag");
          }
        }
      }

    }

    public function imagePost($file, $value, $tags, $font, $loc, $filter, $when, $grp){
      $session = $_SESSION['id'];

      $universal = new universal;
      $noti = new notifications;
      $hashtag = new hashtag;
      $mention = new mention_class;

      $name = $file['name'];
      $size = $file['size'];
      $tmp_name = $file['tmp_name'];
      $error = $file['error'];
      $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
      $allowed = array("jpg", "png", "gif", "jpeg");
      $font_size = preg_replace("#[^0-9]#i", "", $font);

      if (in_array($ext, $allowed)) {
        if ($error == 0) {
          $new_name = time().".".$ext;
          if (move_uploaded_file($tmp_name, "../../media/Instagram_".$new_name)) {

            if ($when == "user") {
              $query = $this->db->prepare("INSERT INTO post (user_id, type, time, font_size, address) VALUES (:user, :type, now(), :font, :loc)");
              $query->execute(array(":user" => $session, ":type" => "image", ":font" => $font_size, ":loc" => $loc));
            } else if ($when == "group") {
              $query = $this->db->prepare("INSERT INTO post (user_id, type, post_of, grp_id, time, font_size, address) VALUES (:user, :type, :of, :grp, now(), :font, :loc)");
              $query->execute(array(":user" => $session, ":type" => "image", ":of" => "group", ":grp" => $grp, ":font" => $font_size, ":loc" => $loc));
            }

            $last_id = $this->db->lastInsertId();

            $mention->getMentions($value, $last_id);
            $hashtag->getHashtags($value, $last_id);

            $iquery = $this->db->prepare("INSERT INTO image_post (post_id, image, about, filter) VALUES (:id, :image, :about, :fltr)");
            $iquery->execute(array(":id" => $last_id, ":image" => $new_name, ":about" => $value, ":fltr" => $filter));

            if ($when == "user") {
              $array = explode(",", $tags);
              foreach ($array as $value) {
                if ($value != "") {
                  $my = $universal->getIdFromGet($value);
                  $tquery = $this->db->prepare("INSERT INTO taggings (post_id, taggings, taggings_id, taggings_time) VALUES (:post_id, :tags, :taggs_id, now())");
                  $tquery->execute(array(":post_id" => $last_id, ":tags" => $value, ":taggs_id" => $my));
                  $noti->actionNotify($my, $last_id, "tag");
                }
              }
            }

          }
        }
      }
    }

    public function videoPost($file, $value, $tags, $font, $loc, $when, $grp){
      $session = $_SESSION['id'];

      $universal = new universal;
      $noti = new notifications;
      $hashtag = new hashtag;
      $mention = new mention_class;

      $name = $file['name'];
      $size = $file['size'];
      $tmp_name = $file['tmp_name'];
      $error = $file['error'];
      $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
      $allowed = array("mp4", "ogg");
      $font_size = preg_replace("#[^0-9]#i", "", $font);

      if (in_array($ext, $allowed)) {
        if ($error == 0) {
          if ($size <= 10485760) {
            $new_name = time().".".$ext;
            if (move_uploaded_file($tmp_name, "../../media/Instagram_".$new_name)) {

              if ($when == "user") {
                $query = $this->db->prepare("INSERT INTO post (user_id, type, time, font_size, address) VALUES (:user, :type, now(), :font, :loc)");
                $query->execute(array(":user" => $session, ":type" => "video", ":font" => $font_size, ":loc" => $loc));

              } else if ($when == "group") {
                $query = $this->db->prepare("INSERT INTO post (user_id, type, post_of, grp_id, time, font_size, address) VALUES (:user, :type, :of, :grp, now(), :font, :loc)");
                $query->execute(array(":user" => $session, ":type" => "video", ":of" => "group", ":grp" => $grp, ":font" => $font_size, ":loc" => $loc));
              }


              $last_id = $this->db->lastInsertId();

              $mention->getMentions($value, $last_id);
              $hashtag->getHashtags($value, $last_id);

              $iquery = $this->db->prepare("INSERT INTO video_post (post_id, video, about) VALUES (:id, :image, :about)");
              $iquery->execute(array(":id" => $last_id, ":image" => $new_name, ":about" => $value));

              if ($when == "user") {
                $array = explode(",", $tags);
                foreach ($array as $value) {
                  if ($value != "") {
                    $my = $universal->getIdFromGet($value);
                    $tquery = $this->db->prepare("INSERT INTO taggings (post_id, taggings, taggings_id, taggings_time) VALUES (:post_id, :tags, :taggs_id, now())");
                    $tquery->execute(array(":post_id" => $last_id, ":tags" => $value, ":taggs_id" => $my));
                    $noti->actionNotify($my, $last_id, "tag");
                  }
                }
              }

            }
          }
        }
      }
    }

    public function audioPost($file, $value, $tags, $font, $loc){
      $session = $_SESSION['id'];

      $universal = new universal;
      $noti = new notifications;
      $hashtag = new hashtag;
      $mention = new mention_class;

      $name = preg_replace("#[\'\"]#i", "", $file['name']);
      $size = $file['size'];
      $tmp_name = $file['tmp_name'];
      $error = $file['error'];
      $ext = strtolower(end(explode(".", $name)));
      $allowed = array("mp3");
      $font_size = preg_replace("#[^0-9]#i", "", $font);

      if (in_array($ext, $allowed)) {
        if ($error == 0) {
          $new_name = time().".".$ext;
          if (move_uploaded_file($tmp_name, "../../media/".$name)) {
            $query = $this->db->prepare("INSERT INTO post (user_id, type, time, font_size, address) VALUES (:user, :type, now(), :font, :loc)");
            $query->execute(array(":user" => $session, ":type" => "audio", ":font" => $font_size,":loc" => $loc));
            $last_id = $this->db->lastInsertId();

            $mention->getMentions($value, $last_id);
            $hashtag->getHashtags($value, $last_id);

            $iquery = $this->db->prepare("INSERT INTO audio_post (post_id, audio, about, audiovery) VALUES (:id, :image, :about, 'images/musicguildup.jpg')");
            $iquery->execute(array(":id" => $last_id, ":image" => $name, ":about" => $value));

            $array = explode(",", $tags);
            foreach ($array as $value) {
              if ($value != "") {
                $my = $universal->getIdFromGet($value);
                $tquery = $this->db->prepare("INSERT INTO taggings (post_id, taggings, taggings_id, taggings_time) VALUES (:post_id, :tags, :taggs_id, now())");
                $tquery->execute(array(":post_id" => $last_id, ":tags" => $value, ":taggs_id" => $my));
                $noti->actionNotify($my, $last_id, "tag");
              }
            }
          }
        } else {
          return "Error!!";
        }
      }
    }

    public function docPost($file, $value, $tags, $font, $loc, $when, $grp){
      $session = $_SESSION['id'];

      $universal = new universal;
      $noti = new notifications;
      $hashtag = new hashtag;
      $mention = new mention_class;

      $name = preg_replace("#[\'\"]#i", "", $file['name']);
      $size = $file['size'];
      $tmp_name = $file['tmp_name'];
      $error = $file['error'];
      $ext = strtolower(end(explode(".", $name)));
      $allowed = array("js", "css", "html", "txt", "php", "cpp", "py", "ini", "zip", "pdf");
      $font_size = preg_replace("#[^0-9]#i", "", $font);

      if (in_array($ext, $allowed)) {
        if ($error == 0) {
          if (move_uploaded_file($tmp_name, "../../media/".$name)) {

            if ($when == "user") {
              $query = $this->db->prepare("INSERT INTO post (user_id, type, time, font_size, address) VALUES (:user, :type, now(), :font, :loc)");
              $query->execute(array(":user" => $session, ":type" => "document", ":font" => $font_size, ":loc" => $loc));
            } else if ($when == "group") {
              $query = $this->db->prepare("INSERT INTO post (user_id, type, post_of, grp_id, time, font_size, address) VALUES (:user, :type, :of, :grp, now(), :font, :loc)");
              $query->execute(array(":user" => $session, ":type" => "document", ":of" => "group", ":grp" => $grp, ":font" => $font_size, ":loc" => $loc));
            }

            $last_id = $this->db->lastInsertId();

            $mention->getMentions($value, $last_id);
            $hashtag->getHashtags($value, $last_id);

            $iquery = $this->db->prepare("INSERT INTO doc_post (post_id, doc, about) VALUES (:id, :image, :about)");
            $iquery->execute(array(":id" => $last_id, ":image" => $name, ":about" => $value));

            if ($when == "user") {
              $array = explode(",", $tags);
              foreach ($array as $value) {
                if ($value != "") {
                  $my = $universal->getIdFromGet($value);
                  $tquery = $this->db->prepare("INSERT INTO taggings (post_id, taggings, taggings_id, taggings_time) VALUES (:post_id, :tags, :taggs_id, now())");
                  $tquery->execute(array(":post_id" => $last_id, ":tags" => $value, ":taggs_id" => $my));
                  $noti->actionNotify($my, $last_id, "tag");
                }
              }
            }

          }
        }
      }
    }

    public function locPost($src, $value, $tags, $font, $loc, $when, $grp){
      $session = $_SESSION['id'];

      $universal = new universal;
      $noti = new notifications;
      $hashtag = new hashtag;
      $mention = new mention_class;

      if ($when == "user") {
        $query = $this->db->prepare("INSERT INTO post (user_id, type, time, font_size, address) VALUES (:id, :type, now(), :font, :loc)");
        $query->execute(array(":id" => $session, ":type" => "location", ":font" => $font, ":loc" => $loc));
      } else if ($when == "group") {
        $query = $this->db->prepare("INSERT INTO post (user_id, type, post_of, grp_id, time, font_size, address) VALUES (:id, :type, :of, :grp, now(), :font, :loc)");
        $query->execute(array(":id" => $session, ":type" => "location", ":of" => "group", ":grp" => $grp, ":font" => $font, ":loc" => $loc));
      }


      $last_id = $this->db->lastInsertId();

      $mention->getMentions($value, $last_id);
      $hashtag->getHashtags($value, $last_id);

      $tquery = $this->db->prepare("INSERT INTO loc_post (post_id, loc, about) VALUES (:post_id, :loc, :about)");
      $tquery->execute(array(":post_id" => $last_id, ":loc" => $src, ":about" => $value));

      if ($when == "user") {
        $array = explode(",", $tags);
        foreach ($array as $value) {
          if ($value != "") {
            $my = $universal->getIdFromGet($value);
            $fquery = $this->db->prepare("INSERT INTO taggings (post_id, taggings, taggings_id, taggings_time) VALUES (:post_id, :tags, :taggs_id, now())");
            $fquery->execute(array(":post_id" => $last_id, ":tags" => $value, ":taggs_id" => $my));
            $noti->actionNotify($my, $last_id, "tag");
          }
        }
      }

    }

    public function linkPost($value, $tags, $font, $loc, $url, $title, $src, $when, $grp){
      $universal = new universal;
      $noti = new notifications;
      $hashtag = new hashtag;
      $mention = new mention_class;

      $session = $_SESSION['id'];

      if ($when == "user") {
        $pquery = $this->db->prepare("INSERT INTO post (user_id, type, time, font_size, address) VALUES (:id, :type, now(), :size, :loc)");
        $pquery->execute(array(":id" => $session, ":type" => "link", ":size" => $font, ":loc" => $loc));
      } else if ($when == "group") {
        $pquery = $this->db->prepare("INSERT INTO post (user_id, type, post_of, grp_id, time, font_size, address) VALUES (:id, :type, :of, :grp, now(), :size, :loc)");
        $pquery->execute(array(":id" => $session, ":type" => "link", ":of" => "group", ":grp" => $grp, ":size" => $font, ":loc" => $loc));
      }

      $last_id = $this->db->lastInsertId();

      $mention->getMentions($value, $last_id);
      $hashtag->getHashtags($value, $last_id);

      $tquery = $this->db->prepare("INSERT INTO link_post (post_id, text, link_url, link_title, link_src) VALUES (:post_id, :text, :url, :title, :src)");
      $tquery->execute(array(":post_id" => $last_id, ":text" => $value, ":url" => $url, ":title" => $title, ":src" => $src));

      if ($when == "user") {
        $array = explode(",", $tags);
        foreach ($array as $value) {
          if ($value != "") {
            $my = $universal->getIdFromGet($value);
            $fquery = $this->db->prepare("INSERT INTO taggings (post_id, taggings, taggings_id, taggings_time) VALUES (:post_id, :tags, :taggs_id, now())");
            $fquery->execute(array(":post_id" => $last_id, ":tags" => $value, ":taggs_id" => $my));
            $noti->actionNotify($my, $last_id, "tag");
          }
        }
      }

    }

    public function isPostLengthy($text){
      if(strlen($text) > 1000){
        return true;
      } else {
        return false;
      }
    }

    public function addMoreClass($text){
      if(strlen($text) > 1000){
        return "isLengthy";
      }
    }

    public function addMoreLink($text, $class){
      if(strlen($text) > 1000){
        return "<a href='#' style='color:purple' class='hashtag {$class}'>.. Load more</a>";
      }
    }

    public function getDifferentPost($type, $post_id, $size){
      $universal = new universal;
      $Time = new time;
      $hashtag = new hashtag;
      $mention = new mention_class;

      if ($universal->isLoggedIn()) { $session = $_SESSION['id']; }

      if ($type == "text") {
        $tquery = $this->db->prepare("SELECT text FROM text_post WHERE post_id = :post");
        $tquery->execute(array(":post" => $post_id));
        while ($trow = $tquery->fetch(PDO::FETCH_OBJ)) {
          $text = nl2br(trim($trow->text));
          $text = $hashtag->toHashtag($text, "post");
          // $text = $hashtag->lineBreakHashtag($text, "post");
          $text = $mention->mention($text);
          $text = $universal->toAbsURL($text);
          return

            "<div class='p-3 border-b dark:border-gray-700 e ". self::addMoreClass($text) ."' spellcheck='false'>
            <span class='p_text hyphenate' style='font-size: {$size}px'>{$text}</span>
            </div>
            <div class='load_more_div'>". self::addMoreLink($text, "load_more_text") ."</div>";
        }
      } else if ($type == "image") {
        $tquery = $this->db->prepare("SELECT image, about, filter FROM image_post WHERE post_id = :post");
        $tquery->execute(array(":post" => $post_id));
        while ($trow = $tquery->fetch(PDO::FETCH_OBJ)) {
          $text = nl2br(trim($trow->about));
          $img = $trow->image;
          $filter = $trow->filter;
          $text = $hashtag->toHashtag($text, "post");
          $text = $mention->mention($text);
          $text = $universal->toAbsURL($text);
          $by = self::postDetails($post_id, "user_id");
          $time = self::postDetails($post_id, "time");
          if($by == $session){ $u = "You"; } else { $u = $universal->GETsDetails($by, "username"); }
          return
            "<div class='p-3 border-b dark:border-gray-700". self::addMoreClass($text) ."' style='font-size: {$size}px' spellcheck='false'>{$text}</div>
            <div class='load_more_div load_more_not_text_div'>". self::addMoreLink($text, "load_more_not_text") ."</div>
            <div class='post_marginer'></div>
            <img src='{$this->DIR}/media/Instagram_{$img}' alt='Instagram_{$img}' class='w-full object-cover' data-postid='{$post_id}' data-imgby='{$u}' data-time='{$Time->timeAgo($time)}' data-filter='{$filter}'>";
        }
      } else if ($type == "video") {
        $tquery = $this->db->prepare("SELECT video, about FROM video_post WHERE post_id = :post");
        $tquery->execute(array(":post" => $post_id));
        while ($trow = $tquery->fetch(PDO::FETCH_OBJ)) {
          $text = nl2br(trim($trow->about));
          $vid = $trow->video;
          $text = $hashtag->toHashtag($text, "post");
          $text = $mention->mention($text);
          $text = $universal->toAbsURL($text);
           return
             "<div class='p-3 border-b dark:border-gray-700". self::addMoreClass($text) ."' style='font-size: {$size}px' spellcheck='false'><p>$text</p></div>
              <div class='load_more_div load_more_not_text_div'>". self::addMoreLink($text, "load_more_not_text") ."</div>
              <div class='post_marginer'></div>
              <div class='p_vid w-full h-full'>
              <video src='{$this->DIR}/media/Instagram_{$vid}' autoplay></video>
              <span class='p_vid_pp_large'><i class='material-icons'>play_arrow</i></span>
              <span class='p_vid_cur p_vid_time_teaser'>0:00</span>
              <span class='p_vid_time_bubble'>0:00</span><div class='p_vid_ctrls'><div class='p_vid_seek'>
              <input class='p_vid_seek_range' type='range' name='p_vid_range' value='0' min='0' max='100' step='1'>
              </div><span class='p_vid_pp'><i class='material-icons'>play_arrow</i></span>
              <div class='p_vid_duration'><span class='p_vid_cur'>0:00</span><span class='p_vid_dur_sep'>/</span>
              <span class='p_vid_dur'>0:00</span></div><div class='p_vid_vol_div'>
              <input type='range' name='p_vid_vol_slider' value='100' min='0' max='100' step='1'>
              </div><span class='p_vid_vup'><i class='material-icons'>volume_up</i></span>
              <div class='p_vid_pbr_div'><ul><li data-pbr='2'>2x</li><li data-pbr='1.75'>1.75x</li>
              <li data-pbr='1.5'>1.5x</li><li data-pbr='1.25'>1.25x</li><li data-pbr='1' class='pbr_class'>1x</li>
              <li data-pbr='0.75'>0.75x</li><li data-pbr='0.5'>0.5x</li></ul></div>
              <span class='p_vid_setting'>1x</span><div class='p_vid_shadow'></div></div></div>";
        }
      } else if ($type == "audio") {
        $tquery = $this->db->prepare("SELECT audio, about, audiovery FROM audio_post WHERE post_id = :post");
        $tquery->execute(array(":post" => $post_id));
        while ($trow = $tquery->fetch(PDO::FETCH_OBJ)) {
          $text = nl2br(trim($trow->about));
          $audio = $trow->audio;
          $audiovery = $trow->audiovery;
          $text = $hashtag->toHashtag($text, "post");
          $text = $mention->mention($text);
          $text = $universal->toAbsURL($text);
          return
            "<div class='p-3 border-b dark:border-gray-700". self::addMoreClass($text) ."' style='font-size: {$size}px' spellcheck='false'><p>$text</p></div>
            <div class='load_more_div load_more_not_text_div'>". self::addMoreLink($text, "load_more_not_text") ."</div>
            <div class='post_marginer'></div>
            
            <div class='music-container'>

      <div class='img-container'>
        <img src='{$this->DIR}/{$audiovery}' style='width:80px; height:80px;'/>
      </div>
      <div class='navigation'>
        
      <div class='p_aud' data-song='{$this->DIR}/media/{$audio}'>
        
      
   
            <span class='p_aud_time_bubble'>0:00</span><div class='p_aud_ctrls'><div class='p_aud_info'>
            <span class='p_aud_name'></span>
            </div><span class='p_aud_pp'><i class='material-icons'>play_arrow</i></span>
            <div class='p_aud_seek'><input class='p_aud_seek_range' type='range' name='p_aud_seek_range' value='0' min='0' max='100' step='1'>
            </div><div style='left:-90px;' class='p_aud_duration'><span class='p_aud_cur'>0:00</span><span class='p_aud_dur_sep'>/</span>
            <span class='p_aud_dur'>0:00</span></div><div class='p_aud_vol_div' style='left:120px'>
            <input type='range' name='p_aud_vol_slider' value='100' min='0' max='100' step='1'>
            </div><span class='p_aud_vup'  style='top:3px;
             left: 30px; position:relative;'><i class='material-icons'>volume_up</i></span></div></div></div> </div>";
        }
      } else if ($type == "document") {
        $tquery = $this->db->prepare("SELECT doc, about FROM doc_post WHERE post_id = :post");
        $tquery->execute(array(":post" => $post_id));
        while ($trow = $tquery->fetch(PDO::FETCH_OBJ)) {
          $text = nl2br(trim($trow->about));
          $doc = $trow->doc;
          $text = $hashtag->toHashtag($text, "post");
          $text = $mention->mention($text);
          $text = $universal->toAbsURL($text);
          return
            "<div class='p_abt e ". self::addMoreClass($text) ."' style='font-size: {$size}px' spellcheck='false'><p>{$text}</p></div>
            <div class='load_more_div load_more_not_text_div'>". self::addMoreLink($text, "load_more_not_text") ."</div>
            <div class='post_marginer'></div>
            <div class='p_doc'>
            <div class='p_doc_img'><img src='{$this->DIR}/images/Default_Doc_Cover/20151125_5655085dda190-210x210.png' alt='Document'>
            </div><div class='p_doc_info'>
            <a href='{$this->DIR}/media/{$doc}' class='p_doc_link' download='{$doc}'>". substr($doc, 0, 50) ."</a>
            </div></div>";
        }
      } else if ($type == "location") {
        $tquery = $this->db->prepare("SELECT loc, about FROM loc_post WHERE post_id = :post");
        $tquery->execute(array(":post" => $post_id));
        while ($trow = $tquery->fetch(PDO::FETCH_OBJ)) {
          $loc = $trow->loc;
          $text = nl2br(trim($trow->about));
          $text = $hashtag->toHashtag($text, "post");
          $text = $mention->mention($text);
          $text = $universal->toAbsURL($text);
          return
            "<div class='p_abt e ". self::addMoreClass($text) ."' style='font-size: {$size}px' spellcheck='false'><p>$text</p></div>
            <div class='load_more_div load_more_not_text_div'>". self::addMoreLink($text, "load_more_not_text") ."</div>
            <div class='post_marginer'></div>
            <div class='p_loc'>
            <img src='{$loc}' class='p_loc_img'></div>";
        }
      } else if ($type == "link") {
        $tquery = $this->db->prepare("SELECT text, link_url, link_title, link_src FROM link_post WHERE post_id = :post");
        $tquery->execute(array(":post" => $post_id));
        while ($trow = $tquery->fetch(PDO::FETCH_OBJ)) {
          $text = $trow->text;
          $url = $trow->link_url;
          $title = $trow->link_title;
          $src = $trow->link_src;
          $text = $hashtag->toHashtag($text, "post");
          $text = $mention->mention($text);
          $text = $universal->toAbsURL($text);
          return
            "<div class='p_abt e ". self::addMoreClass($text) ."' style='font-size: {$size}px' spellcheck='false'><p>$text</p></div>
            <div class='load_more_div load_more_not_text_div'>". self::addMoreLink($text, "load_more_not_text") ."</div>
            <div class='post_marginer'></div>
            <div class='p_link'><div class='p_link_img'>
            <img src='{$src}' alt=''></div><div class='p_link_info'>
            <div class='p_link_title'><a href='{$url}' target='_blank'>". substr($title, 0, 50) ."</a>
            </div><div class='p_link_url'>
            <a href='{$url}' target='_blank'>". substr($url, 0, 90) ."</a>
            </div></div></div>";
        }
      }
    }

    public function getHomePost($way, $l, $count){
      $avatar = new Avatar;
      $universal = new universal;
      $Time = new time;
      $post_like = new postLike;
      $bookmark = new bookmark;
      $taggings = new taggings;
      $share = new share;
      $comment = new postComment;
      $follow = new follow_system;
      $settings = new settings;

      $session = $_SESSION['id'];

      if ($l == "nolimit") { 
        $query = $this->db->prepare("SELECT post.post_id, post.user_id, post.type, post.time, post.font_size, post.address FROM post, follow_system WHERE follow_system.follow_by = :by AND follow_system.follow_to = post.user_id AND post.post_of <> :grp ORDER BY post.time DESC LIMIT 10");
        $query->execute(array(":by" => $session, ":grp" => "group"));

      } else if ($l == "limit") {

        $start = intval($count);
        $end = $start+10;

        $query = $this->db->prepare("SELECT post.post_id, post.user_id, post.type, post.time, post.font_size, post.address FROM post, follow_system WHERE follow_system.follow_by = :by AND follow_system.follow_to = post.user_id AND post.post_of <> :grp AND post.post_id < :start ORDER BY post.time DESC LIMIT 5");
        $query->execute(array(":by" => $session, ":grp" => "group", ":start" => $start));
      }

      if ($query->rowCount() > 0) {
        while ($row = $query->fetch(PDO::FETCH_OBJ)) {
          $post_id = $row->post_id;
          $user_id = $row->user_id;
          $type = $row->type;
          $time = $row->time;
          $size = $row->font_size;
          $address = $row->address;
          $none = '"none"';

          echo "<div class='card lg:mx-0 uk-animation-slide-bottom-small posts home_posts inst' data-postid='{$post_id}' data-time='{$time}'>";
          if ($way == "get") {
            echo "<div class='flex justify-between items-center lg:p-4 p-2.5'>
            <div class='flex flex-1 items-center space-x-4'>
                <img class='bg-gray-200 border border-white rounded-full w-10 h-10' src='{$this->DIR}/{$avatar->DisplayAvatar($user_id)}' alt='{$universal->GETsDetails($user_id, "username")}'>
";
          } else if ($way == "direct") {
            echo "<div class='flex justify-between items-center lg:p-4 p-2.5'>
            <div class='flex flex-1 items-center space-x-4'>
                <img class='bg-gray-200 border border-white rounded-full w-10 h-10' src='". DIR ."/{$avatar->GETsAvatar($user_id)}' alt='{$universal->GETsDetails($user_id, "username")}'s avatar'>";
          }
          echo "<div class='flex-1 capitalize'>
          <div class='font-semibold'>
          <a href='". DIR ."/profile/{$universal->GETsDetails($user_id, "username")}' data-getid='{$user_id}' class='text-black dark:text-gray-100'> ".$universal->GETsDetails($user_id, "firstname")." ".$universal->GETsDetails($user_id, "surname")."</a> <img src='{$this->DIR}/images/".$universal->GETsDetails($user_id, "bluetick").".png' style='width:15px; height:15px; display:inline-block;' onerror='this.style.display = ".$none."'/>
          </div>
          <div class='text-gray-700 flex items-center space-x-2'>
          <div class='p_i_1'>";
          echo"@<a href='". DIR ."/profile/{$universal->GETsDetails($user_id, "username")}' data-getid='{$user_id}' class='text-black dark:text-gray-100' title='{$universal->GETsDetails($user_id, "username")}'>{$universal->nameShortener($universal->GETsDetails($user_id, "username"), 25)}</a><span title='". self::addressTitle($address, $user_id) ."'>
          </div>";
          echo "<p>. ". $Time->timeAgo($time) ."</p> <ion-icon name='people'></ion-icon></div>";
          echo self::addressN($address, $user_id);
          echo "</span>";

          echo " </div></div><div>"; 
          
              
              
        
      
      echo "</div></div>";
          
          echo "<div>"; 
          echo self::getDifferentPost($type, $post_id, $size);
          echo "</div><div class='p_a p-4 space-y-3'><div class='p_do'>";
          echo "<div class='flex space-x-4 lg:font-bold'>";
         
          echo "</div>";
          echo "</div><div uk-toggle='target: #offcanvas-chat' class='p_did dark:text-gray-100'>
          </div></div><hr>";
          echo "<div class='flex items-center space-x-3 pt-2' > 
            ";
          echo "
      </div>";
          echo "<div class='p_comments'><strong><i class='uil uil-comment-dots' style='color:blue;'></i> &nbsp&nbsp". $comment->getComments($post_id) ."</strong></div>";
          // echo "<div class='p_cit'><div class='p_cit_img'>";
          // if ($way == "get") {
          //   echo "<img src='{$this->DIR}/{$avatar->DisplayAvatar($session)}' alt='{$universal->GETsDetails($session, "username")}'>";
          // } else if ($way == "direct") {
          //   echo "<img src='". DIR ."/{$avatar->GETsAvatar($session)}' alt='{$universal->GETsDetails($session, "username")}'s avatar'>";
          // }
          // echo "</div><div class='p_cit_area'>";
          // echo "<textarea class='textarea_toggle comment_teaser' name='post_comment' spellcheck='false' placeholder='Wanna comment?'></textarea>";
          // // echo "<span data-description='Add emojis'><i class='material-icons'>sentiment_very_satisfied</i></span>";
          // echo "</div><div class='p_cit_tool' data-postid='{$post_id}'>
          // <span class='c_sticker c_sticker_trailer' data-description='Add sticker'><i class='material-icons'>face</i></span>
          // <form class='p_comment_form' enctype='multipart/form-data' action=''>
          // <input type='file' class='p_comm_file_teaser {$post_id}' name='p_comm_file' id='p_comm_file' data-postid='{$post_id}'>
          // <label for='p_comm_file' class='p_cit_more' data-description='Attach a file'><i class='material-icons'>attach_file</i></label>
          // </form>
          // </div></div>";
          echo "</div>";

        }
        // echo "<div class='feed_inserted'></div>";
        echo "<div class='post_end feed_inserted flex justify-center mt-6'>
        <a class='bg-white dark:bg-gray-900 font-semibold my-3 px-6 py-2 rounded-full shadow-md dark:bg-gray-800 dark:text-white'>
        Looks like you've reached the end</a></div>";
      } else if ($query->rowCount() == 0) {
        if ($way == "direct") {
          echo "<div class='home_last_mssg'>
            <img src='{$this->DIR}/images/no post.gif'>
            <span>Looks like you're new, Follow some to fill up your feed or post from above options</span>
          </div>";
        }
      }

    }

    public function getUserPost($id, $way, $count){
      $avatar = new Avatar;
      $universal = new universal;
      $Time = new time;
      $post_like = new postLike;
      $bookmark = new bookmark;
      $taggings = new taggings;
      $share = new share;
      $comment = new postComment;
      $follow = new follow_system;
      $settings = new settings;

      if ($universal->isLoggedIn()) {
        $session = $_SESSION['id'];
      }

      if ($way == "direct") {
        $get_id = $universal->getIdFromGet($_GET['u']);
      } else if ($way == "ajax") {
        $get_id = $id;
      }

      if ($way == "direct") {
        $pquery = $this->db->prepare("SELECT * FROM post WHERE user_id = :id AND post_of <> :grp ORDER BY time DESC LIMIT 5");
        $pquery->execute(array(":id" => $id, ":grp" => "group"));

      } else if ($way == "ajax") {
        $start = intval($count);
        $end = $start+10;

        $pquery = $this->db->prepare("SELECT * FROM post WHERE user_id = :id AND post_of <> :grp AND post_id < :start ORDER BY time DESC LIMIT 5");
        $pquery->execute(array(":id" => $id, ":grp" => "group", ":start" => $start));

      }

      $count = $pquery->rowCount();
      if ($count == 0) {
        if ($way == "direct") {
          echo "<div class='home_last_mssg pro_last_mssg'><img src='{$this->DIR}/images/no post.gif'><span>";
          if ($universal->MeOrNot($id)) {
            echo "You have no post";
          } else {
            echo $universal->GETsDetails($id, "username")." has no post";
          }
          echo "</span></div>";
        }
      } else if ($count != 0) {

        while ($prow = $pquery->fetch(PDO::FETCH_OBJ)) {
          $post_id = $prow->post_id;
          $user_id = $prow->user_id;
          $type = $prow->type;
          $time = $prow->time;
          $size = $prow->font_size;
          $address = $prow->address;
          $none = '"none"';

          echo "<div class='posts user_posts inst card lg:mx-0 uk-animation-slide-bottom-small' data-postid='{$post_id}' data-time='{$time}'>";
         
            echo "<div class='flex justify-between items-center lg:p-4 p-2.5'>
            <div class='flex flex-1 items-center space-x-4'>
            <img class='bg-gray-200 border border-white rounded-full w-10 h-10' src='{$this->DIR}/". $avatar->DisplayAvatar($user_id) ."' alt='{$universal->GETsDetails($user_id, "username")}'s avatar'>";
                
          echo "<div class='flex-1 capitalize'>
          <div class='font-semibold'>
          <a href='". DIR ."/profile/{$universal->GETsDetails($user_id, "username")}' data-getid='{$user_id}' class='text-black dark:text-gray-100'> ".$universal->GETsDetails($user_id, "firstname")." ".$universal->GETsDetails($user_id, "surname")."</a> <img src='{$this->DIR}/images/".$universal->GETsDetails($user_id, "bluetick").".png' style='width:15px; height:15px; display:inline-block;' onerror='this.style.display = ".$none."'/><img src='{$this->DIR}/images/".$universal->GETsDetails($user_id, "emote").".gif' style='width:25px; height:25px; display:inline-block;' onerror='this.style.display = ".$none."'/>
          </div>
          <div class='text-gray-700 flex items-center space-x-2'>
          <div class='p_i_1'>";
          echo"@<a href='". DIR ."/profile/{$universal->GETsDetails($user_id, "username")}' data-getid='{$user_id}' class='text-black dark:text-gray-100' title='{$universal->GETsDetails($user_id, "username")}'>{$universal->nameShortener($universal->GETsDetails($user_id, "username"), 25)}</a><span title='". self::addressTitle($address, $user_id) ."'>
          </div>";
          echo "<p>. ". $Time->timeAgo($time) ."</p> <ion-icon name='people'></ion-icon></div>";
          echo self::addressN($address, $user_id);
          echo "</span>";

          echo " </div></div><div>"; 
          
          echo "<span class='exp_p_menu'><i class='icon-feather-more-horizontal text-2xl hover:bg-gray-200 rounded-full p-2 transition -mr-1 dark:hover:bg-gray-700'></i></span>
          <div class='p_options bg-white w-56 shadow-md mx-auto p-2 mt-12 rounded-md text-gray-500 hidden text-base border border-gray-100 dark:bg-gray-900 dark:text-gray-100 dark:border-gray-700' 
          uk-drop='mode: click;pos: bottom-right;animation: uk-animation-slide-bottom-small'>
        
              <ul class='space-y-1'>";
              
              
          echo "<li> 
          <a href='{$this->DIR}/view_post/{$post_id}' class='flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
           <i class='uil-bullseye mr-1'></i> Open
          </a> 
      </li>";
      if ($universal->MeOrNot($user_id)) {
        echo "<li><a href='#' class='delete_post flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
        <i class='uil-trash mr-1'></i> Delete post</a></li>";
      } else if ($universal->MeOrNot($user_id) == false) {
        if ($follow->isFollowing($user_id)) {
          echo "<li><a href='#' class='simple_unfollow flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'><i class='uil-user-times mr-1'></i> Unfollow</li>";
        }
        if ($settings->isBlocked($user_id) == false) {
          echo "<li><a href='#' data-getid='{$user_id}' data-username='{$universal->nameShortener($universal->GETsDetails($user_id, "username"), 20)}' class='block flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'><i class='uil-ban mr-1'></i> Block {$universal->nameShortener($universal->GETsDetails($user_id, "username"), 12)}</a></li>";
        }
      }
          if ($taggings->AmITagged($post_id)) {
            echo "<li><a href='#' class='untag flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
            <i class='uil-pricetag-alt mr-1'></i> Untag</a></li>";
          }
          if ($share->AmIsharedTo($post_id)) {
            echo "<li> 
            <a href='#' class='unshare flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
             <i class='uil-flower mr-1'></i> Remove Share
            </a> 
        </li> ";
          }
          if ($share->AmIsharedBy($post_id)) {
            echo "<li> 
            <a href='#' uk-toggle='target: #offcanvas-chat' class='un__share flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
             <i class='uil-flower mr-1'></i> Unshare
            </a> 
        </li> ";
          }
          echo "<li> 
          <a href='#'' data-link='{$universal->urlChecker($this->DIR)}/view_post/{$post_id}' class='p_copy_link flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
           <i class='uil-copy mr-1'></i>  Copy Link
          </a> 
      </li>";
      echo "</ul></div></div></div>";
          
          echo "<div>"; 
          echo self::getDifferentPost($type, $post_id, $size);
          echo "</div><div class='p_a p-4 space-y-3'><div class='p_do'>";
          echo "<div class='flex space-x-4 lg:font-bold'>";
          if($post_like->likedOrNot($post_id)){
            echo "<span class='p_unlike flex items-center space-x-2' data-description='Unlike'><i class='material-icons' style='color:red;'>favorite</i></span>";
          } else if ($post_like->likedOrNot($post_id) == false) {
            echo "<span class='p_like flex items-center space-x-2' data-description='Like'><i class='material-icons' style='color:red;'>favorite_border</i></span>";
          }
          echo "</div>";
          echo "<div class='p_bmrk_wra'>";
          if ($bookmark->bookmarkedOrNot($post_id)) {
            echo "<span class='p_unbookmark' data-description='Unbookmark'><i class='material-icons' style='color:blue;'>bookmark</i></span>";
          } else if ($bookmark->bookmarkedOrNot($post_id) == false) {
            echo "<span class='p_bookmark' data-description='Bookmark'><i class='material-icons' style='color:blue;'>bookmark_border</i></span>";
          }
          echo "</div>";
          echo "<div uk-toggle='target: #offcanvas-chat' class='p_send_wra'><span class='p_send' data-description='Share'><i class='fa fa-leaf' style='font-size: 24px; color:purple; top:-4px; position:relative;'></i></span></div>";
          echo "</div><div uk-toggle='target: #offcanvas-chat' class='p_did dark:text-gray-100'><span class='p_likes likes' style='font-size:10px;'><strong><i class='uil uil-comment-alt-heart' style='color:red;'></i> &nbsp". $post_like->getPostLikes($post_id) ." </strong>
          </strong></span>
          </div></div><hr>";
          echo "<div class='flex items-center space-x-3 pt-2' > 
                                  
          <div class='dark:text-gray-100 p_tags' uk-toggle='target: #offcanvas-chat' >
          &nbsp&nbsp&nbsp<i class='uil uil-pricetag-alt' style='color:blue;'></i> <strong > ". $taggings->getTaggings($post_id) ."</strong>
          </div>";
          echo "<div class='dark:text-gray-100'>
          <i class='fa fa-leaf' style='color:purple;'></i> <strong>". $share->getShares($post_id) ."</strong>
          </div>
      </div>";
          echo "<div class='p_comments'><strong><i class='uil uil-comment-dots' style='color:blue;'></i> &nbsp&nbsp". $comment->getComments($post_id) ."</strong></div>";
          // echo "<div class='p_cit'><div class='p_cit_img'>";
          // if ($way == "get") {
          //   echo "<img src='{$this->DIR}/{$avatar->DisplayAvatar($session)}' alt='{$universal->GETsDetails($session, "username")}'>";
          // } else if ($way == "direct") {
          //   echo "<img src='". DIR ."/{$avatar->GETsAvatar($session)}' alt='{$universal->GETsDetails($session, "username")}'s avatar'>";
          // }
          // echo "</div><div class='p_cit_area'>";
          // echo "<textarea class='textarea_toggle comment_teaser' name='post_comment' spellcheck='false' placeholder='Wanna comment?'></textarea>";
          // // echo "<span data-description='Add emojis'><i class='material-icons'>sentiment_very_satisfied</i></span>";
          // echo "</div><div class='p_cit_tool' data-postid='{$post_id}'>
          // <span class='c_sticker c_sticker_trailer' data-description='Add sticker'><i class='material-icons'>face</i></span>
          // <form class='p_comment_form' enctype='multipart/form-data' action=''>
          // <input type='file' class='p_comm_file_teaser {$post_id}' name='p_comm_file' id='p_comm_file' data-postid='{$post_id}'>
          // <label for='p_comm_file' class='p_cit_more' data-description='Attach a file'><i class='material-icons'>attach_file</i></label>
          // </form>
          // </div></div>";
          echo "</div>";

        }
        // echo "<div class='feed_inserted'></div>";
        echo "<div class='post_end feed_inserted flex justify-center mt-6'>
        <a class='bg-white dark:bg-gray-900 font-semibold my-3 px-6 py-2 rounded-full shadow-md dark:bg-gray-800 dark:text-white'>
        Looks like you've reached the end</a></div>";
      }

    }

    public function getTaggedPost($id, $way, $count){
      $avatar = new Avatar;
      $universal = new universal;
      $Time = new time;
      $post_like = new postLike;
      $bookmark = new bookmark;
      $taggings = new taggings;
      $share = new share;
      $comment = new postComment;
      $follow = new follow_system;
      $settings = new settings;

      $session = $_SESSION['id'];

      if ($way == "direct") {
        $get_id = $universal->getIdFromGet($_GET['u']);
      } else if ($way == "ajax") {
        $get_id = $id;
      }

      if ($way == "direct") {
        $query = $this->db->prepare("SELECT post.post_id, post.user_id, post.type, post.time, post.font_size, post.address, taggings.tagging_id FROM post, taggings WHERE post.post_id = taggings.post_id AND taggings.taggings_id = :by AND post.post_of <> :grp ORDER BY taggings.tagging_id DESC LIMIT 5");
        $query->execute(array(":by" => $id, ":grp" => "group"));

      } else if ($way == "ajax") {

        $start = intval($count);
        $end = $start+10;

        $query = $this->db->prepare("SELECT post.post_id, post.user_id, post.type, post.time, post.font_size, post.address, taggings.tagging_id FROM post, taggings WHERE post.post_id = taggings.post_id AND taggings.taggings_id = :by AND post.post_of <> :grp AND taggings.tagging_id < :start ORDER BY taggings.tagging_id DESC LIMIT 5");
        $query->execute(array(":by" => $id, ":grp" => "group", ":start" => $start));

      }

      if ($query->rowCount() == 0) {
        if ($way == "direct") {
          echo "<div class='home_last_mssg pro_last_mssg'><img src='{$this->DIR}/images/no post.gif'><span>";
          if ($universal->MeOrNot($id)) {
            echo "You are not tagged in any of the post";
          } else {
            echo $universal->GETsDetails($id, "username")." is not tagged in any of the post";
          }
          echo "</span></div>";
        }

      } else if ($query->rowCount() > 0) {
        while ($row = $query->fetch(PDO::FETCH_OBJ)) {
          $post_id = $row->post_id;
          $user_id = $row->user_id;
          $type = $row->type;
          $time = $row->time;
          $size = $row->font_size;
          $address = $row->address;
          $tag_id = $row->tagging_id;
          $none = '"none"';

          echo "<div class='posts tag_posts inst card lg:mx-0 uk-animation-slide-bottom-small' data-postid='{$post_id}' data-type='{$type}' data-tagid='{$tag_id}'>";
         
            echo "<div class='flex justify-between items-center lg:p-4 p-2.5'>
            <div class='flex flex-1 items-center space-x-4'>
            <img class='bg-gray-200 border border-white rounded-full w-10 h-10' src='{$this->DIR}/". $avatar->DisplayAvatar($user_id) ."' alt='{$universal->GETsDetails($user_id, "username")}'s avatar'>";
                
            echo "<div class='flex-1 capitalize'>
            <div class='font-semibold'>
            <a href='". DIR ."/profile/{$universal->GETsDetails($user_id, "username")}' data-getid='{$user_id}' class='text-black dark:text-gray-100'> ".$universal->GETsDetails($user_id, "firstname")." ".$universal->GETsDetails($user_id, "surname")."</a> <img src='{$this->DIR}/images/".$universal->GETsDetails($user_id, "bluetick").".png' style='width:15px; height:15px; display:inline-block;' onerror='this.style.display = ".$none."'/>
            </div>
            <div class='text-gray-700 flex items-center space-x-2'>
            <div class='p_i_1'>";
            echo"@<a href='". DIR ."/profile/{$universal->GETsDetails($user_id, "username")}' data-getid='{$user_id}' class='text-black dark:text-gray-100' title='{$universal->GETsDetails($user_id, "username")}'>{$universal->nameShortener($universal->GETsDetails($user_id, "username"), 25)}</a><span title='". self::addressTitle($address, $user_id) ."'>
            </div>";
            echo "<p>. ". $Time->timeAgo($time) ."</p> <ion-icon name='people'></ion-icon></div>";
            echo self::addressN($address, $user_id);
            echo "</span>";
  
            echo " </div></div><div>"; 
            
            echo "<span class='exp_p_menu'><i class='icon-feather-more-horizontal text-2xl hover:bg-gray-200 rounded-full p-2 transition -mr-1 dark:hover:bg-gray-700'></i></span>
            <div class='p_options bg-white w-56 shadow-md mx-auto p-2 mt-12 rounded-md text-gray-500 hidden text-base border border-gray-100 dark:bg-gray-900 dark:text-gray-100 dark:border-gray-700' 
            uk-drop='mode: click;pos: bottom-right;animation: uk-animation-slide-bottom-small'>
          
                <ul class='space-y-1'>";
                
                
            echo "<li> 
            <a href='{$this->DIR}/view_post/{$post_id}' class='flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
             <i class='uil-bullseye mr-1'></i> Open
            </a> 
        </li>";
            if ($follow->isFollowing($user_id)) {
              echo "<li><a href='#' class='simple_unfollow flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
              <i class='uil-user-times mr-1'></i> Unfollow</a></li>";
            }
            if ($settings->isBlocked($user_id) == false) {
              echo "<li> 
              <a href='#' data-getid='{$user_id}' data-username='{$universal->nameShortener($universal->GETsDetails($user_id, "username"), 20)}' class='block flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
               <i class='uil-ban mr-1'></i> Block @{$universal->nameShortener($universal->GETsDetails($user_id, "username"), 12)}
              </a> 
          </li> ";
         }
            if ($taggings->AmITagged($post_id)) {
              echo "<li><a href='#' class='untag flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
              <i class='uil-pricetag-alt mr-1'></i> Untag</a></li>";
            }
            if ($share->AmIsharedTo($post_id)) {
              echo "<li> 
              <a href='#' class='unshare flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
               <i class='uil-flower mr-1'></i> Remove Share
              </a> 
          </li> ";
            }
            if ($share->AmIsharedBy($post_id)) {
              echo "<li> 
              <a href='#' uk-toggle='target: #offcanvas-leaf' class='un__share flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
               <i class='uil-flower mr-1'></i> Unshare
              </a> 
          </li> ";
            }
            echo "<li> 
            <a href='#'' data-link='{$universal->urlChecker($this->DIR)}/view_post/{$post_id}' class='p_copy_link flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
             <i class='uil-copy mr-1'></i>  Copy Link
            </a> 
        </li>";
        echo "</ul></div></div></div>";
            
            echo "<div>"; 
            echo self::getDifferentPost($type, $post_id, $size);
            echo "</div><div class='p_a p-4 space-y-3'><div class='p_do'>";
            echo "<div class='flex space-x-4 lg:font-bold'>";
            if($post_like->likedOrNot($post_id)){
              echo "<span class='p_unlike flex items-center space-x-2' data-description='Unlike'><i class='material-icons' style='color:red;'>favorite</i></span>";
            } else if ($post_like->likedOrNot($post_id) == false) {
              echo "<span class='p_like flex items-center space-x-2' data-description='Like'><i class='material-icons stopl' style='color:red;'>favorite_border</i></span>";
            }
            echo "</div>";
            echo "<div class='p_bmrk_wra'>";
            if ($bookmark->bookmarkedOrNot($post_id)) {
              echo "<span class='p_unbookmark' data-description='Unbookmark'><i class='material-icons' style='color:blue;'>bookmark</i></span>";
            } else if ($bookmark->bookmarkedOrNot($post_id) == false) {
              echo "<span class='p_bookmark' data-description='Bookmark'><i class='material-icons' style='color:blue;'>bookmark_border</i></span>";
            }
            echo "</div>";
            echo "<div uk-toggle='target: #offcanvas-chat' class='p_send_wra'><span class='p_send' data-description='Share'><i class='fa fa-leaf' style='font-size: 24px; color:purple; top:-4px; position:relative;'></i></span></div>";
            echo "</div><div uk-toggle='target: #offcanvas-chat' class='p_did dark:text-gray-100'><span class='p_likes likes'><strong><i class='uil uil-comment-alt-heart' style='color:red;'></i> &nbsp". $post_like->getPostLikes($post_id) ." </strong>
            </strong></span>
            </div></div><hr>";
            echo "<div class='flex items-center space-x-3 pt-2' > 
                                    
            <div class='dark:text-gray-100 p_tags' uk-toggle='target: #offcanvas-chat' >
            &nbsp&nbsp&nbsp<i class='uil uil-pricetag-alt' style='color:blue;'></i> <strong > ". $taggings->getTaggings($post_id) ."</strong>
            </div>";
            echo "<div class='dark:text-gray-100'>
            <i class='fa fa-leaf' style='color:purple;'></i> <strong>". $share->getShares($post_id) ."</strong>
            </div>
        </div>";
            echo "<div class='p_comments'><strong><i class='uil uil-comment-dots' style='color:blue;'></i> &nbsp&nbsp". $comment->getComments($post_id) ."</strong></div>";
            // echo "<div class='p_cit'><div class='p_cit_img'>";
          // if ($way == "get") {
          //   echo "<img src='{$this->DIR}/{$avatar->DisplayAvatar($session)}' alt='{$universal->GETsDetails($session, "username")}'>";
          // } else if ($way == "direct") {
          //   echo "<img src='". DIR ."/{$avatar->GETsAvatar($session)}' alt='{$universal->GETsDetails($session, "username")}'s avatar'>";
          // }
          // echo "</div><div class='p_cit_area'>";
          // echo "<textarea class='textarea_toggle comment_teaser' name='post_comment' spellcheck='false' placeholder='Wanna comment?'></textarea>";
          // // echo "<span data-description='Add emojis'><i class='material-icons'>sentiment_very_satisfied</i></span>";
          // echo "</div><div class='p_cit_tool' data-postid='{$post_id}'>
          // <span class='c_sticker c_sticker_trailer' data-description='Add sticker'><i class='material-icons'>face</i></span>
          // <form class='p_comment_form' enctype='multipart/form-data' action=''>
          // <input type='file' class='p_comm_file_teaser {$post_id}' name='p_comm_file' id='p_comm_file' data-postid='{$post_id}'>
          // <label for='p_comm_file' class='p_cit_more' data-description='Attach a file'><i class='material-icons'>attach_file</i></label>
          // </form>
          // </div></div>";
          echo "</div>";

        }
        // echo "<div class='feed_inserted'></div>";
        echo "<div class='post_end feed_inserted flex justify-center mt-6'>
        <a class='bg-white dark:bg-gray-900 font-semibold my-3 px-6 py-2 rounded-full shadow-md dark:bg-gray-800 dark:text-white'>
        Looks like you've reached the end</a></div>";
      }

    }



    


    public function getBookmarksPost($way, $count){
      $avatar = new Avatar;
      $universal = new universal;
      $Time = new time;
      $post_like = new postLike;
      $bookmark = new bookmark;
      $taggings = new taggings;
      $share = new share;
      $comment = new postComment;
      $follow = new follow_system;
      $groups = new group;
      $settings = new settings;

      $session = $_SESSION['id'];

      if ($way == "direct") {
        $query = $this->db->prepare("SELECT post.post_id, post.user_id, post.type, post.post_of, post.grp_id, post.time, post.font_size, post.address, bookmarks.bkmrk_id FROM post, bookmarks WHERE bookmarks.user_id = :by AND bookmarks.post_id = post.post_id ORDER BY bookmarks.bkmrk_id DESC LIMIT 5");
        $query->execute(array(":by" => $session));


      } else if ($way == "ajax") {

        $start = intval($count);
        $end = $start+10;

        $query = $this->db->prepare("SELECT post.post_id, post.user_id, post.type, post.post_of, post.grp_id, post.time, post.font_size, post.address, bookmarks.bkmrk_id FROM post, bookmarks WHERE bookmarks.user_id = :by AND bookmarks.post_id = post.post_id AND bookmarks.bkmrk_id < :start ORDER BY bookmarks.bkmrk_id DESC LIMIT 5");
        $query->execute(array(":by" => $session, ":start" => $start));

      }

      if ($query->rowCount() == 0) {
        if ($way == "direct") {
          echo "<div class='home_last_mssg pro_last_mssg'><img src='{$this->DIR}/images/no post.gif'>
          <span>You have no bookmarked posts</span></div>";
        }
      } else if ($query->rowCount() > 0) {
        while ($row = $query->fetch(PDO::FETCH_OBJ)) {
          $post_id = $row->post_id;
          $user_id = $row->user_id;
          $type = $row->type;
          $time = $row->time;
          $size = $row->font_size;
          $address = $row->address;
          $of = $row->post_of;
          $grp = $row->grp_id;
          $bk = $row->bkmrk_id;
          $none = '"none"';

          echo "<div class='posts bkmrk_posts inst card lg:mx-0 uk-animation-slide-bottom-small' data-postid='{$post_id}' data-type='{$type}' data-bookmarkid='{$bk}'>";
         
            echo "<div class='flex justify-between items-center lg:p-4 p-2.5'>
            <div class='flex flex-1 items-center space-x-4'>
            <img class='bg-gray-200 border border-white rounded-full w-10 h-10' src='{$this->DIR}/". $avatar->DisplayAvatar($user_id) ."' alt='{$universal->GETsDetails($user_id, "username")}'s avatar'>";
                
            echo "<div class='flex-1 capitalize'>
            <div class='font-semibold'>
            <a href='". DIR ."/profile/{$universal->GETsDetails($user_id, "username")}' data-getid='{$user_id}' class='text-black dark:text-gray-100'> ".$universal->GETsDetails($user_id, "firstname")." ".$universal->GETsDetails($user_id, "surname")."</a> <img src='{$this->DIR}/images/".$universal->GETsDetails($user_id, "bluetick").".png' style='width:15px; height:15px; display:inline-block;' onerror='this.style.display = ".$none."'/>
            </div>
            <div class='text-gray-700 flex items-center space-x-2'>
            <div class='p_i_1'>";
            echo"@<a href='". DIR ."/profile/{$universal->GETsDetails($user_id, "username")}' data-getid='{$user_id}' class='text-black dark:text-gray-100' title='{$universal->GETsDetails($user_id, "username")}'>{$universal->nameShortener($universal->GETsDetails($user_id, "username"), 25)}</a><span title='". self::addressTitle($address, $user_id) ."'>
            </div>";
            echo "<p>. ". $Time->timeAgo($time) ."</p> <ion-icon name='people'></ion-icon></div>";
            echo self::addressN($address, $user_id);
            echo "</span>";
  
            echo " </div></div><div>"; 
            
            echo "<span class='exp_p_menu'><i class='icon-feather-more-horizontal text-2xl hover:bg-gray-200 rounded-full p-2 transition -mr-1 dark:hover:bg-gray-700'></i></span>
            <div class='p_options bg-white w-56 shadow-md mx-auto p-2 mt-12 rounded-md text-gray-500 hidden text-base border border-gray-100 dark:bg-gray-900 dark:text-gray-100 dark:border-gray-700' 
            uk-drop='mode: click;pos: bottom-right;animation: uk-animation-slide-bottom-small'>
          
                <ul class='space-y-1'>";
                
                
            echo "<li> 
            <a href='{$this->DIR}/view_post/{$post_id}' class='flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
             <i class='uil-bullseye mr-1'></i> Open
            </a> 
        </li>";
            if ($follow->isFollowing($user_id)) {
              echo "<li><a href='#' class='simple_unfollow flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
              <i class='uil-user-times mr-1'></i> Unfollow</a></li>";
            }
            if ($settings->isBlocked($user_id) == false) {
              echo "<li> 
              <a href='#' data-getid='{$user_id}' data-username='{$universal->nameShortener($universal->GETsDetails($user_id, "username"), 20)}' class='block flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
               <i class='uil-ban mr-1'></i> Block @{$universal->nameShortener($universal->GETsDetails($user_id, "username"), 12)}
              </a> 
          </li> ";
         }
            if ($taggings->AmITagged($post_id)) {
              echo "<li><a href='#' class='untag flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
              <i class='uil-pricetag-alt mr-1'></i> Untag</a></li>";
            }
            if ($share->AmIsharedTo($post_id)) {
              echo "<li> 
              <a href='#' class='unshare flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
               <i class='uil-flower mr-1'></i> Remove Share
              </a> 
          </li> ";
            }
            if ($share->AmIsharedBy($post_id)) {
              echo "<li> 
              <a href='#' uk-toggle='target: #offcanvas-leaf' class='un__share flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
               <i class='uil-flower mr-1'></i> Unshare
              </a> 
          </li> ";
            }
            echo "<li> 
            <a href='#'' data-link='{$universal->urlChecker($this->DIR)}/view_post/{$post_id}' class='p_copy_link flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
             <i class='uil-copy mr-1'></i>  Copy Link
            </a> 
        </li>";
        echo "</ul></div></div></div>";
            
            echo "<div>"; 
            echo self::getDifferentPost($type, $post_id, $size);
            echo "</div><div class='p_a p-4 space-y-3'><div class='p_do'>";
            echo "<div class='flex space-x-4 lg:font-bold'>";
            if($post_like->likedOrNot($post_id)){
              echo "<span class='p_unlike flex items-center space-x-2' data-description='Unlike'><i class='material-icons' style='color:red;'>favorite</i></span>";
            } else if ($post_like->likedOrNot($post_id) == false) {
              echo "<span class='p_like flex items-center space-x-2' data-description='Like'><i class='material-icons stopl' style='color:red;'>favorite_border</i></span>";
            }
            echo "</div>";
            echo "<div class='p_bmrk_wra'>";
            if ($bookmark->bookmarkedOrNot($post_id)) {
              echo "<span class='p_unbookmark' data-description='Unbookmark'><i class='material-icons' style='color:blue;'>bookmark</i></span>";
            } else if ($bookmark->bookmarkedOrNot($post_id) == false) {
              echo "<span class='p_bookmark' data-description='Bookmark'><i class='material-icons' style='color:blue;'>bookmark_border</i></span>";
            }
            echo "</div>";
            echo "<div uk-toggle='target: #offcanvas-chat' class='p_send_wra'><span class='p_send' data-description='Share'><i class='fa fa-leaf' style='font-size: 24px; color:purple; top:-4px; position:relative;'></i></span></div>";
            echo "</div><div uk-toggle='target: #offcanvas-chat' class='p_did dark:text-gray-100'><span class='p_likes likes'><strong><i class='uil uil-comment-alt-heart' style='color:red;'></i> &nbsp". $post_like->getPostLikes($post_id) ." </strong>
            </strong></span>
            </div></div><hr>";
            echo "<div class='flex items-center space-x-3 pt-2' > 
                                    
            <div class='dark:text-gray-100 p_tags' uk-toggle='target: #offcanvas-chat' >
            &nbsp&nbsp&nbsp<i class='uil uil-pricetag-alt' style='color:blue;'></i> <strong > ". $taggings->getTaggings($post_id) ."</strong>
            </div>";
            echo "<div class='dark:text-gray-100'>
            <i class='fa fa-leaf' style='color:purple;'></i> <strong>". $share->getShares($post_id) ."</strong>
            </div>
        </div>";
            echo "<div class='p_comments'><strong><i class='uil uil-comment-dots' style='color:blue;'></i> &nbsp&nbsp". $comment->getComments($post_id) ."</strong></div>";
            // echo "<div class='p_cit'><div class='p_cit_img'>";
          // if ($way == "get") {
          //   echo "<img src='{$this->DIR}/{$avatar->DisplayAvatar($session)}' alt='{$universal->GETsDetails($session, "username")}'>";
          // } else if ($way == "direct") {
          //   echo "<img src='". DIR ."/{$avatar->GETsAvatar($session)}' alt='{$universal->GETsDetails($session, "username")}'s avatar'>";
          // }
          // echo "</div><div class='p_cit_area'>";
          // echo "<textarea class='textarea_toggle comment_teaser' name='post_comment' spellcheck='false' placeholder='Wanna comment?'></textarea>";
          // // echo "<span data-description='Add emojis'><i class='material-icons'>sentiment_very_satisfied</i></span>";
          // echo "</div><div class='p_cit_tool' data-postid='{$post_id}'>
          // <span class='c_sticker c_sticker_trailer' data-description='Add sticker'><i class='material-icons'>face</i></span>
          // <form class='p_comment_form' enctype='multipart/form-data' action=''>
          // <input type='file' class='p_comm_file_teaser {$post_id}' name='p_comm_file' id='p_comm_file' data-postid='{$post_id}'>
          // <label for='p_comm_file' class='p_cit_more' data-description='Attach a file'><i class='material-icons'>attach_file</i></label>
          // </form>
          // </div></div>";
          echo "</div>";

        }
        // echo "<div class='feed_inserted'></div>";
        echo "<div class='post_end feed_inserted flex justify-center mt-6'>
        <a class='bg-white dark:bg-gray-900 font-semibold my-3 px-6 py-2 rounded-full shadow-md dark:bg-gray-800 dark:text-white'>
        Looks like you've reached the end</a></div>";
      }

    }



    

    public function getSharedPost($id, $way, $count){
      $avatar = new Avatar;
      $universal = new universal;
      $Time = new time;
      $post_like = new postLike;
      $bookmark = new bookmark;
      $taggings = new taggings;
      $share = new share;
      $comment = new postComment;
      $follow = new follow_system;
      $settings = new settings;
      $groups = new group;

      $session = $_SESSION['id'];
      if ($way == "direct") {
        $get_id = $universal->getIdFromGet($_GET['u']);
      } else if ($way == "ajax") {
        $get_id = $id;
      }

      if ($way == "direct") {
        $query = $this->db->prepare("SELECT * FROM post, shares WHERE post.post_id = shares.post_id AND shares.share_to = :user ORDER BY shares.share_id DESC LIMIT 5");
        $query->execute(array(":user" => $id));

      } else if ($way == "ajax") {

        $start = intval($count);
        $end = $start+10;

        $query = $this->db->prepare("SELECT * FROM post, shares WHERE post.post_id = shares.post_id AND shares.share_to = :user AND shares.share_id < :start ORDER BY shares.share_id DESC LIMIT 5");
        $query->execute(array(":user" => $id, ":start" => $start));

      }

      if ($query->rowCount() == 0) {
        if ($way == "direct") {
          echo "<div class='home_last_mssg pro_last_mssg'><img src='{$this->DIR}/images/no post.gif'><span>";
          if ($universal->MeOrNot($id)) {
            echo "No one shared posts with you";
          } else {
            echo "No one shared posts with ".$universal->GETsDetails($id, "username");
          }
          echo "</span></div>";
        }
      } else if ($query->rowCount() > 0) {
        while ($row = $query->fetch(PDO::FETCH_OBJ)) {
          $post_id = $row->post_id;
          $share_id = $row->share_id;
          $shareby = $row->share_by;
          $sharetime = $row->share_time;
          $user_id = $row->user_id;
          $type = $row->type;
          $time = $row->time;
          $size = $row->font_size;
          $address = $row->address;
          $of = $row->post_of;
          $grp = $row->grp_id;
          $none = '"none"';

        
         
          echo "<div class='posts inst share_posts card lg:mx-0 uk-animation-slide-bottom-small' data-postid='{$post_id}' data-type='{$type}' data-shareid='{$share_id}'>";
          echo "<div class='post_share_info'>Post Shared by <i class='uil uil-user' style='color: red;'></i> <a href='{$this->DIR}/profile/{$universal->GETsDetails($shareby, "username")}' title='{$universal->GETsDetails($shareby, "username")}'>";
          if ($shareby == $session) { echo "You"; } else { echo $universal->nameShortener($universal->GETsDetails($shareby, "username"), 20); }
          echo "</a> <span><i class='uil uil-schedule' style='color: blue;'></i> {$Time->timeAgo($sharetime)}</span></div>";
          echo "<div class='flex justify-between items-center lg:p-4 p-2.5'>
          <div class='flex flex-1 items-center space-x-4'>
          <img class='bg-gray-200 border border-white rounded-full w-10 h-10' src='{$this->DIR}/". $avatar->DisplayAvatar($user_id) ."' alt='{$universal->GETsDetails($user_id, "username")}'s avatar'>";
              
          echo "<div class='flex-1 capitalize'>
          <div class='font-semibold'>
          <a href='". DIR ."/profile/{$universal->GETsDetails($user_id, "username")}' data-getid='{$user_id}' class='text-black dark:text-gray-100'> ".$universal->GETsDetails($user_id, "firstname")." ".$universal->GETsDetails($user_id, "surname")."</a> <img src='{$this->DIR}/images/".$universal->GETsDetails($user_id, "bluetick").".png' style='width:15px; height:15px; display:inline-block;' onerror='this.style.display = ".$none."'/>
          </div>
          <div class='text-gray-700 flex items-center space-x-2'>
          <div class='p_i_1'>";
          echo"@<a href='". DIR ."/profile/{$universal->GETsDetails($user_id, "username")}' data-getid='{$user_id}' class='text-black dark:text-gray-100' title='{$universal->GETsDetails($user_id, "username")}'>{$universal->nameShortener($universal->GETsDetails($user_id, "username"), 25)}</a><span title='". self::addressTitle($address, $user_id) ."'>
          </div>";
          echo "<p>. ". $Time->timeAgo($time) ."</p> <ion-icon name='people'></ion-icon></div>";
          echo self::addressN($address, $user_id);
          echo "</span>";

          echo " </div></div><div>"; 
          
          echo "<span class='exp_p_menu'><i class='icon-feather-more-horizontal text-2xl hover:bg-gray-200 rounded-full p-2 transition -mr-1 dark:hover:bg-gray-700'></i></span>
          <div class='p_options bg-white w-56 shadow-md mx-auto p-2 mt-12 rounded-md text-gray-500 hidden text-base border border-gray-100 dark:bg-gray-900 dark:text-gray-100 dark:border-gray-700' 
          uk-drop='mode: click;pos: bottom-right;animation: uk-animation-slide-bottom-small'>
        
              <ul class='space-y-1'>";
              
              
          echo "<li> 
          <a href='{$this->DIR}/view_post/{$post_id}' class='flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
           <i class='uil-bullseye mr-1'></i> Open
          </a> 
      </li>";
          if ($follow->isFollowing($user_id)) {
            echo "<li><a href='#' class='simple_unfollow flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
            <i class='uil-user-times mr-1'></i> Unfollow</a></li>";
          }
          if ($settings->isBlocked($user_id) == false) {
            echo "<li> 
            <a href='#' data-getid='{$user_id}' data-username='{$universal->nameShortener($universal->GETsDetails($user_id, "username"), 20)}' class='block flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
             <i class='uil-ban mr-1'></i> Block @{$universal->nameShortener($universal->GETsDetails($user_id, "username"), 12)}
            </a> 
        </li> ";
       }
          if ($taggings->AmITagged($post_id)) {
            echo "<li><a href='#' class='untag flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
            <i class='uil-pricetag-alt mr-1'></i> Untag</a></li>";
          }
          if ($share->AmIsharedTo($post_id)) {
            echo "<li> 
            <a href='#' class='unshare flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
             <i class='uil-flower mr-1'></i> Remove Share
            </a> 
        </li> ";
          }
          if ($share->AmIsharedBy($post_id)) {
            echo "<li> 
            <a href='#' uk-toggle='target: #offcanvas-leaf' class='un__share flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
             <i class='uil-flower mr-1'></i> Unshare
            </a> 
        </li> ";
          }
          echo "<li> 
          <a href='#'' data-link='{$universal->urlChecker($this->DIR)}/view_post/{$post_id}' class='p_copy_link flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800'>
           <i class='uil-copy mr-1'></i>  Copy Link
          </a> 
      </li>";
      echo "</ul></div></div></div>";
          
          echo "<div>"; 
          echo self::getDifferentPost($type, $post_id, $size);
          echo "</div><div class='p_a p-4 space-y-3'><div class='p_do'>";
          echo "<div class='flex space-x-4 lg:font-bold'>";
          if($post_like->likedOrNot($post_id)){
            echo "<span class='p_unlike flex items-center space-x-2' data-description='Unlike'><i class='material-icons' style='color:red;'>favorite</i></span>";
          } else if ($post_like->likedOrNot($post_id) == false) {
            echo "<span class='p_like flex items-center space-x-2' data-description='Like'><i class='material-icons stopl' style='color:red;'>favorite_border</i></span>";
          }
          echo "</div>";
          echo "<div class='p_bmrk_wra'>";
          if ($bookmark->bookmarkedOrNot($post_id)) {
            echo "<span class='p_unbookmark' data-description='Unbookmark'><i class='material-icons' style='color:blue;'>bookmark</i></span>";
          } else if ($bookmark->bookmarkedOrNot($post_id) == false) {
            echo "<span class='p_bookmark' data-description='Bookmark'><i class='material-icons' style='color:blue;'>bookmark_border</i></span>";
          }
          echo "</div>";
          echo "<div uk-toggle='target: #offcanvas-chat' class='p_send_wra'><span class='p_send' data-description='Share'><i class='fa fa-leaf' style='font-size: 24px; color:purple; top:-4px; position:relative;'></i></span></div>";
          echo "</div><div uk-toggle='target: #offcanvas-chat' class='p_did dark:text-gray-100'><span class='p_likes likes'><strong><i class='uil uil-comment-alt-heart' style='color:red;'></i> &nbsp". $post_like->getPostLikes($post_id) ." </strong>
          </strong></span>
          </div></div><hr>";
          echo "<div class='flex items-center space-x-3 pt-2' > 
                                  
          <div class='dark:text-gray-100 p_tags' uk-toggle='target: #offcanvas-chat' >
          &nbsp&nbsp&nbsp<i class='uil uil-pricetag-alt' style='color:blue;'></i> <strong > ". $taggings->getTaggings($post_id) ."</strong>
          </div>";
          echo "<div class='dark:text-gray-100'>
          <i class='fa fa-leaf' style='color:purple;'></i> <strong>". $share->getShares($post_id) ."</strong>
          </div>
      </div>";
          echo "<div class='p_comments'><strong><i class='uil uil-comment-dots' style='color:blue;'></i> &nbsp&nbsp". $comment->getComments($post_id) ."</strong></div>";
          // echo "<div class='p_cit'><div class='p_cit_img'>";
        // if ($way == "get") {
        //   echo "<img src='{$this->DIR}/{$avatar->DisplayAvatar($session)}' alt='{$universal->GETsDetails($session, "username")}'>";
        // } else if ($way == "direct") {
        //   echo "<img src='". DIR ."/{$avatar->GETsAvatar($session)}' alt='{$universal->GETsDetails($session, "username")}'s avatar'>";
        // }
        // echo "</div><div class='p_cit_area'>";
        // echo "<textarea class='textarea_toggle comment_teaser' name='post_comment' spellcheck='false' placeholder='Wanna comment?'></textarea>";
        // // echo "<span data-description='Add emojis'><i class='material-icons'>sentiment_very_satisfied</i></span>";
        // echo "</div><div class='p_cit_tool' data-postid='{$post_id}'>
        // <span class='c_sticker c_sticker_trailer' data-description='Add sticker'><i class='material-icons'>face</i></span>
        // <form class='p_comment_form' enctype='multipart/form-data' action=''>
        // <input type='file' class='p_comm_file_teaser {$post_id}' name='p_comm_file' id='p_comm_file' data-postid='{$post_id}'>
        // <label for='p_comm_file' class='p_cit_more' data-description='Attach a file'><i class='material-icons'>attach_file</i></label>
        // </form>
        // </div></div>";
        echo "</div>";

      }
      // echo "<div class='feed_inserted'></div>";
      echo "<div class='post_end feed_inserted flex justify-center mt-6'>
      <a class='bg-white dark:bg-gray-900 font-semibold my-3 px-6 py-2 rounded-full shadow-md dark:bg-gray-800 dark:text-white'>
      Looks like you've reached the end</a></div>";
    }

  }

    public function getPhotosPost($id){
      $universal = new universal;
      $like = new postLike;
      $comment = new postComment;
      $Time = new time;

      $session = $_SESSION['id'];

      $query = $this->db->prepare("SELECT post.post_id, post.user_id, image_post.image, image_post.filter, post.time FROM post, image_post WHERE post.user_id = :user AND post.type = :type AND post.post_id = image_post.post_id AND post.post_of <> :grp ORDER BY post.time DESC");
      $query->execute(array(":user" => $id, ":type" => "image", ":grp" => "group"));

      $count = $query->rowCount();
      if ($count == 0) {
        echo "
        <div>
                                <div class=''>
                                <img src='{$this->DIR}/images/needs/noimage.gif'><strong><span>@";
        if ($universal->MeOrNot($id)) { echo "You have no photos"; } else { echo $universal->GETsDetails($id, "username")." got no photos"; }
        echo "</span></strong></div></div>";
      } else if ($count > 0) {
        while ($row = $query->fetch(PDO::FETCH_OBJ)) {
          $post_id = $row->post_id;
          $user_id = $row->user_id;
          $image = $row->image;
          $time = $row->time;
          $filter = $row->filter;
          if ($user_id == $session) { $r = "You"; } else { $r = $universal->GETsDetails($user_id, "username"); }
          echo "
          <div>
                                  <div class='post_photos bg-green-400 max-w-full lg:h-44 h-36 rounded-lg relative overflow-hidden shadow uk-transition-toggle'>
                                  <img src='{$this->DIR}/media/Instagram_{$image}";  echo"' alt='' data-postid='{$post_id}' data-imgby='{$r}' data-time='{$Time->timeAgo($time)}' data-filter='{$filter}' class='w-full h-full absolute object-cover inset-0 {$filter}'>
                                  <div class='-bottom-12 absolute bg-gradient-to-b from-transparent h-1/2 to-gray-800 uk-transition-slide-bottom-small w-full'></div>
                                  <div class='absolute bottom-0 w-full p-3 text-white uk-transition-slide-bottom-small'>
                                  <div class='post_p_info flex justify-between text-xs'>
                              <a><i class='material-icons' style='color:red; font-size:30px;'>favorite</i>&nbsp{$like->simpleGetPostLikes($post_id)}</a>
                              <a><i class='uil uil-comment-dots' style='color:blue; font-size:30px;'></i> &nbsp{$comment->simpleGetComments($post_id)}</a>
                              </div>
                         </div></div></div>";
        }
        // echo "<div class='post_end'>Looks like you've reached the end</div>";
      }

    }

    public function getVideosPost($id){
      $avatar = new Avatar;
      $universal = new universal;
      $Time = new time;
      $post_like = new postLike;
      $bookmark = new bookmark;
      $taggings = new taggings;
      $share = new share;
      $comment = new postComment;

      $get_id = $universal->getIdFromGet($_GET['u']);
      $session = $_SESSION['id'];

      $query = $this->db->prepare("SELECT post.post_id, post.user_id, video_post.video FROM post, video_post WHERE post.user_id = :user AND post.type = :type AND post.post_id = video_post.post_id AND post.post_of <> :grp ORDER BY post.time DESC");
      $query->execute(array(":user" => $id, ":type" => "video", ":grp" => "group"));
      $count = $query->rowCount();
      if ($count == 0) {
        echo "<div><img src='{$this->DIR}/images/needs/noimage.gif'><strong><span>@";
        if ($universal->MeOrNot($id)) {
          echo "You have no videos";
        } else {
          echo $universal->GETsDetails($id, "username")." has no videos</span></strong></div>";
        }
      } else if ($query->rowCount() > 0) {

        while ($row = $query->fetch(PDO::FETCH_OBJ)) {
          $post_id = $row->post_id;
          $user_id = $row->user_id;
          $video = $row->video;

          echo "<div class='p_vid video_vid user_post_vid'>
            <video src='{$this->DIR}/media/Instagram_{$video}' loop preload='auto'></video>
            <span class='p_vid_pp_large'><i class='material-icons'>play_arrow</i></span>
            <span class='p_vid_cur p_vid_time_teaser'>0:00</span>
            <span class='p_vid_time_bubble'>0:00</span><div class='p_vid_ctrls'><div class='p_vid_seek'>
            <input class='p_vid_seek_range' type='range' name='p_vid_range' value='0' min='0' max='100' step='1'>
            </div><span class='p_vid_pp'><i class='material-icons'>play_arrow</i></span>
            <div class='p_vid_duration'><span class='p_vid_cur'>0:00</span><span class='p_vid_dur_sep'>/</span>
            <span class='p_vid_dur'>0:00</span></div><div class='p_vid_vol_div'>
            <input type='range' name='p_vid_vol_slider' value='100' min='0' max='100' step='1'>
            </div><span class='p_vid_vup'><i class='material-icons'>volume_up</i></span>
            <div class='p_vid_pbr_div'><ul><li data-pbr='2'>2x</li><li data-pbr='1.75'>1.75x</li>
            <li data-pbr='1.5'>1.5x</li><li data-pbr='1.25'>1.25x</li><li data-pbr='1' class='pbr_class'>1x</li>
            <li data-pbr='0.75'>0.75x</li><li data-pbr='0.5'>0.5x</li></ul></div>
            <span class='p_vid_setting'>1x</span><div class='p_vid_shadow'></div></div></div>";
        }

      }

    }

    public function getAudiosPost($id){
      $avatar = new Avatar;
      $universal = new universal;
      $Time = new time;
      $post_like = new postLike;
      $bookmark = new bookmark;
      $taggings = new taggings;
      $share = new share;
      $comment = new postComment;

      $get_id = $universal->getIdFromGet($_GET['u']);
      $session = $_SESSION['id'];

      $query = $this->db->prepare("SELECT post.post_id, post.user_id, audio_post.audio FROM post, audio_post WHERE post.user_id = :user AND post.type = :type AND post.post_id = audio_post.post_id AND post.post_of <> :grp ORDER BY post.time DESC");
      $query->execute(array(":user" => $id, ":type" => "audio", ":grp" => "group"));
      $count = $query->rowCount();
      if ($count == 0) {
        echo "<div class='home_last_mssg pro_last_mssg'><img src='{$this->DIR}/images/needs/noimage.gif'><span>";
        if ($universal->MeOrNot($id)) {
          echo "You have no audios";
        } else {
          echo $universal->GETsDetails($id, "username")." has no audios";
        }
      } else if ($query->rowCount() > 0) {

        while ($row = $query->fetch(PDO::FETCH_OBJ)) {
          $post_id = $row->post_id;
          $user_id = $row->user_id;
          $audio = $row->audio;
          

          echo "<div class='flex items-center flex-col md:flex-row justify-center p-4 rounded-md shadow hover:shadow-md md:space-x-4'>
          <a>
          <div class='music-container'>

          <div class='img-container'>
            <img src='{$this->DIR}/images/needs/music.gif' style='width:80px; height:80px;'/>
          </div>
          <div class='navigation'>
            
          <div class='p_aud' data-song='{$this->DIR}/media/{$audio}'>
            
          
       
                <span class='p_aud_time_bubble'>0:00</span><div class='p_aud_ctrls'><div class='p_aud_info'>
                <span class='p_aud_name'></span>
                </div><span class='p_aud_pp'><i class='material-icons'>play_arrow</i></span>
                <div class='p_aud_seek'><input class='p_aud_seek_range' type='range' name='p_aud_seek_range' value='0' min='0' max='100' step='1'>
                </div><div style='left:-90px;' class='p_aud_duration'><span class='p_aud_cur'>0:00</span><span class='p_aud_dur_sep'>/</span>
                <span class='p_aud_dur'>0:00</span></div><div class='p_aud_vol_div' style='left:120px'>
                <input type='range' name='p_aud_vol_slider' value='100' min='0' max='100' step='1'>
                </div><span class='p_aud_vup'  style='top:3px;
                 left: 30px; position:relative;'><i class='material-icons'>volume_up</i></span></div></div></div> </div></a>
                                
                 </div>";
         }

      }

    }

    public function deletePost($post){
      $id = $_SESSION['id'];
      $tagquery = $this->db->prepare("DELETE FROM taggings WHERE post_id = :post");
      $tagquery->execute(array(":post" => $post));

      $sharequery = $this->db->prepare("DELETE FROM shares WHERE post_id = :post");
      $sharequery->execute(array(":post" => $post));

      $bkmrkquery = $this->db->prepare("DELETE FROM bookmarks WHERE post_id = :post");
      $bkmrkquery->execute(array(":post" => $post));

      $likequery = $this->db->prepare("DELETE FROM post_likes WHERE post_id = :post");
      $likequery->execute(array(":post" => $post));

      $cc = $this->db->prepare("SELECT post_comments_id FROM post_comments WHERE post_id = :post");
      $cc->execute(array(":post" => $post));
      if ($cc->rowCount() > 0) {
        while ($row = $cc->fetch(PDO::FETCH_OBJ)) {
          $cid = $row->post_comments_id;
          $cl = $this->db->prepare("DELETE FROM comment_likes WHERE comment_id = :comment");
          $cl->execute(array(":comment" => $cid));
        }
      }

      $comquery = $this->db->prepare("DELETE FROM post_comments WHERE post_id = :post");
      $comquery->execute(array(":post" => $post));

      $notiquery = $this->db->prepare("DELETE FROM notifications WHERE post_id = :post");
      $notiquery->execute(array(":post" => $post));

      $hashquery = $this->db->prepare("DELETE FROM hashtag WHERE post_id = :post");
      $hashquery->execute(array(":post" => $post));

      $query = $this->db->prepare("SELECT type, post_id FROM post WHERE post_id = :post");
      $query->execute(array(":post" => $post));
      if ($query->rowCount() > 0) {
        while ($row = $query->fetch(PDO::FETCH_OBJ)) {
          $type = $row->type;
          $p = $row->post_id;

          if ($type == "text") {
            $textquery = $this->db->prepare("DELETE FROM text_post WHERE post_id = :post");
            $textquery->execute(array(":post" => $p));

          } else if ($type == "image") {
            $imgquery1 = $this->db->prepare("SELECT image FROM image_post WHERE post_id = :post");
            $imgquery1->execute(array(":post" => $p));
            if ($imgquery1->rowCount() > 0) {
              while ($imgrow = $imgquery1->fetch(PDO::FETCH_OBJ)) {
                $image = $imgrow->image;

                if(file_exists("../../media/Instagram_{$image}")){
                  unlink("../../media/Instagram_$image");
                }
                $dltimage = $this->db->prepare('DELETE FROM image_post WHERE post_id = :post');
                $dltimage->execute(array(":post" => $p));
              }
            }

          } else if ($type == "video") {
            $vidquery1 = $this->db->prepare("SELECT video FROM video_post WHERE post_id = :post");
            $vidquery1->execute(array(":post" => $p));
            if ($vidquery1->rowCount() > 0) {
              while ($vidrow = $vidquery1->fetch(PDO::FETCH_OBJ)) {
                $video = $vidrow->video;
                if(file_exists("../../media/Instagram_{$video}")){
                  unlink("../../media/Instagram_$video");
                }
                $dltvideo = $this->db->prepare('DELETE FROM video_post WHERE post_id = :post');
                $dltvideo->execute(array(":post" => $p));
              }
            }

          } else if ($type == "audio") {
            $audquery1 = $this->db->prepare("SELECT audio FROM audio_post WHERE post_id = :post");
            $audquery1->execute(array(":post" => $p));
            if ($audquery1->rowCount() > 0) {
              while ($audrow = $audquery1->fetch(PDO::FETCH_OBJ)) {
                $audio = $audrow->audio;
                if (file_exists("../../media/$audio")) {
                  unlink("../../media/$audio");
                }
                $dltaudio = $this->db->prepare('DELETE FROM audio_post WHERE post_id = :post');
                $dltaudio->execute(array(":post" => $p));
              }
            }

          } else if ($type == "document") {
            $docquery1 = $this->db->prepare("SELECT doc FROM doc_post WHERE post_id = :post");
            $docquery1->execute(array(":post" => $p));
            if ($docquery1->rowCount() > 0) {
              while ($docrow = $docquery1->fetch(PDO::FETCH_OBJ)) {
                $doc = $docrow->doc;
                if(file_exists("../../doc/{$doc}")){
                  unlink("../../doc/$doc");
                }
                $dltdoc = $this->db->prepare('DELETE FROM doc_post WHERE post_id = :post');
                $dltdoc->execute(array(":post" => $p));
              }
            }

          } else if ($type == "link") {
            $linkquery = $this->db->prepare("DELETE FROM link_post WHERE post_id = :post");
            $linkquery->execute(array(":post" => $p));

          } else if ($type == "location") {
            $locquery = $this->db->prepare("DELETE FROM loc_post WHERE post_id = :post");
            $locquery->execute(array(":post" => $p));
          }

        }

        $squery = $this->db->prepare("DELETE FROM post WHERE post_id = :post");
        $squery->execute(array(":post" => $post));
      }

    }

    public function getlinknani($post){
      $universal = new universal;

      $session = $_SESSION['id'];

      $query = $this->db->prepare("SELECT * FROM post WHERE post_id = :post LIMIT 1");
      $query->execute(array(":post" => $post));
      $count = $query->rowCount();

      if ($count == 0) {
        echo "<input type='text' name='linkre' value='No Post to Report please refresh this page' class='bg-gray-100 h-12 mt-2 px-3 rounded-md w-full'readonly>";
      } else if ($count == 1) {

        $row = $query->fetch(PDO::FETCH_OBJ);
        $post_id = $row->post_id;
        $user_id = $row->user_id;


        echo"<div class='flex items-center'>
                            <div class='-mr-1 bg-gray-100 border px-3 py-3 rounded-l-md'> <i class='uil uil-user-square' style='color:purple;'></i></div>
                            <input type='text' name='reportuser' value='@{$universal->nameShortener($universal->GETsDetails($user_id, "username"), 25)}' class='with-border'readonly>
                        </div>
       <div class='flex items-center'>
                            <div class='-mr-1 bg-gray-100 border px-3 py-3 rounded-l-md'><i class='uil uil-link' style='color:purple;'></i></div>
        <input type='text' name='reportlink' value='{$universal->urlChecker($this->DIR)}/view_post/{$post_id}' class='with-border'readonly></div>";
    }
  }

    public function viewPost($post){
      $avatar = new Avatar;
      $universal = new universal;
      $Time = new time;
      $post_like = new postLike;
      $bookmark = new bookmark;
      $taggings = new taggings;
      $share = new share;
      $comment = new postComment;
      $follow = new follow_system;
      $comment = new postComment;
      $settings = new settings;
      $groups = new group;

      $session = $_SESSION['id'];

      $query = $this->db->prepare("SELECT * FROM post WHERE post_id = :post LIMIT 1");
      $query->execute(array(":post" => $post));
      $count = $query->rowCount();

      if ($count == 0) {
        echo "<div class='home_last_mssg pro_last_mssg'><img src='{$this->DIR}/images/no post.gif'><span>No such post found</span></div>";
      } else if ($count == 1) {

        $row = $query->fetch(PDO::FETCH_OBJ);
        $post_id = $row->post_id;
        $user_id = $row->user_id;
        $type = $row->type;
        $time = $row->time;
        $size = $row->font_size;
        $address = $row->address;
        $of = $row->post_of;
        $grp = $row->grp_id;
        $none = '"none"';

        echo "<div class='card lg:mx-0 uk-animation-slide-bottom-small' data-postid='{$post_id}' data-type='{$type}'><div class='flex justify-between items-center lg:p-4 p-2.5'>
        <div class='flex flex-1 items-center space-x-4'>";
        echo "<img class='bg-gray-200 border border-white rounded-full w-10 h-10' src='". DIR ."/{$avatar->GETsAvatar($user_id)}' alt='{$universal->GETsDetails($user_id, "username")}'s avatar'>";
       
        echo "<div class='flex-1 capitalize'>
            <div class='font-semibold'>
            <a href='". DIR ."/profile/{$universal->GETsDetails($user_id, "username")}' data-getid='{$user_id}' class='text-black dark:text-gray-100'> ".$universal->GETsDetails($user_id, "firstname")." ".$universal->GETsDetails($user_id, "surname")."</a> <img src='{$this->DIR}/images/".$universal->GETsDetails($user_id, "bluetick").".png' style='width:15px; height:15px; display:inline-block;' onerror='this.style.display = ".$none."'/>
            </div>
            <div class='text-gray-700 flex items-center space-x-2'>
            <div class='p_i_1'>";
            echo"@<a href='". DIR ."/profile/{$universal->GETsDetails($user_id, "username")}' data-getid='{$user_id}' class='text-black dark:text-gray-100' title='{$universal->GETsDetails($user_id, "username")}'>{$universal->nameShortener($universal->GETsDetails($user_id, "username"), 25)}</a><span title='". self::addressTitle($address, $user_id) ."'>
            </div>";
            echo "<p>. ". $Time->timeAgo($time) ."</p> <ion-icon name='people'></ion-icon></div>";
            echo self::addressN($address, $user_id);
            echo "</span>";
  
            echo " </div></div><div>"; 
            
            
                
          
        echo "</div></div>";
            
            echo "<div>"; 
            echo self::getDifferentPost($type, $post_id, $size);
            echo "</div><div class='p_a p-4 space-y-3'><div class='p_do'>";
            echo "<div class='flex space-x-4 lg:font-bold'>";
           
            echo "</div>";
        
            echo "</div><div uk-toggle='target: #offcanvas-chat' class='p_did dark:text-gray-100'>
            </div></div><hr>";
        
        echo "<div class='p_cit view_cit p-4 space-y-3'>";
        echo"<div class='p_cit_area border-t py-4 space-y-4 dark:border-gray-600'>";
       
        echo "<input class='bg-transparent max-h-10 shadow-none px-5 comment_og' name='post_comment' spellcheck='false' placeholder='Add your Comment..'>";
         // echo "<span data-description='Add emojis'><i class='material-icons'>sentiment_very_satisfied</i></span>";
         echo "</div><div class='p_cit_tool view_cit_tool'>
         <form class='p_comment_form' enctype='multipart/form-data'>
         <input type='file' class='p_comm_file_og' name='p_comm_file' id='p_comm_file'>
         <label for='p_comm_file' class='p_cit_more' data-description='Attach a file'><i class='material-icons' style='color:blue;'>attach_file</i></label>
         </form></div></div></div>";

        echo " <div class='flex'>
        <div class='comments_div'>";

        $comment->comments($post_id);

        echo "</div></div>";

        echo "</div></div>";

        echo "<div class='flex justify-center mt-6'>
        <a href='#' class='bg-white dark:bg-gray-900 font-semibold my-3 px-6 py-2 rounded-full shadow-md dark:bg-gray-800 dark:text-white'>
        Looks like you've reached the end</a>
    </div>";

      }

    }

    public function editPost($text, $post, $type){

      $hashtag = new hashtag;
      $mention = new mention_class;

      if ($type == "text") {
        $query = $this->db->prepare("UPDATE text_post SET text = :text WHERE post_id = :post");
        $query->execute(array(":text" => $text, ":post" => $post));
        if ($text == "") {
          self::deletePost($post);
        }

      } else if ($type == "image") {
        $query = $this->db->prepare("UPDATE image_post SET about = :text WHERE post_id = :post");
        $query->execute(array(":text" => $text, ":post" => $post));

      } else if ($type == "video") {
        $query = $this->db->prepare("UPDATE video_post SET about = :text WHERE post_id = :post");
        $query->execute(array(":text" => $text, ":post" => $post));

      } else if ($type == "audio") {
        $query = $this->db->prepare("UPDATE audio_post SET about = :text WHERE post_id = :post");
        $query->execute(array(":text" => $text, ":post" => $post));

      } else if ($type == "link") {
        $query = $this->db->prepare("UPDATE link_post SET text = :text WHERE post_id = :post");
        $query->execute(array(":text" => $text, ":post" => $post));

      } else if ($type == "document") {
        $query = $this->db->prepare("UPDATE doc_post SET about = :text WHERE post_id = :post");
        $query->execute(array(":text" => $text, ":post" => $post));

      } else if ($type == "location") {
        $query = $this->db->prepare("UPDATE loc_post SET about = :text WHERE post_id = :post");
        $query->execute(array(":text" => $text, ":post" => $post));
      }

      $a = $this->db->prepare("DELETE FROM hashtag WHERE post_id = :post");
      $a->execute(array(":post" => $post));

      $mention->getMentions($text, $post);
      $hashtag->getHashtags($text, $post);

    }

  }
?>
