<?php
  class tags extends universal{

    protected $db;
    protected $DIR;

    public function __construct(){
      $db = N::_DB();
      $DIR = N::$DIR;

      $this->db = $db;
      $this->DIR = $DIR;
    }

    public function filterTags(){
      $delete = $this->db->exec("DELETE FROM tags WHERE tags = ''");
    }

    public function get_tags($get){
      $query = $this->db->prepare("SELECT tags FROM tags WHERE user_id = :id");
      $query->execute(array(":id" => $get));
      if ($query->rowCount() == 0 || $query->rowCount() == null) {
        if (parent::MeOrNot($get)) {
          echo "You got no <i class='fa fa-leaf' style='color:purple;' aria-hidden='true'></i> sphere! <a href='{$this->DIR}/edit'><button class='p-2 px-4 rounded bg-gray-50 text-purple-500'> Add </button></a>";
        } else {
          echo parent::GETsDetails($get, "username")." got no <i class='fa fa-leaf' style='color:purple;' aria-hidden='true'></i> sphere";
        }
      } else if ($query->rowCount() > 0) {
        while ($row = $query->fetch(PDO::FETCH_OBJ)) {
          $each = $row->tags;
          $tag = "<a href='{$this->DIR}/tag?tag={$each}' class='tags'><i class='fa fa-leaf' style='color:purple;' aria-hidden='true'></i> $each</a>";
          echo $tag;
        }
      }
    }

    public function userTags($user, $when){
      if ($when == "user") { $limit = "LIMIT 6"; } else if ($when == "page") { $limit = ""; }
      $query = $this->db->prepare("SELECT tags FROM tags WHERE user_id = :id ORDER BY tag_id $limit");
      $query->execute(array(":id" => $user));
      if ($query->rowCount() > 0) {
        while ($row = $query->fetch(PDO::FETCH_OBJ)) {
          $each = $row->tags;
          $tag = "<a href='{$this->DIR}/tag?tag={$each}' class='tags'><i class='fa fa-leaf' style='color:purple;' aria-hidden='true'></i> {$each}</a>";
          echo $tag;
        }
      }
    }

    public function popularTags(){
      $query = $this->db->query("SELECT tags, COUNT(tags) as c FROM tags GROUP BY tags ORDER BY c DESC LIMIT 15");
      if ($query->rowCount() > 0) {
        while ($row = $query->fetch(PDO::FETCH_OBJ)) {
          $tags = $row->tags;
          echo "<a href='{$this->DIR}/tag?tag={$tags}' class='tags'><i class='fa fa-leaf' style='color:purple;' aria-hidden='true'></i> {$tags}</a>";
        }
      }
    }

    public function getTagsEdit($get){
      $query = $this->db->prepare("SELECT tags FROM tags WHERE user_id = :id");
      $query->execute(array(":id" => $get));
      if ($query->rowCount() != null) {
        while ($row = $query->fetch(PDO::FETCH_OBJ)) {
          $each = $row->tags;
          $tag = "<span class='t_a_tag'>". $each ."</span>";
          echo $tag;
        }
      }
    }

    public function noOfTagPeople($tag){
      $query = $this->db->prepare("SELECT user_id, tags FROM tags WHERE tags = :tag");
      $query->execute(array(":tag" => $tag));
      $count = $query->rowCount();
      if ($count == 0) {
        return "No";
      } else {
        return $count;
      }
    }

    public function sameTagPeople($tag){
      $session = $_SESSION['id'];

      $universal = new universal;
      $avatar = new Avatar;
      $follow = new follow_system;
      $mutual = new mutual;

      $query = $this->db->prepare("SELECT user_id, tags FROM tags WHERE tags = :tag");
      $query->execute(array(":tag" => $tag));
      if ($query->rowCount() == 0) {
        echo "<ul class='card divide-y'><img src='{$this->DIR}/images/no post.gif'><span>No one with {$tag} found</span></ul>";
      } else if ($query->rowCount() > 0) {
        while ($row = $query->fetch(PDO::FETCH_OBJ)) {
          $user = $row->user_id;
          $tags = $row->tags;
          $none = '"none"';
          

          echo
          "<li> 
          <a>
          <div class='flex items-center space-x-5 p-4'>
          
            <img src='{$this->DIR}/{$avatar->GETsAvatar($user)}' class='w-12 h-12 rounded-full' alt=''>
            <div class='flex-1'>
            
            <a href='". DIR ."/profile/{$universal->GETsDetails($user, "username")}'><h3 class='text-lg font-semibold line-clamp-1'>";
              if ($user == $session) {
                echo "You";
              } else {
                echo "@".$universal->GETsDetails($user, "username")."";
              }
              echo " </a><img src='{$this->DIR}/images/".$universal->GETsDetails($user, "bluetick").".png' style='width:15px; height:15px; display:inline-block;' onerror='this.style.display = ".$none."'/></h3>
              <div class='flex space-x-3 text-sm pb-2 mt-1 flex-wrap'>
              <div class='font-semibold'> {$mutual->eMutual($user)} </div> 
              <div class='text-gray-500'> ";
              self::userTags($user, "user");

              echo"</div>
            </div>
        </a>
    </li>";
          

        }
      }

    }

  }
?>
