<?php
  class login_class{

    protected $db;
    protected $DIR;
    protected $gmail;
    protected $gmail_password;

    public function __construct(){
      $db = N::_DB();
      $DIR = N::$DIR;
      $GMAIL = N::$GMAIL;
      $GMAIL_PASS = N::$GMAIL_PASSWORD;

      $this->db = $db;
      $this->DIR = $DIR;
      $this->gmail = $GMAIL;
      $this->gmail_password = $GMAIL_PASS;
    }



public function getTwoFactorAuth($username) {
$query = $this->db->prepare("SELECT twoauth FROM users WHERE username = :username LIMIT 1");
$query->execute(array(":username" => $username));
$row = $query->fetch(PDO::FETCH_OBJ);
return $row->twoauth;
}

 public function LOGIN_otp($username, $otp) {
    $query = $this->db->prepare("SELECT id, twootp FROM users WHERE username = :username LIMIT 1");
    $query->execute(array(":username" => $username));
    $row = $query->fetch(PDO::FETCH_OBJ);
    $twofnani = $row->twootp;

    if ($otp = $twofnani) {
         $otpdd = rand(100000, 999999);
            $uid = $row->id;

            $lquery = $this->db->prepare("UPDATE users SET twootp = :otpnani WHERE id = :id");
            $lquery->execute(array(":id" => $uid, ":otpnani" => $otpdd));

            $_SESSION['id'] = $uid;

            return "OTP Verified Successfully";
        
    } else {
        return "Incorrect otp";
    }
}

public function LOGIN($username, $password, $ip) {
    include 'settings.class.php';
    include 'universal.class.php';
    include 'PHPMailerAutoload.php';

    $mail = new PHPMailer;
    $settings = new settings;
    $universal = new universal;

    if (empty($username) || empty($password)) {
        return "Your values are missing";
    }

    $attempts = isset($_SESSION['login_attempts']) ? $_SESSION['login_attempts'] : 0;

    // if ($attempts >= 5) {
    //      $_SESSION['try'] = $attempts;
    //     return "Maximum login attempts Reached";

    // }
    
    $query = $this->db->prepare("SELECT id, password, twoauth FROM users WHERE username = :username LIMIT 1");
    $query->execute(array(":username" => $username));
    
    if ($query->rowCount() == 0) {
        $_SESSION['login_attempts'] = isset($_SESSION['login_attempts']) ? $_SESSION['login_attempts'] + 1 : 1;
        $_SESSION['login_timestamp'] = time();
        return "Incorrect details";
    }
    
    $row = $query->fetch(PDO::FETCH_OBJ);
    $pass = $row->password;
    $twofactor = $row->twoauth;


    if (password_verify($password, $pass)) {
        if ($twofactor === 'active') {
            $otp = rand(100000, 999999);
            $uid = $row->id;

            $wquery = $this->db->prepare("UPDATE users SET twootp = :otpnani WHERE id = :id");
            $wquery->execute(array(":id" => $uid, ":otpnani" => $otp));

            $lquery = $this->db->prepare("INSERT INTO login(user_id, ip, time, otp) VALUES(:id, :ip, now(), :otp)");
            $lquery->execute(array(":id" => $uid, ":ip" => $ip, ":otp" => $otp));

            $email = $universal->GETsDetails($uid, "email");
            $uname = $universal->GETsDetails($uid, "username");

            $otpcode = $universal->GETsDetails($uid, "twootp");

        // $mail->SMTPDebug = 3;                               // Enable verbose debug output
        $mail->isSMTP();                                      // Set mailer to use SMTP
        $mail->Host = 'smtp.gmail.com';          // Specify main and backup SMTP servers
        $mail->SMTPAuth = true;                               // Enable SMTP authentication
        $mail->Username = $this->gmail;                 // SMTP username
        $mail->Password = $this->gmail_password;                           // SMTP password
        $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
        $mail->Port = 587;                                    // TCP port to connect to

        $mail->From = $this->gmail;
        $mail->FromName = "Team Tagopus";
        $mail->addAddress($email);               // Name is optional
        $mail->addReplyTo($this->gmail, 'Team Tagopus');
        // $mail->addCC('cc@example.com');
        // $mail->addBCC('bcc@example.com');

        $mail->addCC($this->gmail);
        $mail->addBCC($this->gmail);

        $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
        $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
        $mail->addEmbeddedImage('../../images/display logo22.png', 'te');
        $mail->addEmbeddedImage('../../images/email.png', 'logo');
        $mail->isHTML(true);                                  // Set email format to HTML

        $mail->Subject = 'Login OTP to your account';

        $mail->Body = '
        <!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
    <meta charset="utf-8"> <!-- utf-8 works for most cases -->
    <meta name="viewport" content="width=device-width">
    <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Use the latest (edge) version of IE rendering engine -->
    <meta name="x-apple-disable-message-reformatting">  <!-- Disable auto-scale in iOS 10 Mail entirely -->
    <title></title> <!-- The title tag shows in email notifications, like Android 4.4. -->

    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700" rel="stylesheet">

    <!-- CSS Reset : BEGIN -->
    <style>

        /* What it does: Remove spaces around the email design added by some email clients. */
        /* Beware: It can remove the padding / margin and add a background color to the compose a reply window. */
        html,
body {
    margin: 0 auto !important;
    padding: 0 !important;
    height: 100% !important;
    width: 100% !important;
    background: #f1f1f1;
}

/* What it does: Stops email clients resizing small text. */
* {
    -ms-text-size-adjust: 100%;
    -webkit-text-size-adjust: 100%;
}

/* What it does: Centers email on Android 4.4 */
div[style*="margin: 16px 0"] {
    margin: 0 !important;
}

/* What it does: Stops Outlook from adding extra spacing to tables. */
table,
td {
    mso-table-lspace: 0pt !important;
    mso-table-rspace: 0pt !important;
}

/* What it does: Fixes webkit padding issue. */
table {
    border-spacing: 0 !important;
    border-collapse: collapse !important;
    table-layout: fixed !important;
    margin: 0 auto !important;
}

/* What it does: Uses a better rendering method when resizing images in IE. */
img {
    -ms-interpolation-mode:bicubic;
}

/* What it does: Prevents Windows 10 Mail from underlining links despite inline CSS. Styles for underlined links should be inline. */
a {
    text-decoration: none;
}

/* What it does: A work-around for email clients meddling in triggered links. */
*[x-apple-data-detectors],  /* iOS */
.unstyle-auto-detected-links *,
.aBn {
    border-bottom: 0 !important;
    cursor: default !important;
    color: inherit !important;
    text-decoration: none !important;
    font-size: inherit !important;
    font-family: inherit !important;
    font-weight: inherit !important;
    line-height: inherit !important;
}

/* What it does: Prevents Gmail from displaying a download button on large, non-linked images. */
.a6S {
    display: none !important;
    opacity: 0.01 !important;
}

/* What it does: Prevents Gmail from changing the text color in conversation threads. */
.im {
    color: inherit !important;
}

img.g-img + div {
    display: none !important;
}

/* What it does: Removes right gutter in Gmail iOS app: https://github.com/TedGoas/Cerberus/issues/89  */

@media only screen and (min-device-width: 320px) and (max-device-width: 374px) {
    u ~ div .email-container {
        min-width: 320px !important;
    }
}
/* iPhone 6, 6S, 7, 8, and X */
@media only screen and (min-device-width: 375px) and (max-device-width: 413px) {
    u ~ div .email-container {
        min-width: 375px !important;
    }
}
/* iPhone 6+, 7+, and 8+ */
@media only screen and (min-device-width: 414px) {
    u ~ div .email-container {
        min-width: 414px !important;
    }
}


    </style>

    <!-- CSS Reset : END -->

    <!-- Progressive Enhancements : BEGIN -->
    <style>

        .primary{
    background: #17bebb;
}
.bg_white{
    background: #ffffff;
}
.bg_light{
    background: #f7fafa;
}
.bg_black{
    background: #000000;
}
.bg_dark{
    background: rgba(0,0,0,.8);
}
.email-section{
    padding:2.5em;
}

/*BUTTON*/
.btn{
    padding: 10px 15px;
    display: inline-block;
}
.btn.btn-primary{
    border-radius: 5px;
    background: #17bebb;
    color: #ffffff;
}
.btn.btn-white{
    border-radius: 5px;
    background: #ffffff;
    color: #000000;
}
.btn.btn-white-outline{
    border-radius: 5px;
    background: transparent;
    border: 1px solid #fff;
    color: #fff;
}
.btn.btn-black-outline{
    border-radius: 0px;
    background: transparent;
    border: 2px solid #000;
    color: #000;
    font-weight: 700;
}
.btn-custom{
    color: rgba(0,0,0,.3);
    text-decoration: underline;
}

h1,h2,h3,h4,h5,h6{
    font-family: "Poppins", sans-serif;
    color: #000000;
    margin-top: 0;
    font-weight: 400;
}

body{
    font-family: "Poppins", sans-serif;
    font-weight: 400;
    font-size: 15px;
    line-height: 1.8;
    color: rgba(0,0,0,.4);
}

a{
    color: #17bebb;
}

table{
}
/*LOGO*/

.logo h1{
    margin: 0;
}
.logo h1 a{
    color: #17bebb;
    font-size: 24px;
    font-weight: 700;
    font-family: "Poppins", sans-serif;
}

/*HERO*/
.hero{
    position: relative;
    z-index: 0;
}

.hero .text{
    color: rgba(0,0,0,.3);
}
.hero .text h2{
    color: #000;
    font-size: 34px;
    margin-bottom: 0;
    font-weight: 200;
    line-height: 1.4;
}
.hero .text h3{
    font-size: 24px;
    font-weight: 300;
}
.hero .text h2 span{
    font-weight: 600;
    color: #000;
}

.text-author{
    bordeR: 1px solid rgba(0,0,0,.05);
    max-width: 50%;
    margin: 0 auto;
    padding: 2em;
}
.text-author img{
    border-radius: 50%;
    padding-bottom: 20px;
}
.text-author h3{
    margin-bottom: 0;
}
ul.social{
    padding: 0;
}
ul.social li{
    display: inline-block;
    margin-right: 10px;
}

/*FOOTER*/

.footer{
    border-top: 1px solid rgba(0,0,0,.05);
    color: rgba(0,0,0,.5);
}
.footer .heading{
    color: #000;
    font-size: 20px;
}
.footer ul{
    margin: 0;
    padding: 0;
}
.footer ul li{
    list-style: none;
    margin-bottom: 10px;
}
.footer ul li a{
    color: rgba(0,0,0,1);
}


@media screen and (max-width: 500px) {


}


    </style>


</head>

<body width="100%" style="margin: 0; padding: 0 !important; mso-line-height-rule: exactly; background-color: #f1f1f1;">
    <center style="width: 100%; background-color: #f1f1f1;">
    <div style="display: none; font-size: 1px;max-height: 0px; max-width: 0px; opacity: 0; overflow: hidden; mso-hide: all; font-family: sans-serif;">
      &zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;
    </div>
    <div style="max-width: 600px; margin: 0 auto;" class="email-container">
        <!-- BEGIN BODY -->
      <table align="center" role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: auto;">
        <tr>
          <td valign="top" class="bg_white" style="padding: 1em 2.5em 0 2.5em;">
            <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
                <tr>
                    <td class="logo" style="text-align: center;" >
                    <img src="cid:te" style="width: 150px;"/>
                      </td>
                </tr>
            </table>
          </td>
          </tr><!-- end tr -->
           <tr>
          <td valign="middle" class="hero bg_white" style="padding: 3em 0 2em 0;">
            <img src="cid:logo" alt="" style="width: 100px; max-width: 300px; height: auto; margin: auto; display: block;">
          </td>
          </tr><!-- end tr -->
                <tr>
          <td valign="middle" class="hero bg_white" style="padding: 2em 0 4em 0;">
            <table >
                <tr>
                    <td>
                        <div class="text" style="padding: 0 2.5em; text-align: center;">
                            <h3 >Hello '.$uname.', </h3>
                            <h4 style="text-align:left;">You have received this message because you or someone is trying to access your TAGOPUS account.</h3>
                            <h4 style="text-align:left;">But 2FA is setup for your account according to your preference. Use the code below to gain access to your account.</h4>
                            <h3>'.$otpcode.'</h3>
                        </div>
                    </td>
                </tr>
            </table>
          </td>
          </tr><!-- end tr -->
      <!-- 1 Column Text + Button : END -->
     

    </div>
  </center>
</body>
</html>';


            $_SESSION['otp'] = $otp;
            $_SESSION['id'] = $uid;
            if($mail->send() || !$mail->send()){
            return "OTP sent";
        }
        } else {
            $uid = $row->id;

            $random = new random;
            $os = $random->getOS();
            $browser = $random->getBrowser();

            $lquery = $this->db->prepare("INSERT INTO login(user_id, ip, time, os, browser) VALUES(:id, :ip, now(), :os, :browser)");
            $lquery->execute(array(":id" => $uid, ":ip" => $ip, ":os" => $os, ":browser" => $browser));

            $_SESSION['id'] = $uid;

            return "Successful";
        }
    } else {
        return "Incorrect password";
    }
}


    public function LOGOUT(){
      $id = $_SESSION['id'];

      $query = $this->db->prepare("SELECT MAX(login_id) AS myGet FROM login WHERE user_id = :id LIMIT 1");
      $query->execute(array(":id" => $id));
      $row = $query->fetch(PDO::FETCH_OBJ);
      $login_id = $row->myGet;

      $mquery = $this->db->prepare("UPDATE login SET logout = now() WHERE login_id = :id");
      $mquery->execute(array(":id" => $login_id));
      session_destroy();
      header("Location: login");
    }

    public function REGISTER($username, $firstname, $surname, $email, $gender, $country, $mobile, $birthday, $password, $pri_ip){
      include 'settings.class.php';
      include 'universal.class.php';
      include 'PHPMailerAutoload.php';

      $mail = new PHPMailer;
      $settings = new settings;
      $universal = new universal;

      $password_h = password_hash($password, PASSWORD_DEFAULT);

      $fquery = $this->db->prepare("SELECT id FROM users WHERE username = :username");
      $fquery->execute(array(":username" => $username));
      $squery = $this->db->prepare("SELECT id FROM users WHERE email = :email");
      $squery->execute(array(":email" => $email));

      if (($username || $firstname || $surname || $email || $password || $gender || $country || $mobile || $birthday ) == "") {
        return "Some values are missing";
      } else if (!filter_var($email, FILTER_VALIDATE_EMAIL) === true) {
        return "Incorrect email";
      } else if ($fquery->rowCount() > 0) {
        return "username already exists";
      } else if ($squery->rowCount() > 0) {
        return "Email already exists";
      } else {

        $random = new random;
        $os = $random->getOS();
        $browser = $random->getBrowser();

        $query = $this->db->prepare("INSERT INTO users(username, firstname, surname, email, gender, country, mobile, birthday, password, signup, coins, last_login, pri_ip, pri_os, pri_browser, twoauth) VALUES(:username, :firstname, :surname, :email, :gender, :country, :mobile, :birthday, :password, now(), 0, now(), :ip, :os, :browser, 'inactive')");
        $query->execute(array(":username" => $username, ":firstname" => $firstname, ":surname" => $surname, ":email" => $email, ":gender" => $gender, ":country" => $country, ":mobile" => $mobile, ":birthday" => $birthday, ":password" => $password_h, ":ip" => $pri_ip, ":os" => $os, ":browser" => $browser));

        $uid = $this->db->lastInsertId();

        $email = $universal->GETsDetails($uid, "email");
        $uname = $universal->GETsDetails($uid, "username");

        $url = $universal->urlChecker($this->DIR);

        // $mail->SMTPDebug = 3;                               // Enable verbose debug output
        $mail->isSMTP();                                      // Set mailer to use SMTP
        $mail->Host = 'smtp.gmail.com';          // Specify main and backup SMTP servers
        $mail->SMTPAuth = true;                               // Enable SMTP authentication
        $mail->Username = $this->gmail;                 // SMTP username
        $mail->Password = $this->gmail_password;                           // SMTP password
        $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
        $mail->Port = 587;                                    // TCP port to connect to

        $mail->From = $this->gmail;
        $mail->FromName = "Team Tagopus";
        $mail->addAddress($email);               // Name is optional
        $mail->addReplyTo($this->gmail, 'Team Tagopus');
        // $mail->addCC('cc@example.com');
        // $mail->addBCC('bcc@example.com');

        $mail->addCC($this->gmail);
        $mail->addBCC($this->gmail);

        $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
        $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
        $mail->addEmbeddedImage('../../images/display logo22.png', 'te');
        $mail->addEmbeddedImage('../../images/email.png', 'logo');
        $mail->isHTML(true);                                  // Set email format to HTML

        $mail->Subject = 'Verify your Tagopus account';

        $mail->Body = '
        <!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
    <meta charset="utf-8"> <!-- utf-8 works for most cases -->
    <meta name="viewport" content="width=device-width">
    <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Use the latest (edge) version of IE rendering engine -->
    <meta name="x-apple-disable-message-reformatting">  <!-- Disable auto-scale in iOS 10 Mail entirely -->
    <title></title> <!-- The title tag shows in email notifications, like Android 4.4. -->

    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700" rel="stylesheet">

    <!-- CSS Reset : BEGIN -->
    <style>

        /* What it does: Remove spaces around the email design added by some email clients. */
        /* Beware: It can remove the padding / margin and add a background color to the compose a reply window. */
        html,
body {
    margin: 0 auto !important;
    padding: 0 !important;
    height: 100% !important;
    width: 100% !important;
    background: #f1f1f1;
}

/* What it does: Stops email clients resizing small text. */
* {
    -ms-text-size-adjust: 100%;
    -webkit-text-size-adjust: 100%;
}

/* What it does: Centers email on Android 4.4 */
div[style*="margin: 16px 0"] {
    margin: 0 !important;
}

/* What it does: Stops Outlook from adding extra spacing to tables. */
table,
td {
    mso-table-lspace: 0pt !important;
    mso-table-rspace: 0pt !important;
}

/* What it does: Fixes webkit padding issue. */
table {
    border-spacing: 0 !important;
    border-collapse: collapse !important;
    table-layout: fixed !important;
    margin: 0 auto !important;
}

/* What it does: Uses a better rendering method when resizing images in IE. */
img {
    -ms-interpolation-mode:bicubic;
}

/* What it does: Prevents Windows 10 Mail from underlining links despite inline CSS. Styles for underlined links should be inline. */
a {
    text-decoration: none;
}

/* What it does: A work-around for email clients meddling in triggered links. */
*[x-apple-data-detectors],  /* iOS */
.unstyle-auto-detected-links *,
.aBn {
    border-bottom: 0 !important;
    cursor: default !important;
    color: inherit !important;
    text-decoration: none !important;
    font-size: inherit !important;
    font-family: inherit !important;
    font-weight: inherit !important;
    line-height: inherit !important;
}

/* What it does: Prevents Gmail from displaying a download button on large, non-linked images. */
.a6S {
    display: none !important;
    opacity: 0.01 !important;
}

/* What it does: Prevents Gmail from changing the text color in conversation threads. */
.im {
    color: inherit !important;
}

img.g-img + div {
    display: none !important;
}

/* What it does: Removes right gutter in Gmail iOS app: https://github.com/TedGoas/Cerberus/issues/89  */

@media only screen and (min-device-width: 320px) and (max-device-width: 374px) {
    u ~ div .email-container {
        min-width: 320px !important;
    }
}
/* iPhone 6, 6S, 7, 8, and X */
@media only screen and (min-device-width: 375px) and (max-device-width: 413px) {
    u ~ div .email-container {
        min-width: 375px !important;
    }
}
/* iPhone 6+, 7+, and 8+ */
@media only screen and (min-device-width: 414px) {
    u ~ div .email-container {
        min-width: 414px !important;
    }
}


    </style>

    <!-- CSS Reset : END -->

    <!-- Progressive Enhancements : BEGIN -->
    <style>

        .primary{
    background: #17bebb;
}
.bg_white{
    background: #ffffff;
}
.bg_light{
    background: #f7fafa;
}
.bg_black{
    background: #000000;
}
.bg_dark{
    background: rgba(0,0,0,.8);
}
.email-section{
    padding:2.5em;
}

/*BUTTON*/
.btn{
    padding: 10px 15px;
    display: inline-block;
}
.btn.btn-primary{
    border-radius: 5px;
    background: #17bebb;
    color: #ffffff;
}
.btn.btn-white{
    border-radius: 5px;
    background: #ffffff;
    color: #000000;
}
.btn.btn-white-outline{
    border-radius: 5px;
    background: transparent;
    border: 1px solid #fff;
    color: #fff;
}
.btn.btn-black-outline{
    border-radius: 0px;
    background: transparent;
    border: 2px solid #000;
    color: #000;
    font-weight: 700;
}
.btn-custom{
    color: rgba(0,0,0,.3);
    text-decoration: underline;
}

h1,h2,h3,h4,h5,h6{
    font-family: "Poppins", sans-serif;
    color: #000000;
    margin-top: 0;
    font-weight: 400;
}

body{
    font-family: "Poppins", sans-serif;
    font-weight: 400;
    font-size: 15px;
    line-height: 1.8;
    color: rgba(0,0,0,.4);
}

a{
    color: #17bebb;
}

table{
}
/*LOGO*/

.logo h1{
    margin: 0;
}
.logo h1 a{
    color: #17bebb;
    font-size: 24px;
    font-weight: 700;
    font-family: "Poppins", sans-serif;
}

/*HERO*/
.hero{
    position: relative;
    z-index: 0;
}

.hero .text{
    color: rgba(0,0,0,.3);
}
.hero .text h2{
    color: #000;
    font-size: 34px;
    margin-bottom: 0;
    font-weight: 200;
    line-height: 1.4;
}
.hero .text h3{
    font-size: 24px;
    font-weight: 300;
}
.hero .text h2 span{
    font-weight: 600;
    color: #000;
}

.text-author{
    bordeR: 1px solid rgba(0,0,0,.05);
    max-width: 50%;
    margin: 0 auto;
    padding: 2em;
}
.text-author img{
    border-radius: 50%;
    padding-bottom: 20px;
}
.text-author h3{
    margin-bottom: 0;
}
ul.social{
    padding: 0;
}
ul.social li{
    display: inline-block;
    margin-right: 10px;
}

/*FOOTER*/

.footer{
    border-top: 1px solid rgba(0,0,0,.05);
    color: rgba(0,0,0,.5);
}
.footer .heading{
    color: #000;
    font-size: 20px;
}
.footer ul{
    margin: 0;
    padding: 0;
}
.footer ul li{
    list-style: none;
    margin-bottom: 10px;
}
.footer ul li a{
    color: rgba(0,0,0,1);
}


@media screen and (max-width: 500px) {


}


    </style>


</head>

<body width="100%" style="margin: 0; padding: 0 !important; mso-line-height-rule: exactly; background-color: #f1f1f1;">
    <center style="width: 100%; background-color: #f1f1f1;">
    <div style="display: none; font-size: 1px;max-height: 0px; max-width: 0px; opacity: 0; overflow: hidden; mso-hide: all; font-family: sans-serif;">
      &zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;
    </div>
    <div style="max-width: 600px; margin: 0 auto;" class="email-container">
        <!-- BEGIN BODY -->
      <table align="center" role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: auto;">
        <tr>
          <td valign="top" class="bg_white" style="padding: 1em 2.5em 0 2.5em;">
            <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
                <tr>
                    <td class="logo" style="text-align: center;" >
                    <img src="cid:te" style="width: 150px;"/>
                      </td>
                </tr>
            </table>
          </td>
          </tr><!-- end tr -->
           <tr>
          <td valign="middle" class="hero bg_white" style="padding: 3em 0 2em 0;">
            <img src="cid:logo" alt="" style="width: 100px; max-width: 300px; height: auto; margin: auto; display: block;">
          </td>
          </tr><!-- end tr -->
                <tr>
          <td valign="middle" class="hero bg_white" style="padding: 2em 0 4em 0;">
            <table >
                <tr>
                    <td>
                        <div class="text" style="padding: 0 2.5em; text-align: center;">
                            <h3>Hello '.$uname.', You received this message because you created an account on TAGOPUS.</h3>
                            <h4>Click on button below to verify your Tagopus account and explore.</h4>
                            <p><a href="'.$url.'/ajaxify/deep/most/topmost/activate.php?id='.$uid.'" class="btn btn-primary">Activate</a></p>
                        </div>
                    </td>
                </tr>
            </table>
          </td>
          </tr><!-- end tr -->
      <!-- 1 Column Text + Button : END -->
     

    </div>
  </center>
</body>
</html>';

        if (!file_exists("../../users/$uid")) {
          mkdir("../../users/$uid", 0755);
          mkdir("../../users/$uid/avatar", 0755);
        }
        $avatar = "../../images/avatars/userpro.png";
        $dest = "../../users/$uid/avatar/userpro.png";
        copy($avatar, $dest);
        
        $settings->settingsDefaults($uid);

        $_SESSION['id'] = $uid;

        if($mail->send() || !$mail->send()){
          return "Successfull";
        } 

      }

    }

    public function usernameChecker($value){
      $query = $this->db->prepare("SELECT id FROM users WHERE username = :username");
      $query->execute(array(":username" => $value));
      $count = $query->rowCount();
      if ($count == 0) {
        echo "<span class='checker_text' style='color: green;'>username is available</span><span class='checker_icon'>
          <i class='fa fa-smile-o' style='color: green;' aria-hidden='true'></i></span>";
      } else if ($count > 0) {
        echo "<span class='checker_text' style='color: red;'>username already taken</span><span class='checker_icon'>
          <i class='fa fa-frown-o' style='color: red;' aria-hidden='true'></i></span>";
      }
    }

    public function activateAccount($id){
      $settings = new settings;

      if (!file_exists("$id")) {
        mkdir("users/$id", 0755);
        mkdir("users/$id/avatar", 0755);
      }
      $avatar = "images/avatars/userpro.png";
      $dest = "users/$id/avatar/userpro.png";
      copy($avatar, $dest);

      $settings->settingsDefaults($id);

      $query = $this->db->prepare("UPDATE users SET email_activated = :act WHERE id = :user");
      $query->execute(array(":act" => "yes", ":user" => $id));
    }

  }
?>
