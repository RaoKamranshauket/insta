<?php
  class taggings{

    protected $db;
    protected $DIR;

    public function __construct(){
      $db = N::_DB();
      $DIR = N::$DIR;

      $this->db = $db;
      $this->DIR = $DIR;
    }

    public function getTaggings($post){
      $query = $this->db->prepare("SELECT tagging_id FROM taggings WHERE post_id = :post");
      $query->execute(array(":post" => $post));
      $count = $query->rowCount();
      if ($count == 0) {
        return "No tags";
      } else if ($count == 1) {
        return "1 tag";
      } else {
        return "$count tags";
      }
    }

    public function taggers($post){
      $session = $_SESSION['id'];

      include 'universal.class.php';
      include 'avatar.class.php';
      include 'follow_system.class.php';

      $universal = new universal;
      $avatar = new Avatar;
      $follow = new follow_system;

      $query = $this->db->prepare("SELECT taggings_id FROM taggings WHERE post_id = :post ORDER BY tagging_id DESC");
      $query->execute(array(":post" => $post));
      if ($query->rowCount() == 0) {
        echo"<h3 class='text-2xl font-bold mb-2'> No Tag in this Post </h3><div class='p-1'><img src='{$this->DIR}/images/taggs.gif' style='width: 150px; height: 150px; display: block;
        margin-left: auto;
        margin-right: auto;
        width: 50%;'><p style='text-align:center; font-weight:bold;'>Nobody was tagged in this post!</p></div>";
      } else if ($query->rowCount() != 0) {
        echo"<h3 class='text-2xl font-bold mb-2'> Tagged in this post</h3>";
        while ($fetch = $query->fetch(PDO::FETCH_OBJ)) {
          $userid = $fetch->taggings_id;
          $none = '"none"';
          
          


          echo "<div class='flex justify-between items-center lg:p-4 p-2.5'>
          <div class='flex flex-1 items-center space-x-4' data-getid='$userid'>
          <img src='{$this->DIR}/". $avatar->DisplayAvatar($userid) ."'class='bg-gray-200 border border-white rounded-full w-10 h-10' alt=''>
          <div class='flex-1 capitalize'>
          <div class='font-semibold'>
                <a href='{$this->DIR}/profile/". $universal->GETsDetails($userid, "username") ."' >
                <span>". $universal->nameShortener($universal->GETsDetails($userid, "firstname")." ".$universal->GETsDetails($userid, "surname"), 20) ."</span>&nbsp<img src='{$this->DIR}/images/".$universal->GETsDetails($userid, "bluetick").".png' style='width:15px; height:15px; display:inline-block;' onerror='this.style.display = ".$none."'/>
                </a>
                </div>
                
                &nbsp<span class='blocked_mutual'>@". $universal->nameShortener($universal->GETsDetails($userid, "username"), 20) ."</span>
                
              
                <span data-getid='$userid'>";
          $mquery = $this->db->prepare("SELECT user_id FROM post WHERE post_id = :post LIMIT 1");
          $mquery->execute(array(":post" => $post));
          $row = $mquery->fetch(PDO::FETCH_OBJ);
          $user = $row->user_id;

          if ($session == $userid) {
            echo "<a href='#' style='float:right;' class='delete_tag' data-postid='{$post}'><i style='position:relative; margin-top:-10%; border-radius: 25px; color:red;' class='fa fa-trash' aria-hidden='true'></i></a>";
           
          } 

          echo "</span></div></div></div><hr>";
        }
      }
    }

    public function untag($post){
      $session = $_SESSION['id'];
      $query = $this->db->prepare("DELETE FROM taggings WHERE post_id = :post AND taggings_id = :id");
      $query->execute(array(":post" => $post, ":id" => $session));
    }

    public function AmITagged($post){
      $session = $_SESSION['id'];
      $query = $this->db->prepare("SELECT tagging_id FROM taggings WHERE post_id = :post AND taggings_id = :id");
      $query->execute(array(":post" => $post, ":id" => $session));
      $count = $query->rowCount();
      if ($count == 0) {
        return false;
      } else if ($count > 0) {
        return true;
      }
    }

    public function deleteTag($post, $id){
      $query = $this->db->prepare("DELETE FROM taggings WHERE post_id = :post AND taggings_id = :taggings");
      $query->execute(array(":post" => $post, ":taggings" => $id));
    }

  }
?>
