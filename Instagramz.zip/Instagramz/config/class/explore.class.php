<?php
  class explore{

    protected $db;
    protected $DIR;

    public function __construct(){
      $db = N::_DB();
      $DIR = N::$DIR;

      $this->db = $db;
      $this->DIR = $DIR;
    }

    public function explorePhotos(){
      $session = $_SESSION['id'];

      $avatar = new Avatar;
      $universal = new universal;
      $mutual = new mutual;
      $Time = new time;
      $follow = new follow_system;

      $query = $this->db->prepare("SELECT post.post_id, post.user_id, image_post.image, image_post.filter, post.time FROM post, image_post WHERE post.user_id <> :me AND post.type = :type  AND post.post_id = image_post.post_id ORDER BY RAND() LIMIT 15");
      $query->execute(array(":me" => $session, ":type" => "image"));
      if ($query->rowCount() > 0) {
        while ($row = $query->fetch(PDO::FETCH_OBJ)) {
          $post = $row->post_id;
          $user = $row->user_id;
          $image = $row->image;
          $time = $row->time;
          $filter = $row->filter;

          echo "<div class='exp_finds_ph inst'>
            <div class='exp_f_ph_img'>
              <img src='{$this->DIR}/media/Instagram_{$image}' alt='' data-imgby='{$universal->GETsDetails($user, "username")}' data-postid='{$post}' data-time='{$Time->timeAgo($time)}' data-filter='{$filter}' class='{$filter}'>
            </div>
            <div class='exp_f_ph_bottom'>
              <img src='{$this->DIR}/{$avatar->DisplayAvatar($user)}' alt=''>
              <div class='exp_f_ph_b_right'>
                <a href='{$this->DIR}/profile/{$universal->GETsDetails($user, "username")}'>{$universal->GETsDetails($user, "username")}</a>
                <span class='exp_f_ph_light'>{$Time->timeAgo($time)}</span>
              </div>
              <a class='exp_f_ph_open' href='{$this->DIR}/view_post/{$post}'><i class='material-icons'>open_in_new</i></a>
            </div>
          </div>";

        }
      } else if ($query->rowCount() == 0) {
        echo "<div class='home_last_mssg exp_p_last'>
          <img src='{$this->DIR}/images/needs/large.jpg'>
          <span>Sorry, no photos to explore</span>
        </div>";
      }

    }

    public function explorePeople(){
      $session = $_SESSION['id'];

      $avatar = new Avatar;
      $universal = new universal;
      $mutual = new mutual;
      $Time = new time;
      $follow = new follow_system;

      $query = $this->db->prepare("SELECT id FROM users WHERE id <> :me ORDER BY RAND() LIMIT 9");
      $query->execute(array(":me" => $session));
      if ($query->rowCount() > 0) {
        while ($row = $query->fetch(PDO::FETCH_OBJ)) {
          $id = $row->id;
          $none = '"none"';

          if ($follow->isFollowing($id) == false) {
            echo "<li><div class='card'>
            <a href='#'>
                
                &nbsp&nbsp&nbsp&nbsp <img src='{$this->DIR}/{$avatar->DisplayAvatar($id)}' class='ex-image'>
                <style>
                .ex-image {
                  display: inline-block;
                  width: 150px;
                height: 150px;
                border-radius: 50%;
                object-position: center;
                object-fit: cover;
                  transition: all .5s;
                }
                .ex-image:hover {
                  transform: scale(1.2) rotate(360deg);
                }
                </style>
            </a>
            <div class='p-3'>
                <h4 class='text-base font-semibold mb-0.5'> <a href='{$this->DIR}/profile/{$universal->GETsDetails($id, "username")}'>@{$universal->GETsDetails($id, "username")}</a> <img src='{$this->DIR}/images/".$universal->GETsDetails($id, "bluetick").".png' style='width:15px; height:15px; display:inline-block;' onerror='this.style.display = ".$none."'/></h4>
                <p class='font-medium text-sm'>{$follow->getFollowers($id, "username")} followers</p>
                
                
            </div><div data-getid='{$id}'>";
        if ($follow->isFollowing($id)) {
          echo "<a href='#' class='unfollow block py-1.5 mt-2 text-sm font-semibold text-center bg-gray-200 rounded-md'>Unfollow</a>";
        } else if ($follow->isFollowing($id) == false) {
          echo "<a href='#' class='follow block py-1.5 mt-2 text-sm font-semibold text-center bg-gray-200 rounded-md'>Follow</a>";
        }
        echo "</div></li>";
          }

        }
      }

    }

public function exploreBiz(){
      $session = $_SESSION['id'];

      $groups = new group;

      $query = $this->db->prepare("SELECT group_id, grp_name, grp_avatar, grp_very, grp_tag FROM groups WHERE group_id <> :me ORDER BY RAND() LIMIT 6");
      $query->execute(array(":me" => $session));
      if($query->rowCount() > 0) {
        while ($row = $query->fetch(PDO::FETCH_OBJ)) {
          $grp = $row->group_id;
          $name = $row->grp_name;
          $avatar = $row->grp_avatar;

          if ($groups->memberOrNot($grp, $session) == false) {
            echo " <div class='flex items-center space-x-4 rounded-md -mx-2 p-2 hover:bg-gray-50'>
                                  <a href='{$this->DIR}/groups/{$grp}' class='w-12 h-12 flex-shrink-0 overflow-hidden rounded-full relative'>
                                      <img src='{$groups->grpAvatar($grp)}' class='absolute w-full h-full inset-0' alt=''>
                                  </a>
                                  <div class='flex-1'>
                                      <a href='{$this->DIR}/groups/{$grp}' class='text-base font-semibold capitalize'> {$name} </a>
                                      <div class='text-sm text-gray-500 mt-0.5'>{$groups->noOfGrpMembers($grp)} Subscribers</div>
                                  </div>
                              </div>";
          }

        }
      }

    }
    
    public function exploreGroups(){
      $session = $_SESSION['id'];

      $groups = new group;

      $query = $this->db->prepare("SELECT group_id, grp_name, grp_avatar, grp_very, grp_tag FROM groups WHERE group_id <> :me ORDER BY RAND() LIMIT 6");
      $query->execute(array(":me" => $session));
      if($query->rowCount() > 0) {
        while ($row = $query->fetch(PDO::FETCH_OBJ)) {
          $grp = $row->group_id;
          $name = $row->grp_name;
          $avatar = $row->grp_avatar;
          $grpico = $row->grp_very;
          $Biztag = $row->grp_tag;

          if ($groups->memberOrNot($grp, $session) == false) {
            echo "
            <li>
                                <div
                                    class='relative bg-gradient-to-tr from-yellow-600 to-pink-600 p-1 rounded-full transform -rotate-2 hover:rotate-3 transition hover:scale-105 m-1'>
                                     <a href='{$this->DIR}/groups/{$grp}'>
                                    <img src='{$groups->grpAvatar($grp)}'
                                        class='w-20 h-20 rounded-full border-2 border-white bg-gray-200></a>
                                        <a 
                                        class=' bg-gray-400 p-2 rounded-full w-8 h-8 flex justify-center items-center text-white border-4 border-white absolute right-2 bottom-0 bg-red-600'>
                                        </a>
                                        <a 
                                        class=' bg-gray-400 p-2 rounded-full w-8 h-8 flex justify-center items-center text-white border-4 border-white absolute right-2 bottom-0 bg-purple-600'>
                                        <img src='{$groups->grpVery($grp)}' uk-tooltip='title: {$Biztag}'></a>
                                </div>
                                <a href='{$this->DIR}/groups/{$grp}' class='blockva font-medium text-center text-gray-500 text-x truncate w-24'>
                                    {$name}</a>
                            </li>
                  ";
          }

        }
      }

    }

        public function exploreGroupsInExplore(){
      $session = $_SESSION['id'];

      $groups = new group;

      $query = $this->db->prepare("SELECT group_id, grp_name, grp_avatar, grp_very, grp_tag FROM groups WHERE group_id <> :me ORDER BY RAND() LIMIT 6");
      $query->execute(array(":me" => $session));
      if($query->rowCount() > 0) {
        while ($row = $query->fetch(PDO::FETCH_OBJ)) {
          $grp = $row->group_id;
          $name = $row->grp_name;
          $avatar = $row->grp_avatar;
          $grpico = $row->grp_very;
          $Biztag = $row->grp_tag;

          if ($groups->memberOrNot($grp, $session) == false) {
            echo "<div class='flex items-center space-x-4 rounded-md -mx-2 p-2 hover:bg-gray-50'>
                                    <a href='{$this->DIR}/groups/{$grp}' class='w-12 h-12 flex-shrink-0 overflow-hidden rounded-full relative'>
                                        <img src='{$groups->grpAvatar($grp)}' class='absolute w-full h-full inset-0 '>
                                    </a>
                                    <div class='flex-1'>
                                        <a href='{$this->DIR}/groups/{$grp}' class='text-base font-semibold capitalize'> {$name} </a>
                                        <div class='text-sm text-gray-500 mt-0.5'><img src='{$groups->grpVery($grp)}' uk-tooltip='title: {$Biztag}' style='width:10px; height:10px;'> </div>
                                    </div>
                                    <a href='{$this->DIR}/groups/{$grp}'
                                        class='flex items-center justify-center h-8 px-3 rounded-md text-sm border font-semibold'>
                                        View
                                    </a>
                                </div>
                  ";
          }

        }
      }

    }


public function exploreGroupsInLead()
{
    $session = $_SESSION['id'];
    $groups = new group;
    $universal = new universal;
    $avatar = new Avatar;
    $queryl = $this->db->prepare("SELECT group_id, grp_name, grp_avatar, grp_very, grp_tag, grp_points FROM groups WHERE group_id <> :me ORDER BY grp_points DESC LIMIT 1");
    $queryl->execute(array(":me" => $session));
    
    if ($queryl->rowCount() > 0) {
        while ($row = $queryl->fetch(PDO::FETCH_OBJ)) {
            $grp = $row->group_id;
            $name = $row->grp_name;
            $avatarPath = $row->grp_avatar;
            $grpico = $row->grp_very;
            $Biztag = $row->grp_tag;
            $grppoints = $row->grp_points;
            $formattedNum = number_format($grppoints, 2);
            $parts = explode('.', $formattedNum);
            $decimal = $parts[1] === '00' ? '' : '.' . $parts[1];
            $formattedNum = $parts[0] . $decimal;

            $followerCount = $groups->noOfGrpMembers($grp);

            echo "<div class='col-xl-4 col-sm-6'>
                    <div class='single-box position-relative' data-bs-toggle='modal' data-bs-target='#userInfoMod'>
                        <div class='abs-top'>
                            <p class='lgtxt'><i class='uil uil-trophy' style='color:gold; font-size:40px;'></i></p>
                            <p class='mdtxt'>1st</p>
                        </div>
                        <div class='position-relative d-inline-flex justify-content-center'>
                            <div class='relative bg-gradient-to-tr from-yellow-600 to-pink-600 p-1 rounded-full transform -rotate-2 hover:rotate-3 transition hover:scale-105 m-1'>
                                <a href='{$this->DIR}/groups/{$grp}'>
                                      <img src='{$groups->grpAvatar($grp)}'
                                        class='w-20 h-20 rounded-full border-2 border-white bg-gray-200></a>
                                        <a 
                                        class=' bg-gray-400 p-2 rounded-full w-8 h-8 flex justify-center items-center text-white border-4 border-white absolute right-2 bottom-0 bg-red-600'>
                                        </a>
                                        <a 
                                        class=' bg-gray-400 p-2 rounded-full w-10 h-10 flex justify-center items-center text-white absolute right-2 bottom-0 bg-purple-600'>

                                        <img src='{$groups->grpVery($grp)}' uk-tooltip='title: {$Biztag}'></a>
                                </div>
                                        </div>
                                        <div class='info-area mt-4'>
                                           
                            <a href='{$this->DIR}/groups/{$grp}'><h5 class='truncate'>{$name}</h5></a>
                            <p class='mdtxt'>{$formattedNum} <img src='assets/images/favicon.png' style='width:20px; height:20px; display:inline-block;'></p>
                        </div>
                        <div class='coin-bonus mt-5 d-flex justify-content-between align-items-center'>
                            <div class='single'>
                                <p class='lgtxt'  style='color:black; font-weight:bold; font-size:15px;'>{$followerCount}</p>
                                <p class='mdtxt'>Followers</p>
                            </div>
                            <div class='single'>
                                <p style='font-size:15px; color:black; font-weight:bold;''>
                                <a href='{$this->DIR}/profile/{$universal->GETsDetails($groups->GETgrp($grp, "grp_admin"), "username")}'>";

            if ($groups->GETgrp($grp, "grp_admin") == $session) {
              $user_id = $groups->GETgrp($grp, "grp_admin"); // Assuming this returns the user_id of the group admin
                echo "<img class='w-10 h-10 rounded-full border-2 border-white bg-gray-200' src='{$this->DIR}/" . $avatar->GETsAvatar($user_id) . "' alt='' style='width: 20px; height: 20px; display: inline-block;'> You";
            } else {
                $adminUsername = $universal->GETsDetails($groups->GETgrp($grp, "grp_admin"), "username");
                $user_id = $groups->GETgrp($grp, "grp_admin"); // Assuming this returns the user_id of the group admin
                echo "<img class='w-10 h-10 rounded-full border-2 border-white bg-gray-200' src='{$this->DIR}/" . $avatar->GETsAvatar($user_id) . "' alt='' style='width: 20px; height: 20px; display: inline-block;'> @$adminUsername";
            }

            echo "</a></p>
                  <p class='mdtxt'>Owned by</p>
              </div>
          </div>
      </div>
  </div>";
        }
    }
}


public function exploreGroupsInLead2nd()
{
    $session = $_SESSION['id'];
    $groups = new group;
    $universal = new universal;
    $avatar = new Avatar;
    $queryl = $this->db->prepare("SELECT group_id, grp_name, grp_avatar, grp_very, grp_tag, grp_points FROM groups WHERE group_id <> :me ORDER BY grp_points DESC LIMIT 1 OFFSET 1");
    $queryl->execute(array(":me" => $session));
    
    if ($queryl->rowCount() > 0) {
        while ($row = $queryl->fetch(PDO::FETCH_OBJ)) {
            $grp = $row->group_id;
            $name = $row->grp_name;
            $avatarPath = $row->grp_avatar;
            $grpico = $row->grp_very;
            $Biztag = $row->grp_tag;
            $grppoints = $row->grp_points;
            $formattedNum = number_format($grppoints, 2);
            $parts = explode('.', $formattedNum);
            $decimal = $parts[1] === '00' ? '' : '.' . $parts[1];
            $formattedNum = $parts[0] . $decimal;

            $followerCount = $groups->noOfGrpMembers($grp);

            echo "<div class='col-xl-4 col-sm-6'>
                    <div class='single-box position-relative' data-bs-toggle='modal' data-bs-target='#userInfoMod'>
                        <div class='abs-top'>
                            <p class='lgtxt'><i class='uil uil-trophy' style='color:Silver;'></i></p>
                            <p class='mdtxt'>2nd</p>
                        </div>
                        <div class='position-relative d-inline-flex justify-content-center'>
                            <div class='relative bg-gradient-to-tr from-yellow-600 to-pink-600 p-1 rounded-full transform -rotate-2 hover:rotate-3 transition hover:scale-105 m-1'>
                                <a href='{$this->DIR}/groups/{$grp}'>
                                      <img src='{$groups->grpAvatar($grp)}'
                                        class='w-20 h-20 rounded-full border-2 border-white bg-gray-200></a>
                                        <a 
                                        class=' bg-gray-400 p-2 rounded-full w-8 h-8 flex justify-center items-center text-white border-4 border-white absolute right-2 bottom-0 bg-red-600'>
                                        </a>
                                        <a 
                                        class=' bg-gray-400 p-2 rounded-full w-10 h-10 flex justify-center items-center text-white absolute right-2 bottom-0 bg-purple-600'>

                                        <img src='{$groups->grpVery($grp)}' uk-tooltip='title: {$Biztag}'></a>
                                </div>
                                        </div>
                                        <div class='info-area mt-4'>
                                           
                            <a href='{$this->DIR}/groups/{$grp}'><h5 class='truncate'>{$name}</h5></a>
                            <p class='mdtxt'>{$formattedNum} <img src='assets/images/favicon.png' style='width:20px; height:20px; display:inline-block;'></p>
                        </div>
                        <div class='coin-bonus mt-5 d-flex justify-content-between align-items-center'>
                            <div class='single'>
                                <p class='lgtxt' style='color:black; font-weight:bold; font-size:15px;'>{$followerCount}</p>
                                <p class='mdtxt'>Followers</p>
                            </div>
                            <div class='single'>
                                <p style='font-size:15px; color:black; font-weight:bold;''>
                                <a href='{$this->DIR}/profile/{$universal->GETsDetails($groups->GETgrp($grp, "grp_admin"), "username")}'>";

            if ($groups->GETgrp($grp, "grp_admin") == $session) {
              $user_id = $groups->GETgrp($grp, "grp_admin"); // Assuming this returns the user_id of the group admin
                echo "<img class='w-10 h-10 rounded-full border-2 border-white bg-gray-200' src='{$this->DIR}/" . $avatar->GETsAvatar($user_id) . "' alt='' style='width: 20px; height: 20px; display: inline-block;'> You";
            } else {
                $adminUsername = $universal->GETsDetails($groups->GETgrp($grp, "grp_admin"), "username");
                $user_id = $groups->GETgrp($grp, "grp_admin"); // Assuming this returns the user_id of the group admin
                echo "<img class='w-10 h-10 rounded-full border-2 border-white bg-gray-200' src='{$this->DIR}/" . $avatar->GETsAvatar($user_id) . "' alt='' style='width: 20px; height: 20px; display: inline-block;'> @$adminUsername";
            }

            echo "</a></p>
                  <p class='mdtxt'>Owned by</p>
              </div>
          </div>
      </div>
  </div>";
        }
    }
}


public function exploreGroupsInLead3rd()
{
    $session = $_SESSION['id'];
    $groups = new group;
    $universal = new universal;
    $avatar = new Avatar;
    $queryl = $this->db->prepare("SELECT group_id, grp_name, grp_avatar, grp_very, grp_tag, grp_points FROM groups WHERE group_id <> :me ORDER BY grp_points DESC LIMIT 1 OFFSET 2");
    $queryl->execute(array(":me" => $session));
    
    if ($queryl->rowCount() > 0) {
        while ($row = $queryl->fetch(PDO::FETCH_OBJ)) {
            $grp = $row->group_id;
            $name = $row->grp_name;
            $avatarPath = $row->grp_avatar;
            $grpico = $row->grp_very;
            $Biztag = $row->grp_tag;
            $grppoints = $row->grp_points;
            $formattedNum = number_format($grppoints, 2);
            $parts = explode('.', $formattedNum);
            $decimal = $parts[1] === '00' ? '' : '.' . $parts[1];
            $formattedNum = $parts[0] . $decimal;

            $followerCount = $groups->noOfGrpMembers($grp);

            echo "<div class='col-xl-4 col-sm-6'>
                    <div class='single-box position-relative' data-bs-toggle='modal' data-bs-target='#userInfoMod'>
                        <div class='abs-top'>
                            <p class='lgtxt'><i class='uil uil-trophy' style='color:#CD7F32;'></i></p>
                            <p class='mdtxt'>3rd</p>
                        </div>
                        <div class='position-relative d-inline-flex justify-content-center'>
                            <div class='relative bg-gradient-to-tr from-yellow-600 to-pink-600 p-1 rounded-full transform -rotate-2 hover:rotate-3 transition hover:scale-105 m-1'>
                                <a href='{$this->DIR}/groups/{$grp}'>
                                      <img src='{$groups->grpAvatar($grp)}'
                                        class='w-20 h-20 rounded-full border-2 border-white bg-gray-200></a>
                                        <a 
                                        class=' bg-gray-400 p-2 rounded-full w-8 h-8 flex justify-center items-center text-white border-4 border-white absolute right-2 bottom-0 bg-red-600'>
                                        </a>
                                        <a 
                                        class=' bg-gray-400 p-2 rounded-full w-10 h-10 flex justify-center items-center text-white absolute right-2 bottom-0 bg-purple-600'>

                                        <img src='{$groups->grpVery($grp)}' uk-tooltip='title: {$Biztag}'></a>
                                </div>
                                        </div>
                                        <div class='info-area mt-4'>
                                           
                            <a href='{$this->DIR}/groups/{$grp}'><h5 class='truncate'>{$name}</h5></a>
                            <p class='mdtxt'>{$formattedNum} <img src='assets/images/favicon.png' style='width:20px; height:20px; display:inline-block;'></p>
                        </div>
                        <div class='coin-bonus mt-5 d-flex justify-content-between align-items-center'>
                            <div class='single'>
                                <p class='lgtxt' style='color:black; font-weight:bold; font-size:15px;'>{$followerCount}</p>
                                <p class='mdtxt'>Followers</p>
                            </div>
                            <div class='single'>
                                <p style='font-size:15px; color:black; font-weight:bold;'>
                                <a href='{$this->DIR}/profile/{$universal->GETsDetails($groups->GETgrp($grp, "grp_admin"), "username")}'>";

            if ($groups->GETgrp($grp, "grp_admin") == $session) {
              $user_id = $groups->GETgrp($grp, "grp_admin"); // Assuming this returns the user_id of the group admin
                echo "<img class='w-10 h-10 rounded-full border-2 border-white bg-gray-200' src='{$this->DIR}/" . $avatar->GETsAvatar($user_id) . "' alt='' style='width: 20px; height: 20px; display: inline-block;'> You";
            } else {
                $adminUsername = $universal->GETsDetails($groups->GETgrp($grp, "grp_admin"), "username");
                $user_id = $groups->GETgrp($grp, "grp_admin"); // Assuming this returns the user_id of the group admin
                echo "<img class='w-10 h-10 rounded-full border-2 border-white bg-gray-200' src='{$this->DIR}/" . $avatar->GETsAvatar($user_id) . "' alt='' style='width: 20px; height: 20px; display: inline-block;'> @$adminUsername";
            }

            echo "</a></p>
                  <p class='mdtxt'>Owned by</p>
              </div>
          </div>
      </div>
  </div>";
        }
    }
}


public function exploreGroupsInLeadlist()
{
    $session = $_SESSION['id'];
    $groups = new group;
    $universal = new universal;
    $avatar = new Avatar;
    $queryl = $this->db->prepare("SELECT group_id, grp_name, grp_avatar, grp_very, grp_tag, grp_points FROM groups WHERE group_id <> :me ORDER BY grp_points DESC LIMIT 7 OFFSET 3");
    $queryl->execute(array(":me" => $session));
    
    if ($queryl->rowCount() > 0) {
      $count = 4;
        while ($row = $queryl->fetch(PDO::FETCH_OBJ)) {
            $grp = $row->group_id;
            $name = $row->grp_name;
            $avatarPath = $row->grp_avatar;
            $grpico = $row->grp_very;
            $Biztag = $row->grp_tag;
            $grppoints = $row->grp_points;
            $formattedNum = number_format($grppoints, 2);
            $parts = explode('.', $formattedNum);
            $decimal = $parts[1] === '00' ? '' : '.' . $parts[1];
            $formattedNum = $parts[0] . $decimal;

            $followerCount = $groups->noOfGrpMembers($grp);

            echo "<tr data-bs-toggle='modal'>
                                            <th class='border-left' scope='row'>
                                                <span>0{$count}</span>
                                            </th>
                                           <td>
                                        <a href='{$this->DIR}/groups/{$grp}'>
                                          <span class='img-area'>
                                            <img src='{$groups->grpAvatar($grp)}' class='w-12 h-12 rounded-full border-2 border-purple bg-purple-600'>
                                          </span>
                                        </a>
                                        <a href='{$this->DIR}/groups/{$grp}'>
                                          <span class='lgtxt truncate' style='color:black; display: inline-block; max-width: 100px;'>{$name}</span>
                                        </a>
                                      </td>

                                            <td class='grid-area'>
                                                <span class='mdtxt'>{$formattedNum} <img src='assets/images/favicon.png' style='width:20px; height:20px; display:inline-block;'></span>
                                            </td>
                                            <td class='grid-area'>
                                                <span class='mdtxt' style='color:black; font-weight:bold; font-size:15px;'>{$followerCount}</span>
                                                <span class='mdtxt'>Followers</span>
                                            </td>
                                            <a href='{$this->DIR}/profile/{$universal->GETsDetails($groups->GETgrp($grp, "grp_admin"), "username")}'>

                                            <td class='grid-area border-right' style='color:black; font-weight:bold; font-size:12px;'> <a href='{$this->DIR}/profile/{$universal->GETsDetails($groups->GETgrp($grp, "grp_admin"), "username")}'>";
                                                


            if ($groups->GETgrp($grp, "grp_admin") == $session) {
              $user_id = $groups->GETgrp($grp, "grp_admin"); // Assuming this returns the user_id of the group admin
                echo "<img class='w-10 h-10 rounded-full border-2 border-white bg-gray-200' src='{$this->DIR}/" . $avatar->GETsAvatar($user_id) . "' alt='' style='width: 20px; height: 20px; display: inline-block;'> You";
            } else {
                $adminUsername = $universal->GETsDetails($groups->GETgrp($grp, "grp_admin"), "username");
                $user_id = $groups->GETgrp($grp, "grp_admin"); // Assuming this returns the user_id of the group admin
                echo "<img class='w-10 h-10 rounded-full border-2 border-white bg-gray-200' src='{$this->DIR}/" . $avatar->GETsAvatar($user_id) . "' alt='' style='width: 20px; height: 20px; display: inline-block;'> @$adminUsername";
            }

            echo "</a><span class='mdtxt'>Owned By</span>
                                            </td>
                                        </tr>";

                                        $count++;
        }
    }
}

    public function exploreAudios(){
      $session = $_SESSION['id'];

      $universal = new universal;
      $avatar = new Avatar;
      $Time = new time;
      $groups = new group;

      $query = $this->db->prepare("SELECT post.post_id, post.user_id, audio_post.audio, post.time, post.post_of, post.grp_id FROM post, audio_post WHERE post.user_id <> :me AND post.type = :type  AND post.post_id = audio_post.post_id ORDER BY RAND() LIMIT 4");
      $query->execute(array(":me" => $session, ":type" => "audio"));
      if ($query->rowCount() == 0) {
        echo "<div class='home_last_mssg'>
          <img src='{$this->DIR}/images/needs/large.jpg'>
          <span>Sorry, no audios to explore</span>
        </div>";
      }
      while ($row = $query->fetch(PDO::FETCH_OBJ)) {
        $audio = $row->audio;
        $post = $row->post_id;
        $user = $row->user_id;
        $time = $row->time;
        $of = $row->post_of;
        $grp = $row->grp_id;

        echo "<div class='exp_audio inst'>
          <div class='exp_aud_top'>
            <img src='{$this->DIR}/{$avatar->DisplayAvatar($user)}' alt=''>
            <div class='exp_aud_con'>
              <a href='{$this->DIR}/profile/{$universal->GETsDetails($user, "username")}'>{$universal->nameShortener($universal->GETsDetails($user, "username"), 30)}</a>";
              if ($of == "group") {
                echo "<span class='to_grp_arrow'><i class='material-icons'>arrow_drop_up</i></span><a href='{$this->DIR}/groups/{$grp}' class='to_grp_name exp_grp_name'>{$universal->nameShortener($groups->GETgrp($grp, "grp_name"), 20)}</a>";
              }
              echo "<span>{$Time->timeAgo($time)}</span>
            </div>
            <a href='{$this->DIR}/view_post/{$post}' class='sec_btn exp_aud_open'>Open post</a>
          </div>
          <hr>

          <div class='p_aud' data-song='{$this->DIR}/media/{$audio}'>
            <span class='p_aud_time_bubble'>0:00</span>
            <div class='p_aud_ctrls'>
              <div class='p_aud_info'>
                <span class='p_aud_name'>The Weeknd - Starboy (official) ft. Daft Punk</span>
              </div>
              <span class='p_aud_pp'><i class='material-icons'>play_arrow</i></span>
              <div class='p_aud_seek'>
                <input class='p_aud_seek_range' type='range' name='p_aud_seek_range' value='0' min='0' max='100' step='1'>
              </div>
              <div class='p_aud_duration'>
                <span class='p_aud_cur'>0:00</span>
                <span class='p_aud_dur_sep'>/</span>
                <span class='p_aud_dur'>0:00</span>
              </div>
              <div class='p_aud_vol_div'>
                <input type='range' name='p_aud_vol_slider' value='100' min='0' max='100' step='1'>
              </div>
              <span class='p_aud_vup'><i class='material-icons'>volume_up</i></span>
            </div>
          </div>
        </div>";

      }

    }

    public function exploreVideos(){
      $session = $_SESSION['id'];

      $universal = new universal;
      $avatar = new Avatar;
      $Time = new time;
      $groups = new group;

      $query = $this->db->prepare("SELECT post.post_id, post.user_id, video_post.video, post.time, post.post_of, post.grp_id FROM post, video_post WHERE post.user_id <> :me AND post.type = :type AND post.post_of = :group  AND post.post_id = video_post.post_id ORDER BY RAND() LIMIT 5");
      $query->execute(array(":me" => $session, ":type" => "video", ":group" => "group"));
      if ($query->rowCount() == 0) {
        echo "<li style='visibility:hidden;'>
          <img src='{$this->DIR}/images/no post.gif'>
          <span>Sorry, no videos to explore</span>
        </li>";
      }
      while ($row = $query->fetch(PDO::FETCH_OBJ)) {
        $video = $row->video;
        $post = $row->post_id;
        $user = $row->user_id;
        $time = $row->time;
        $of = $row->post_of;
        $grp = $row->grp_id;

        echo "
            <li>
            <a  class='w-full md:h-36 h-28 overflow-hidden rounded-lg relative blockva'>
             <video src='{$this->DIR}/media/Instagram_{$video}' loop preload='auto' class='w-full h-full absolute inset-0 object-cover' autoplay></video>
             </a>
              <div class='pt-3'>
                                   
                                    <div class='flex flex-1 items-center space-x-4'>
                                    <img class='bg-gray-200 border border-white rounded-full w-7 h-7' src='{$groups->grpAvatar($grp)}' /> 
                                    <div class='flex-1 capitalize'>
          <div class='font-semibold'> <a href='{$this->DIR}/groups/{$grp}' class='font-semibold line-clamp-2 truncate'>
          {$universal->nameShortener($groups->GETgrp($grp, "grp_name"), 20)} 
          <img src='{$groups->grpVery($grp)}' style='width:10px; height:10px; display:inline-block;' onerror='this.style.display = 'none''>
          </div><a href='{$this->DIR}/profile/{$universal->GETsDetails($user, 'username')}' class='text-sm'>@{$universal->nameShortener($universal->GETsDetails($user, 'username'), 30)}</a> . <a style='font-size:10px;'>{$Time->timeAgo($time)}</a> </div></div> 
                                    </div>
                                 </li>";

      }

    }

  }
?>
