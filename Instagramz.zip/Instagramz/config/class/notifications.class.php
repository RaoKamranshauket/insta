<?php
  class notifications{

    protected $db;
    protected $DIR;

    public function __construct(){
      $db = N::_DB();
      $DIR = N::$DIR;

      $this->db = $db;
      $this->DIR = $DIR;
    }

    public function notiCount(){
      $session = $_SESSION['id'];
      $query = $this->db->prepare("SELECT noti_id FROM notifications WHERE notify_to = :to");
      $query->execute(array(":to" => $session));
      $count = $query->rowCount();
      return $count;
    }

    public function unreadCount(){
      if (isset($_SESSION['id'])) {
        $session = $_SESSION['id'];
        $query = $this->db->prepare("SELECT noti_id FROM notifications WHERE notify_to = :to AND status = :status");
        $query->execute(array(":to" => $session, ":status" => "unread"));
        $count = $query->rowCount();
        if ($count != 0) {
          if ($count < 9) {
            return $count;
          } else if ($count >= 9) {
            return "10+";
          }
        }
      }
    }

    public function titleNoti(){
      if(self::unreadCount() != 0){
        return "(".self::unreadCount().")";
      }
    }

    public function markRead(){
      $session = $_SESSION['id'];
      $query = $this->db->prepare("UPDATE notifications SET status = :status WHERE notify_to = :to");
      $query->execute(array(":status" => "read", ":to" => $session));
    }

    public function followNotify($to, $type){
      $session = $_SESSION['id'];
      $query = $this->db->prepare("INSERT INTO notifications (notify_by, notify_to, type, time) VALUES (:by, :to, :type, now())");
      $query->execute(array(":by" => $session, ":to" => $to, ":type" => $type));
    }

    public function recommendNotify($to, $of){
      $by = $_SESSION['id'];
      $query = $this->db->prepare("INSERT INTO notifications(notify_by, notify_to, notify_of, type, time) VALUES(:by, :to, :of, :type, now())");
      $query->execute(array(":by" => $by, ":to" => $to, ":of" => $of, ":type" => "recommend"));
    }

    public function actionNotify($to, $post, $type){
      $by = $_SESSION['id'];
      if ($by != $to) {
        $query = $this->db->prepare("INSERT INTO notifications (notify_by, notify_to, post_id, type, time) VALUES (:by, :to, :post, :type, now())");
        $query->execute(array(":by" => $by, ":to" => $to, ":post" => $post, ":type" => $type));
      }
    }

    public function cLikeNotify($by, $to, $post, $comment){
      $session = $_SESSION['id'];
      $query = $this->db->prepare("INSERT INTO notifications (notify_by, notify_to, post_id, comment_id, type, time) VALUES(:by, :to, :post, :comment, 'commentLike', now())");
      $query->execute(array(":by" => $by, ":to" => $to, ":post" => $post, ":comment" => $comment,));
    }

    public function clearNotifications(){
      $session = $_SESSION['id'];
      $query = $this->db->prepare("DELETE FROM notifications WHERE notify_to = :to");
      $query->execute(array(":to" => $session));
    }

    public function getNotifications($way, $limit){
      $universal = new universal;
      $avatar = new Avatar;
      $Time = new time;
      $follow = new follow_system;
      $group = new group;
      $message = new message;

      $session = $_SESSION['id'];

      if ($way == "direct") {
        $query = $this->db->prepare("SELECT * FROM notifications WHERE notify_to = :to ORDER BY noti_id DESC LIMIT 20");
        $query->execute(array(":to" => $session));

      } else if ($way == "ajax") {
        $start = intval($limit);
        $query = $this->db->prepare("SELECT * FROM notifications WHERE notify_to = :to AND noti_id < :start ORDER BY noti_id DESC LIMIT 20");
        $query->execute(array(":to" => $session, ":start" => $start));
      }

      $count = $query->rowCount();
      if ($count == 0) {
        if ($way == "direct") {
          echo "<div class='home_last_mssg pro_last_mssg'><img src='{$this->DIR}/images/needs/sleep.gif'>
          <span>You have no notifications</span></div>";
        }
      } else if ($count > 0) {
        while ($row = $query->fetch(PDO::FETCH_OBJ)) {
          $nid = $row->noti_id;
          $by = $row->notify_by;
          $type = $row->type;
          $to = $row->notify_to;
          $of = $row->notify_of;
          $postid = $row->post_id;
          $time = $row->time;
          $none = '"none"';

          if ($type == "follow") {
            echo "<li data-notiid='{$nid}'> <a>";
            if ($way == "direct") {
              echo "<div class='drop_avatar'><img src='{$this->DIR}/{$avatar->GETsAvatar($by)}' alt='' class='noti_avatar'></div>";
            } else if ($way == "ajax") {
              echo "<div class='drop_avatar'><img src='{$this->DIR}/{$avatar->DisplayAvatar($by)}' alt='' class='noti_avatar'></div>";
            }
              echo "<span class='drop_icon bg-gradient-primary'>
                   <i class='icon-feather-user-check'></i>
                 </span> 
                 <div class='drop_text'>
                 <p>
                 <strong href='{$this->DIR}/profile/{$universal->GETsDetails($by, "username")}' title='{$universal->GETsDetails($by, "username")}'>@". $universal->nameShortener($universal->GETsDetails($by, "username"), 20) ."</strong> <img src='{$this->DIR}/images/".$universal->GETsDetails($by, "bluetick").".png' style='width:15px; height:15px; display:inline-block;' onerror='this.style.display = ".$none."'/>
                 started <br>following you
                 </p>
                <time>{$Time->timeAgo($time)}</time>
                </div><div class='noti_right follow_noti_right' data-getid='{$by}'>";
                if ($follow->isFollowing($by)) {
                  echo "<a href='#' class='noti_ff flex items-center justify-center h-8 px-3 rounded-md text-sm border font-semibold unfollow'>Unfollow</a>";
                } else if ($follow->isFollowing($by) == false) {
                  echo "<a href='#' class='noti_ff flex items-center justify-center h-8 px-3 rounded-md text-sm border font-semibold follow'>Follow</a>";
                }
                echo"</div>";
                echo"</a></li>";

            //<!-- recommend --!>
            } else if ($type == "recommend") {
              echo "<li data-notiid='{$nid}'> <a>";
              if ($way == "direct") {
                echo "<div class='drop_avatar'><img src='{$this->DIR}/{$avatar->GETsAvatar($by)}' alt='' class='noti_avatar'></div>";
              } else if ($way == "ajax") {
                echo "<div class='drop_avatar'><img src='{$this->DIR}/{$avatar->DisplayAvatar($by)}' alt='' class='noti_avatar'></div>";
              }
                echo "<span class='drop_iconn bg-gradient-primary'>
                     <i class='icon-feather-rss'></i>
                   </span> 
                   <div class='drop_text'>
                   <p>
                   <strong href='{$this->DIR}/profile/{$universal->GETsDetails($by, "username")}' title='{$universal->GETsDetails($by, "username")}'>@". $universal->nameShortener($universal->GETsDetails($by, "username"), 20) ."</strong> <img src='{$this->DIR}/images/".$universal->GETsDetails($by, "bluetick").".png' style='width:15px; height:15px; display:inline-block;' onerror='this.style.display = ".$none."'/>
                   recommended <br><strong>@". $universal->nameShortener($universal->GETsDetails($of, "username"), 20) ."</strong> to you
                   </p>
                  <time>{$Time->timeAgo($time)}</time>
                  </div><div class='noti_right follow_noti_right' data-getid='{$of}'>
                  <a href='{$this->DIR}/profile/{$universal->GETsDetails($of, "username")}' class='noti_ff flex items-center justify-center h-8 px-3 rounded-md text-sm border font-semibold'>View @{$universal->nameShortener($universal->GETsDetails($of, "username"), 10)}</a>";
                  echo"</div>";
                  echo"</a></li>";


//<!-- like --!>
              } else if ($type == "like") {
                echo "<li data-notiid='{$nid}'> <a>";
                if ($way == "direct") {
                  echo "<div class='drop_avatar'><img src='{$this->DIR}/{$avatar->GETsAvatar($by)}' alt='' class='noti_avatar'></div>";
                } else if ($way == "ajax") {
                  echo "<div class='drop_avatar'><img src='{$this->DIR}/{$avatar->DisplayAvatar($by)}' alt='' class='noti_avatar'></div>";
                }
                  echo "<span class='drop_iconnn bg-gradient-primary'>
                       <i class='icon-feather-heart'></i>
                     </span> 
                     <div class='drop_text'>
                     <p>
                     <strong href='{$this->DIR}/profile/{$universal->GETsDetails($by, "username")}' title='{$universal->GETsDetails($by, "username")}'>@". $universal->nameShortener($universal->GETsDetails($by, "username"), 20) ."</strong> <img src='{$this->DIR}/images/".$universal->GETsDetails($by, "bluetick").".png' style='width:15px; height:15px; display:inline-block;' onerror='this.style.display = ".$none."'/>
                     liked <br> your post
                     </p>
                    <time>{$Time->timeAgo($time)}</time>
                    </div><div class='noti_right follow_noti_right' data-getid='{$by}'>
                    <a href='{$this->DIR}/view_post/{$postid}' class='noti_ff flex items-center justify-center h-8 px-3 rounded-md text-sm border font-semibold'>View post</a>";
                    echo"</div>";
                    echo"</a></li>";

//<!-- comment --!>

                } else if ($type == "comment") {
                  echo "<li data-notiid='{$nid}'> <a>";
                  if ($way == "direct") {
                    echo "<div class='drop_avatar'><img src='{$this->DIR}/{$avatar->GETsAvatar($by)}' alt='' class='noti_avatar'></div>";
                  } else if ($way == "ajax") {
                    echo "<div class='drop_avatar'><img src='{$this->DIR}/{$avatar->DisplayAvatar($by)}' alt='' class='noti_avatar'></div>";
                  }
                    echo "<span class='drop_iconnnn bg-gradient-primary'>
                         <i class='icon-feather-message-circle'></i>
                       </span> 
                       <div class='drop_text'>
                       <p>
                       <strong href='{$this->DIR}/profile/{$universal->GETsDetails($by, "username")}' title='{$universal->GETsDetails($by, "username")}'>@". $universal->nameShortener($universal->GETsDetails($by, "username"), 20) ."</strong> <img src='{$this->DIR}/images/".$universal->GETsDetails($by, "bluetick").".png' style='width:15px; height:15px; display:inline-block;' onerror='this.style.display = ".$none."'/>
                       commented <br> on your post
                       </p>
                      <time>{$Time->timeAgo($time)}</time>
                      </div><div class='noti_right follow_noti_right' data-getid='{$by}'>
                      <a href='{$this->DIR}/view_post/{$postid}' class='noti_ff flex items-center justify-center h-8 px-3 rounded-md text-sm border font-semibold'>View post</a>";
                      echo"</div>";
                      echo"</a></li>";

          //<!-- share you a post --!>
                  } else if ($type == "shareto") {
                    echo "<li data-notiid='{$nid}'> <a>";
                    if ($way == "direct") {
                      echo "<div class='drop_avatar'><img src='{$this->DIR}/{$avatar->GETsAvatar($by)}' alt='' class='noti_avatar'></div>";
                    } else if ($way == "ajax") {
                      echo "<div class='drop_avatar'><img src='{$this->DIR}/{$avatar->DisplayAvatar($by)}' alt='' class='noti_avatar'></div>";
                    }
                      echo "<span class='drop_iconnnnn bg-gradient-primary'>
                           <i class='icon-feather-share-2'></i>
                         </span> 
                         <div class='drop_text'>
                         <p>
                         <strong href='{$this->DIR}/profile/{$universal->GETsDetails($by, "username")}' title='{$universal->GETsDetails($by, "username")}'>@". $universal->nameShortener($universal->GETsDetails($by, "username"), 20) ."</strong> <img src='{$this->DIR}/images/".$universal->GETsDetails($by, "bluetick").".png' style='width:15px; height:15px; display:inline-block;' onerror='this.style.display = ".$none."'/>
                         shared <br> you a post
                         </p>
                        <time>{$Time->timeAgo($time)}</time>
                        </div><div class='noti_right follow_noti_right' data-getid='{$by}'>
                        <a href='{$this->DIR}/view_post/{$postid}' class='noti_ff flex items-center justify-center h-8 px-3 rounded-md text-sm border font-semibold'>View post</a>";
                        echo"</div>";
                        echo"</a></li>";


            //<!-- share your post --!> 
                    } else if ($type == "shareyour") {
                      echo "<li data-notiid='{$nid}'> <a>";
                      if ($way == "direct") {
                        echo "<div class='drop_avatar'><img src='{$this->DIR}/{$avatar->GETsAvatar($by)}' alt='' class='noti_avatar'></div>";
                      } else if ($way == "ajax") {
                        echo "<div class='drop_avatar'><img src='{$this->DIR}/{$avatar->DisplayAvatar($by)}' alt='' class='noti_avatar'></div>";
                      }
                        echo "<span class='drop_iconnnnn bg-gradient-primary'>
                             <i class='icon-feather-share-2'></i>
                           </span> 
                           <div class='drop_text'>
                           <p>
                           <strong href='{$this->DIR}/profile/{$universal->GETsDetails($by, "username")}' title='{$universal->GETsDetails($by, "username")}'>@". $universal->nameShortener($universal->GETsDetails($by, "username"), 20) ."</strong> <img src='{$this->DIR}/images/".$universal->GETsDetails($by, "bluetick").".png' style='width:15px; height:15px; display:inline-block;' onerror='this.style.display = ".$none."'/>
                           shared <br> your post
                           </p>
                          <time>{$Time->timeAgo($time)}</time>
                          </div><div class='noti_right follow_noti_right' data-getid='{$by}'>
                          <a href='{$this->DIR}/view_post/{$postid}' class='noti_ff flex items-center justify-center h-8 px-3 rounded-md text-sm border font-semibold'>View post</a>";
                          echo"</div>";
                          echo"</a></li>";


                  //<!-- comment like --!>          
                      } else if ($type == "commentLike") {
                        echo "<li data-notiid='{$nid}'> <a>";
                        if ($way == "direct") {
                          echo "<div class='drop_avatar'><img src='{$this->DIR}/{$avatar->GETsAvatar($by)}' alt='' class='noti_avatar'></div>";
                        } else if ($way == "ajax") {
                          echo "<div class='drop_avatar'><img src='{$this->DIR}/{$avatar->DisplayAvatar($by)}' alt='' class='noti_avatar'></div>";
                        }
                          echo "<span class='drop_iconnn bg-gradient-primary'>
                               <i class='icon-feather-heart'></i>
                             </span> 
                             <div class='drop_text'>
                             <p>
                             <strong href='{$this->DIR}/profile/{$universal->GETsDetails($by, "username")}' title='{$universal->GETsDetails($by, "username")}'>@". $universal->nameShortener($universal->GETsDetails($by, "username"), 20) ."</strong> <img src='{$this->DIR}/images/".$universal->GETsDetails($by, "bluetick").".png' style='width:15px; height:15px; display:inline-block;' onerror='this.style.display = ".$none."'/>
                             liked <br> your comment
                             </p>
                            <time>{$Time->timeAgo($time)}</time>
                            </div><div class='noti_right follow_noti_right' data-getid='{$by}'>
                            <a href='{$this->DIR}/view_post/{$postid}' class='noti_ff flex items-center justify-center h-8 px-3 rounded-md text-sm border font-semibold'>View comment</a>";
                            echo"</div>";
                            echo"</a></li>";

                  //<!-- tagged you --!>             
                        } else if ($type == "tag") {
                          echo "<li data-notiid='{$nid}'> <a>";
                          if ($way == "direct") {
                            echo "<div class='drop_avatar'><img src='{$this->DIR}/{$avatar->GETsAvatar($by)}' alt='' class='noti_avatar'></div>";
                          } else if ($way == "ajax") {
                            echo "<div class='drop_avatar'><img src='{$this->DIR}/{$avatar->DisplayAvatar($by)}' alt='' class='noti_avatar'></div>";
                          }
                            echo "<span class='drop_iconnnnnn bg-gradient-primary'>
                                 <i class='icon-feather-tag'></i>
                               </span> 
                               <div class='drop_text'>
                               <p>
                               <strong href='{$this->DIR}/profile/{$universal->GETsDetails($by, "username")}' title='{$universal->GETsDetails($by, "username")}'>@". $universal->nameShortener($universal->GETsDetails($by, "username"), 20) ."</strong> <img src='{$this->DIR}/images/".$universal->GETsDetails($by, "bluetick").".png' style='width:15px; height:15px; display:inline-block;' onerror='this.style.display = ".$none."'/>
                               tagged <br> you in a post
                               </p>
                              <time>{$Time->timeAgo($time)}</time>
                              </div><div class='noti_right follow_noti_right' data-getid='{$by}'>
                              <a href='{$this->DIR}/view_post/{$postid}' class='noti_ff flex items-center justify-center h-8 px-3 rounded-md text-sm border font-semibold'>View post</a>";
                              echo"</div>";
                              echo"</a></li>";



                    //<!-- post mention --!>            
                          } else if ($type == "post_mention") {
                            echo "<li data-notiid='{$nid}'> <a>";
                            if ($way == "direct") {
                              echo "<div class='drop_avatar'><img src='{$this->DIR}/{$avatar->GETsAvatar($by)}' alt='' class='noti_avatar'></div>";
                            } else if ($way == "ajax") {
                              echo "<div class='drop_avatar'><img src='{$this->DIR}/{$avatar->DisplayAvatar($by)}' alt='' class='noti_avatar'></div>";
                            }
                              echo "<span class='drop_iconnnnnn bg-gradient-primary'>
                                   <i class='icon-feather-tag'></i>
                                 </span> 
                                 <div class='drop_text'>
                                 <p>
                                 <strong href='{$this->DIR}/profile/{$universal->GETsDetails($by, "username")}' title='{$universal->GETsDetails($by, "username")}'>@". $universal->nameShortener($universal->GETsDetails($by, "username"), 20) ."</strong> <img src='{$this->DIR}/images/".$universal->GETsDetails($by, "bluetick").".png' style='width:15px; height:15px; display:inline-block;' onerror='this.style.display = ".$none."'/>
                                 mentioned <br> you in a post
                                 </p>
                                <time>{$Time->timeAgo($time)}</time>
                                </div><div class='noti_right follow_noti_right' data-getid='{$by}'>
                                <a href='{$this->DIR}/view_post/{$postid}' class='noti_ff flex items-center justify-center h-8 px-3 rounded-md text-sm border font-semibold'>View post</a>";
                                echo"</div>";
                                echo"</a></li>";


                 //<!-- comment mention --!>                     
                            } else if ($type == "comment_mention") {
                              echo "<li data-notiid='{$nid}'> <a>";
                              if ($way == "direct") {
                                echo "<div class='drop_avatar'><img src='{$this->DIR}/{$avatar->GETsAvatar($by)}' alt='' class='noti_avatar'></div>";
                              } else if ($way == "ajax") {
                                echo "<div class='drop_avatar'><img src='{$this->DIR}/{$avatar->DisplayAvatar($by)}' alt='' class='noti_avatar'></div>";
                              }
                                echo "<span class='drop_icon bg-gradient-primary'>
                                     <i class='icon-feather-at-sign'></i>
                                   </span> 
                                   <div class='drop_text'>
                                   <p>
                                   <strong href='{$this->DIR}/profile/{$universal->GETsDetails($by, "username")}' title='{$universal->GETsDetails($by, "username")}'>@". $universal->nameShortener($universal->GETsDetails($by, "username"), 20) ."</strong> <img src='{$this->DIR}/images/".$universal->GETsDetails($by, "bluetick").".png' style='width:15px; height:15px; display:inline-block;' onerror='this.style.display = ".$none."'/>
                                   mentioned <br> you in a comment
                                   </p>
                                  <time>{$Time->timeAgo($time)}</time>
                                  </div><div class='noti_right follow_noti_right' data-getid='{$by}'>
                                  <a href='{$this->DIR}/view_post/{$postid}' class='noti_ff flex items-center justify-center h-8 px-3 rounded-md text-sm border font-semibold'>View comment</a>";
                                  echo"</div>";
                                  echo"</a></li>";
                              } 
            
            
          





        }
      }

    }

  }
?>
