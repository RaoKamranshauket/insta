<?php
  ob_start();
  session_start();
  define('DIR', '/instagramz');
?>
