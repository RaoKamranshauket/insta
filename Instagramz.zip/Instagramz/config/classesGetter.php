<?php
  include_once 'class/needy_class.php';
  include 'class/universal.class.php';
  include 'class/tags.class.php';
  include 'class/avatar.class.php';
  include 'class/follow_system.class.php';
  include 'class/general.class.php';
  include 'class/post.class.php';
  include 'class/time.class.php';
  include 'class/post_like.class.php';
  include 'class/bkmrk.class.php';
  include 'class/taggings.class.php';
  include 'class/share.class.php';
  include 'class/post_comment.class.php';
  include 'class/mutual.class.php';
  include 'class/recommend.class.php';
  include 'class/settings.class.php';
  include 'class/notifications.class.php';
  include 'class/message.class.php';
  include 'class/suggestions.class.php';
  include 'class/groups.class.php';
  include 'class/explore.class.php';
  include 'class/search.class.php';
  include 'class/hashtag.class.php';
  include 'class/mention.class.php';
  include 'class/fav.class.php';
?>
