<?php error_reporting (0); ?>
<?php include 'config/declare.php'; ?>

<!-- a universal file that has all the classes included -->
<?php include 'config/classesGetter.php'; ?>

<!-- creating objects -->
<?php
  $universal = new universal;
  $avatar = new Avatar;
?>

<?php
  if ($universal->isLoggedIn()) {
    header('Location: '.DIR);
  }
?>


<?php include 'index_include/index_headerrr.php'; ?>

 <!-- LOGIN-->

 <div>
                <div class="lg:p-12 max-w-xl lg:my-0 my-12 mx-auto p-6 space-y-">
                <form class="login lg:p-10 p-6 space-y-3 relative bg-white shadow-xl rounded-md" action="" method="post">
                <h1 class="lg:text-2xl text-xl font-semibold mb-6"> Login </h1>

                <div>
                    <label class="mb-0"> Username </label>
                    <input type="text" name="s_username" value="" autocomplete="off" placeholder="Username" class="s_username bg-gray-100 h-12 mt-2 px-3 rounded-md w-full" spellcheck="false" mssg="" maxlength="32" required autofocus>
                </div>
                <div class="username_checker u_c">
                  
                    <span class="checker_text">username not available</span>
                   <span class="checker_icon">
                    <i class="fa fa-frown-o" aria-hidden="true"></i>
                   </span>
                </div>

                <div>
                    <label class="mb-0"> Password </label>
                    <input type="password" name="s_password" value="" autocomplete="off" placeholder="Password" id="login_password" class="s_password bg-gray-100 h-12 mt-2 px-3 rounded-md w-full" required maxlength="32">
                    <span class="show_psswrd log_show_psswrd" id="show_psswrd">
                      <i class="fa fa-lock" aria-hidden="true"></i>
                    </span>
                </div>
                <div>
                        <a href="forgot_psswrd" tabindex="5" class="link">Forgotten your passowrd?</a>
                        
                </div>
                <div>
                 <button type="submit" name="s_submit" value="login" class="s_submit bg-blue-600 font-semibold p-2 mt-5 rounded-md text-center text-white w-full">Login</button>
                </div>
                </form>
        <div style="margin: 0 12px 0 4px"></div>
        
    </div>


   
  </div>

    

                </div>
            </div>
            <!----------------------  LOGIN  ---------------------->


            <!----------------------  QUICK LOGIN  ---------------------->

 


  <div class="notify">
    <span></span>
  </div>

</div>

<div class="overlay-2"></div>
<div class="overlay"></div>
<?php include 'index_include/index_footerrr.php'; ?>


<script type="text/javascript">
  $(function(e){
    $('form.login').on('submit', (function(e){
      e.preventDefault();
      $('.s_submit').prop('disabled', true);
      $('.overlay-2').show();
      login($('.s_username').val(), $('.s_password').val(), $('.s_submit'));
    }));

    $('.log_show_psswrd').togglePassword({
      input: document.getElementById('login_password')
    });

    $('.q_l_div > img').description({extraTop: -30});

    $('.q_l_div > img').quickLogin();

  });
</script>
